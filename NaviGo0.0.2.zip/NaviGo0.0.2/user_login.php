<?php
session_start();

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = sanitize_input($_POST['email']);
    $password = $_POST['password'];
    
    if (empty($email) || empty($password)) {
        $error_message = 'Please fill in all fields.';
    } else {
        $user = authenticate_user($email, $password);
        if ($user) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_type'] = 'personal';
            $_SESSION['user_email'] = $user['email'];
            header('Location: User/user_dashboard.php');
            exit();
        } else {
            $error_message = 'Invalid email or password.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login - NaviGo</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <script src="js/dark-mode.js"></script>
</head>
<body class="login-page">
    <div class="container">
        <!-- Back Button -->
         <button class="back-button" onclick="window.location.href='Index.php'">
             <i class="fas fa-arrow-left"></i>
         </button>

        <style>
            .login-page {
                background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
                min-height: 100vh;
                position: relative;
                font-family: 'Roboto', sans-serif;
            }
            
            .login-page::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-image: 
                    url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><circle cx="20" cy="20" r="2" fill="%23e0f2fe" opacity="0.3"/><circle cx="80" cy="30" r="1.5" fill="%23bae6fd" opacity="0.4"/><circle cx="30" cy="70" r="1" fill="%23e0f2fe" opacity="0.2"/><circle cx="70" cy="80" r="2.5" fill="%23bae6fd" opacity="0.3"/></svg>');
                pointer-events: none;
            }
            
            .login-container {
                display: grid;
                grid-template-columns: 1fr 500px;
                gap: 10px;
                align-items: start;
                min-height: 100vh;
                max-width: 1200px;
                margin: 0 auto;
                position: relative;
            }
            
            .login-content {
                background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
                padding: 60px 40px;
                display: flex;
                flex-direction: column;
                justify-content: flex-start;
                position: relative;
                min-height: 100vh;
                overflow: visible;
            }
            
            .login-panel {
                background: white;
                border-radius: 15px;
                margin-top: 40px;
                margin-bottom: 40px;
                margin-right: 40px;
                padding: 40px;
                box-shadow: -5px 0 20px rgba(0, 0, 0, 0.1);
                display: flex;
                flex-direction: column;
                justify-content: flex-start;
                min-height: 600px;
                position: relative;
                z-index: 1;
            }
            
            .login-title {
                font-size: 2.5rem;
                font-weight: 700;
                margin-bottom: 20px;
                line-height: 1.2;
            }
            
            .login-title .journey {
                color: #2563eb;
            }
            
            .login-title .starts {
                color: #0891b2;
            }
            
            .login-subtitle {
                font-size: 1.5rem;
                color: #374151;
                margin-bottom: 20px;
            }
            
            .login-description {
                font-size: 1.1rem;
                color: #6b7280;
                line-height: 1.6;
                margin-bottom: 40px;
            } 

            .logo {
                margin-top: 5fpx;
                margin-left: 40px;
                margin-right: 40px;
                margin-bottom: 5px;
            }

            .logo-container {
                display: inline-block;
                margin: 0 auto;
            }

            .logo-image {
                width: 100px;
                height: auto;
                display: block;
                margin: 0 auto;
            }

            .features-grid {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 20px;
            }
            
            .feature-item {
                background: white;
                border-radius: 12px;
                padding: 20px;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
                display: flex;
                align-items: center;
                gap: 15px;
            }
            
            .feature-icon {
                width: 40px;
                height: 40px;
                border-radius: 8px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 18px;
                color: white;
            }
            
            .feature-item:nth-child(1) .feature-icon {
                background: #2563eb;
            }
            
            .feature-item:nth-child(2) .feature-icon {
                background: #0891b2;
            }
            
            .feature-item:nth-child(3) .feature-icon {
                background: #7c3aed;
            }
            
            .feature-item:nth-child(4) .feature-icon {
                background: #f59e0b;
            }
            
            .feature-content h4 {
                font-size: 1rem;
                font-weight: 600;
                color: #374151;
                margin-bottom: 5px;
            }
            
            .feature-content p {
                font-size: 0.9rem;
                color: #6b7280;
                line-height: 1.4;
            }
            
            .panel-header {
                text-align: left;
                margin-top: 30px;
                margin-bottom: 30px;
            }
            
            .panel-header h3 {
                font-size: 0.9rem;
                color: #6b7280;
                text-transform: uppercase;
                letter-spacing: 1px;
                margin-bottom: 10px;
                display: flex;
                align-items: center;
                gap: 8px;
            }
            
            .panel-header h3::before {
                content: '📱';
                font-size: 14px;
            }
            
            .panel-header h4 {
                font-size: 1.8rem;
                font-weight: 700;
                color: #374151;
                margin-bottom: 8px;
            }
            
            .panel-header p {
                font-size: 0.9rem;
                color: #6b7280;
            }
            
            .login-form-container h5 {
                font-size: 1.2rem;
                font-weight: 600;
                color: #374151;
                margin-bottom: 8px;
            }
            
            .login-form-container p {
                font-size: 0.9rem;
                color: #6b7280;
                margin-bottom: 25px;
            }
            
             .form-toggle {
                 display: flex;
                 margin-bottom: 25px;
                 background: #f3f4f6;
                 border-radius: 5px;
                 padding: 4px;
                 border: none;
                 gap: 2px;
             }
            
             .toggle-btn {
                 flex: 1;
                 padding: 12px;
                 border: none;
                 font-weight: 500;
                 cursor: pointer;
                 transition: all 0.3s ease;
             }
             
             .toggle-btn:first-child {
                 border-radius: 4px 0 0 4px;
             }
             
             .toggle-btn:last-child {
                 border-radius: 0 4px 4px 0;
             }
            
            .toggle-btn.active {
                background: linear-gradient(135deg, #2563eb, #0891b2);
                color: white;
            }
            
            .toggle-btn:not(.active) {
                background: transparent;
                color: #6b7280;
            }
            
            .form-group {
                margin-right: 1px;
                margin-left: 1px;
                margin-bottom: 20px;
                position: relative;
            }
            
            .form-row {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 15px;
                margin-bottom: 20px;
            }
            
            .form-group label {
                display: flex;
                align-items: center;
                gap: 8px;
                margin-bottom: 8px;
                font-weight: 500;
                color: #6b7280;
                font-size: 0.9rem;
            }
            
            .form-group input {
                width: 100%;
                padding: 15px;
                border: 1px solid #d1d5db;
                border-radius: 8px;
                font-size: 1rem;
                background: #f9fafb;
                transition: all 0.3s ease;
            }
            
            .form-group input:focus {
                outline: none;
                border-color: #2563eb;
                background: white;
                box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
            }
            
            .btn-primary {
                background: linear-gradient(135deg, #2563eb, #0891b2);
                border: none;
                border-radius: 8px;
                padding: 15px 25px;
                color: white;
                font-size: 1rem;
                font-weight: 600;
                cursor: pointer;
                transition: all 0.3s ease;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
                width: 100%;
            }
            
            .btn-primary:hover {
                transform: translateY(-2px);
                box-shadow: 0 8px 25px rgba(37, 99, 235, 0.3);
            }
            
            .login-links {
                text-align: center;
                margin: 20px 0;
            }
            
            .login-links a {
                color: #2563eb;
                text-decoration: none;
                font-size: 0.9rem;
            }
            
            .social-login {
                margin: 30px 0;
            }
            
             .divider {
                 text-align: center;
                 margin: 20px 0;
                 position: relative;
             }
             
             .divider::before {
                 content: '';
                 position: absolute;
                 top: 50%;
                 left: 0;
                 right: 0;
                 height: 1px;
                 background: #e5e7eb;
             }
             
             .divider span {
                 background: white;
                 padding: 0 15px;
                 color: #6b7280;
                 font-size: 0.8rem;
                 font-weight: 600;
                 text-transform: uppercase;
                 letter-spacing: 1px;
                 position: relative;
                 z-index: 1;
             }
            
            .social-buttons {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 15px;
            }
            
            .btn-social {
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 10px;
                padding: 12px;
                border: 1px solid #d1d5db;
                background: white;
                color: #374151;
                font-weight: 500;
                border-radius: 8px;
                cursor: pointer;
                transition: all 0.3s ease;
            }
            
            .btn-social:hover {
                border-color: #2563eb;
                color: #2563eb;
            }
            
            .legal-links {
                text-align: center;
                font-size: 0.8rem;
                color: #6b7280;
                line-height: 1.5;
            }
            
            .legal-links a {
                color: #2563eb;
                text-decoration: none;
            }
            
            .dark-mode-toggle {
                position: absolute;
                top: 20px;
                right: 20px;
                z-index: 1000;
                background: rgba(255, 255, 255, 0.9);
                border: none;
                border-radius: 15%;
                width: 40px;
                height: 40px;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                backdrop-filter: blur(10px);
                transition: all 0.3s ease;
            }
            
            .dark-mode-toggle:hover {
                background: rgba(255, 255, 255, 1);
                transform: scale(1.1);
            }
             
             .back-button {
                 position: absolute;
                 top: 20px;
                 left: 20px;
                 z-index: 1000;
                 background: rgba(255, 255, 255, 0.9);
                 border: none;
                 border-radius: 50%;
                 width: 40px;
                 height: 40px;
                 cursor: pointer;
                 display: flex;
                 align-items: center;
                 justify-content: center;
                 backdrop-filter: blur(10px);
                 transition: all 0.3s ease;
                 font-size: 16px;
                 color: #6b7280;
             }
             
             .back-button:hover {
                 background: rgba(255, 255, 255, 1);
                 transform: scale(1.1);
             }
            
            /* Dark Mode Styles */
            body.dark-mode {
                background: linear-gradient(135deg, #1e1b4b 0%, #0f172a 100%);
            }
            
            body.dark-mode .login-content {
                background: linear-gradient(135deg, #1e1b4b 0%, #0f172a 100%);
            }
            
            body.dark-mode .login-title .journey {
                color: #e2e8f0;
            }
            
            body.dark-mode .login-title .starts {
                color: #0891b2;
            }
            
            body.dark-mode .login-subtitle {
                color: #f8fafc;
            }
            
            body.dark-mode .login-description {
                color: #cbd5e1;
            }
            
            body.dark-mode .login-panel {
                background: #1e293b;
                border: 1px solid #334155;
            }
            
            body.dark-mode .panel-header h3,
            body.dark-mode .panel-header h4,
            body.dark-mode .panel-header p {
                color: #f8fafc;
            }
            
            body.dark-mode .login-form-container h5,
            body.dark-mode .login-form-container p {
                color: #f8fafc;
            }
            
            body.dark-mode .form-group label {
                color: #9ca3af;
            }
            
            body.dark-mode .form-group input {
                background: #1f2937;
                border-color: #4b5563;
                color: #e2e8f0;
            }
            
            body.dark-mode .form-group input:focus {
                background: #1f2937;
                border-color: #0891b2;
            }
            
            body.dark-mode .form-group input::placeholder {
                color: #e2e8f0;
            }
            
             body.dark-mode .form-toggle {
                 background: #374151;
                 border: 15px;
                 border-radius: 5px;
                 padding: 4px;
             }
             
            body.dark-mode .toggle-btn:not(.active) {
                background: #374151;
                color: #9ca3af;
            }
            
            body.dark-mode .toggle-btn.active {
                background: linear-gradient(135deg, #0ea5e9, #14b8a6);
                color: #ffffff;
            }
            
            body.dark-mode .login-links a {
                color: #0891b2;
            }
            
            body.dark-mode .btn-primary {
                background: linear-gradient(135deg, #0ea5e9, #14b8a6);
                color: #ffffff;
            }
            
            body.dark-mode .btn-social {
                background: #374151;
                border-color: #4b5563;
                color: #f8fafc;
            }
            
            body.dark-mode .btn-social:hover {
                border-color: #0891b2;
                color: #0891b2;
            }
            
            body.dark-mode .legal-links {
                color: #9ca3af;
            }
            
            body.dark-mode .legal-links a {
                color: #0891b2;
            }
            
            body.dark-mode .dark-mode-toggle {
                background: rgba(0, 0, 0, 0.2);
            }
            
             body.dark-mode .dark-mode-toggle:hover {
                 background: rgba(0, 0, 0, 0.3);
             }
             
             body.dark-mode .feature-item {
                 background: #374151;
                 border: 1px solid #4b5563;
             }
             
             body.dark-mode .feature-content h4 {
                 color: #f8fafc;
             }
             
             body.dark-mode .feature-content p {
                 color: #cbd5e1;
             }
             
            body.dark-mode .divider::before {
                background: #6b7280;
            }
            
            body.dark-mode .divider span {
                background: #1e293b;
                color: #9ca3af;
            }
             
             body.dark-mode .back-button {
                 background: rgba(0, 0, 0, 0.2);
                 color: #9ca3af;
             }
             
             body.dark-mode .back-button:hover {
                 background: rgba(0, 0, 0, 0.3);
             }
        </style>

        <!-- Dark Mode Toggle -->
        <button class="dark-mode-toggle" onclick="toggleDarkMode()">
            <span id="dark-mode-icon">🌙</span>
        </button>
        
        <div class="login-container">
            <!-- Left Content -->
            <div class="login-content">
                <div class="logo">
                    <div class="logo-container">
                        <img src="Assets/Images/NaviGo_Logo.png" alt="NaviGo Logo" class="logo-image">
                    </div>
                </div>
                <h1 class="login-title">
                    <span class="journey">Your Journey</span> <span class="starts">Starts Here</span>
                </h1>
                <h2 class="login-subtitle">Welcome to NaviGo</h2>
                <p class="login-description">
                    Your intelligent travel companion for seamless trip planning, cost optimization, 
                    and collaborative group adventures that create lasting memories.
                </p>

                <!-- Feature Icons -->
                <div class="features-grid">
                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fas fa-bolt"></i>
                        </div>
                        <div class="feature-content">
                            <h4>AI-Powered Planning</h4>
                            <p>Smart recommendations tailored for you</p>
                        </div>
                    </div>

                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <div class="feature-content">
                            <h4>Secure & Synced</h4>
                            <p>All your adventures in one place</p>
                        </div>
                    </div>

                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="feature-content">
                            <h4>Group Adventures</h4>
                            <p>Collaborate and explore together</p>
                        </div>
                    </div>

                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fas fa-map-pin"></i>
                        </div>
                        <div class="feature-content">
                            <h4>Smart Savings</h4>
                            <p>Optimize costs on every journey</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Login Panel -->
            <div class="login-panel">
                <div class="panel-header">
                    <h3>NAVIGO ACCESS</h3>
                    <h4>Your Travel Portal</h4>
                    <p>Access your personalized journey hub</p>
                </div>

                <div class="login-form-container">
                    <h5>Access Your Journey</h5>
                    <p id="form-description">Sign in to continue your travel story</p>
                    
                    <!-- Toggle Buttons -->
                    <div class="form-toggle">
                        <button type="button" class="toggle-btn active" onclick="showSignIn()">Sign In</button>
                        <button type="button" class="toggle-btn" onclick="showNewJourney()">New Journey</button>
                    </div>
                    
                    <?php if ($error_message): ?>
                        <div class="alert alert-error">
                            <i class="fas fa-exclamation-circle"></i>
                            <?php echo htmlspecialchars($error_message); ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($success_message): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i>
                            <?php echo htmlspecialchars($success_message); ?>
                        </div>
                    <?php endif; ?>

                    <!-- Sign In Form -->
                    <form method="POST" action="user_login.php" class="login-form" id="signin-form">
                        <div class="form-group">
                            <label for="email">
                                <i class="fas fa-map-pin"></i> Email Address
                            </label>
                            <input type="email" id="email" name="email" required 
                                   placeholder="traveler@example.com"
                                   value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                        </div>

                        <div class="form-group">
                            <label for="password">
                                <i class="fas fa-shield-alt"></i> Password
                            </label>
                            <input type="password" id="password" name="password" required
                                   placeholder="Your secure password">
                        </div>

                        <button type="submit" class="btn-primary">
                            <i class="fas fa-plane"></i> Begin Journey
                        </button>
                    </form>

                    <!-- New Journey Form -->
                    <form method="POST" action="User/user_dashboard.php" class="login-form" id="newjourney-form" style="display: none;">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="firstname">First Name</label>
                                <input type="text" id="firstname" name="firstname" required 
                                       placeholder="Explorer">
                            </div>

                            <div class="form-group">
                                <label for="lastname">Last Name</label>
                                <input type="text" id="lastname" name="lastname" required 
                                       placeholder="Adventurer">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="reg_email">
                                <i class="fas fa-globe"></i> Email Address
                            </label>
                            <input type="email" id="reg_email" name="email" required 
                                   placeholder="explorer@wanderlust.com">
                        </div>

                        <div class="form-group">
                            <label for="reg_password">
                                <i class="fas fa-shield-alt"></i> Secure Password
                            </label>
                            <input type="password" id="reg_password" name="password" required
                                   placeholder="Create your travel key">
                        </div>

                        <button type="submit" class="btn-primary">
                            <i class="fas fa-compass"></i> Start Adventure
                        </button>
                    </form>

                    <div class="login-links">
                        <a href="forgot-password.php">Lost your travel pass?</a>
                    </div>

                    <div class="social-login">
                        <div class="divider">
                            <span>QUICK ACCESS</span>
                        </div>
                        
                        <div class="social-buttons">
                            <button class="btn-social">
                                <i class="fab fa-google"></i>
                                Google
                            </button>
                            <button class="btn-social">
                                <i class="fab fa-microsoft"></i>
                                Microsoft
                            </button>
                        </div>
                    </div>

                    <div class="legal-links">
                        By continuing your journey, you agree to our <a href="terms.php">Terms of Service</a> and <a href="privacy.php">Privacy Policy</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Notification function
        function showNotification(message, type = 'info') {
            // Create notification element
            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.innerHTML = `
                <div class="notification-content">
                    <i class="fas fa-${getNotificationIcon(type)}"></i>
                    <span>${message}</span>
                </div>
                <button class="notification-close" onclick="this.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            `;

            // Add styles
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: white;
                border-radius: 10px;
                padding: 15px 20px;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
                z-index: 10000;
                display: flex;
                align-items: center;
                gap: 15px;
                max-width: 400px;
                animation: slideInRight 0.3s ease;
            `;

            // Add to page
            document.body.appendChild(notification);

            // Auto remove after 5 seconds
            setTimeout(() => {
                if (notification.parentElement) {
                    notification.style.animation = 'slideOutRight 0.3s ease';
                    setTimeout(() => notification.remove(), 300);
                }
            }, 5000);
        }

        // Example usage
        // showNotification('Welcome to NaviGo!', 'success');
        
        // Tab switching functions
        function showSignIn() {
            document.getElementById('signin-form').style.display = 'block';
            document.getElementById('newjourney-form').style.display = 'none';
            document.getElementById('form-description').textContent = 'Sign in to continue your travel story';
            
            // Update button states
            document.querySelectorAll('.toggle-btn').forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
        }
        
        function showNewJourney() {
            document.getElementById('signin-form').style.display = 'none';
            document.getElementById('newjourney-form').style.display = 'block';
            document.getElementById('form-description').textContent = 'Create your account to start your adventure';
            
            // Update button states
            document.querySelectorAll('.toggle-btn').forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
        }
        
        // Dark mode is now handled by js/dark-mode.js
    </script>
</body>
</html>
