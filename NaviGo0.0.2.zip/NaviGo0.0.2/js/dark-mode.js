// Dark Mode System for NaviGo
// Simple and reliable dark mode persistence across all pages

// Initialize dark mode when page loads
document.addEventListener('DOMContentLoaded', function() {
    initializeDarkMode();
});

// Also initialize immediately in case DOMContentLoaded already fired
if (document.readyState === 'loading') {
    // Still loading, wait for DOMContentLoaded
} else {
    // DOM already loaded, initialize immediately
    initializeDarkMode();
}

// Initialize dark mode based on saved preference
function initializeDarkMode() {
    const savedMode = localStorage.getItem('navigo-dark-mode');
    console.log('Initializing dark mode, saved mode:', savedMode);
    
    if (savedMode === 'true') {
        document.body.classList.add('dark-mode');
        updateDarkModeIcons('☀️');
        console.log('Dark mode enabled');
    } else {
        document.body.classList.remove('dark-mode');
        updateDarkModeIcons('🌙');
        console.log('Light mode enabled');
    }
}

// Toggle dark mode function
function toggleDarkMode() {
    const body = document.body;
    const isDarkMode = body.classList.contains('dark-mode');
    
    console.log('Toggling dark mode, currently dark:', isDarkMode);
    
    if (isDarkMode) {
        // Switch to light mode
        body.classList.remove('dark-mode');
        localStorage.setItem('navigo-dark-mode', 'false');
        updateDarkModeIcons('🌙');
        console.log('Switched to light mode');
    } else {
        // Switch to dark mode
        body.classList.add('dark-mode');
        localStorage.setItem('navigo-dark-mode', 'true');
        updateDarkModeIcons('☀️');
        console.log('Switched to dark mode');
    }
}

// Update all dark mode icons on the page
function updateDarkModeIcons(icon) {
    // Update all possible dark mode icon selectors
    const selectors = ['#dark-mode-icon', '.moon-icon', '.dark-mode-toggle span'];
    
    console.log('Updating icons to:', icon);
    
    selectors.forEach(selector => {
        const elements = document.querySelectorAll(selector);
        console.log(`Found ${elements.length} elements for selector: ${selector}`);
        elements.forEach(element => {
            element.textContent = icon;
        });
    });
}
