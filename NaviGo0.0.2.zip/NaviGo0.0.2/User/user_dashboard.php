<?php
session_start();
require_once '../Config/Database.php';
require_once '../Config/functions.php';

// Check if user is logged in
if (!is_logged_in()) {
    header('Location: ../user_login.php');
    exit();
}

$user_type = get_user_type();
$user_id = get_current_user_id();

// Get user information
if ($user_type === 'personal') {
    $user = get_user_by_id($user_id);
    $user_name = $user['first_name'] . ' ' . $user['last_name'];
} else {
    $business = get_business_by_id($user_id);
    $user_name = $business['business_name'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - NaviGo</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <script src="../js/dark-mode.js"></script>
    <style>
        .dashboard-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .dashboard-header {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        .welcome-message {
            font-size: 2rem;
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .user-type {
            color: #00BCD4;
            font-size: 1.1rem;
            font-weight: 500;
        }
        
        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin-bottom: 30px;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }
        
        .dashboard-card:hover {
            transform: translateY(-5px);
        }
        
        .card-icon {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #00BCD4, #0097A7);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            margin-bottom: 20px;
        }
        
        .card-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: #2c3e50;
            margin-bottom: 10px;
        }
        
        .card-description {
            color: #666;
            line-height: 1.6;
            margin-bottom: 20px;
        }
        
        .logout-btn {
            background: #e74c3c;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 25px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: all 0.3s ease;
        }
        
        .logout-btn:hover {
            background: #c0392b;
            transform: translateY(-2px);
        }
        
        /* Dark Mode Toggle */
        .dark-mode-toggle {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 1000;
            background: rgba(255, 255, 255, 0.9);
            border: none;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            backdrop-filter: blur(10px);
            transition: all 0.3s ease;
            font-size: 20px;
        }
        
        .dark-mode-toggle:hover {
            background: rgba(255, 255, 255, 1);
            transform: scale(1.1);
        }
        
        /* Dark Mode Styles */
        body.dark-mode {
            background: linear-gradient(135deg, #1e1b4b 0%, #0f172a 100%);
            color: #e2e8f0;
        }
        
        body.dark-mode .dashboard-container {
            background: transparent;
        }
        
        body.dark-mode .dashboard-header {
            background: #1e293b;
            border: 1px solid #334155;
            color: #f8fafc;
        }
        
        body.dark-mode .welcome-message {
            color: #f8fafc;
        }
        
        body.dark-mode .user-type {
            color: #0891b2;
        }
        
        body.dark-mode .dashboard-card {
            background: #1e293b;
            border: 1px solid #334155;
            color: #f8fafc;
        }
        
        body.dark-mode .card-title {
            color: #f8fafc;
        }
        
        body.dark-mode .card-description {
            color: #cbd5e1;
        }
        
        body.dark-mode .dark-mode-toggle {
            background: rgba(0, 0, 0, 0.2);
            color: #f8fafc;
        }
        
        body.dark-mode .dark-mode-toggle:hover {
            background: rgba(0, 0, 0, 0.3);
        }
        
        /* Button Styles */
        .btn {
            display: inline-block;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #2563eb, #0891b2);
            color: white;
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(37, 99, 235, 0.3);
        }
        
        .btn-secondary {
            background: linear-gradient(135deg, #6b7280, #4b5563);
            color: white;
        }
        
        .btn-secondary:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(107, 114, 128, 0.3);
        }
        
        .btn-outline {
            background: transparent;
            border: 2px solid #2563eb;
            color: #2563eb;
        }
        
        .btn-outline:hover {
            background: #2563eb;
            color: white;
        }
        
        body.dark-mode .btn-outline {
            border-color: #0891b2;
            color: #0891b2;
        }
        
        body.dark-mode .btn-outline:hover {
            background: #0891b2;
            color: white;
        }
    </style>
</head>
<body>
    <!-- Dark Mode Toggle -->
    <button class="dark-mode-toggle" onclick="toggleDarkMode()">
        <span id="dark-mode-icon">🌙</span>
    </button>
    
    <div class="dashboard-container">
        <div class="dashboard-header">
            <h1 class="welcome-message">Welcome back, <?php echo htmlspecialchars($user_name); ?>!</h1>
            <p class="user-type"><?php echo ucfirst($user_type); ?> Account</p>
            <a href="../Database/logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
        
        <div class="dashboard-grid">
            <?php if ($user_type === 'personal'): ?>
                <!-- Personal Account Dashboard -->
                <div class="dashboard-card">
                    <div class="card-icon">
                        <i class="fas fa-map-marked-alt"></i>
                    </div>
                    <h3 class="card-title">My Itineraries</h3>
                    <p class="card-description">Plan and manage your travel adventures with AI-powered recommendations.</p>
                    <a href="#" class="btn btn-primary">View Itineraries</a>
                </div>
                
                <div class="dashboard-card">
                    <div class="card-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <h3 class="card-title">Group Travel</h3>
                    <p class="card-description">Collaborate with friends and family on your next adventure.</p>
                    <a href="#" class="btn btn-primary">Start Group Trip</a>
                </div>
                
                <div class="dashboard-card">
                    <div class="card-icon">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <h3 class="card-title">Travel Analytics</h3>
                    <p class="card-description">Track your travel spending and optimize your budget.</p>
                    <a href="#" class="btn btn-primary">View Analytics</a>
                </div>
                
                <div class="dashboard-card">
                    <div class="card-icon">
                        <i class="fas fa-bookmark"></i>
                    </div>
                    <h3 class="card-title">Saved Places</h3>
                    <p class="card-description">Keep track of places you want to visit.</p>
                    <a href="#" class="btn btn-primary">View Saved Places</a>
                </div>
                
            <?php else: ?>
                <!-- Business Account Dashboard -->
                <div class="dashboard-card">
                    <div class="card-icon">
                        <i class="fas fa-calendar-check"></i>
                    </div>
                    <h3 class="card-title">Bookings Management</h3>
                    <p class="card-description">Manage your bookings and reservations efficiently.</p>
                    <a href="#" class="btn btn-secondary">Manage Bookings</a>
                </div>
                
                <div class="dashboard-card">
                    <div class="card-icon">
                        <i class="fas fa-chart-bar"></i>
                    </div>
                    <h3 class="card-title">Analytics Dashboard</h3>
                    <p class="card-description">Get detailed insights into your business performance.</p>
                    <a href="#" class="btn btn-secondary">View Analytics</a>
                </div>
                
                <div class="dashboard-card">
                    <div class="card-icon">
                        <i class="fas fa-cog"></i>
                    </div>
                    <h3 class="card-title">Services</h3>
                    <p class="card-description">Manage your services and inventory.</p>
                    <a href="#" class="btn btn-secondary">Manage Services</a>
                </div>
                
                <div class="dashboard-card">
                    <div class="card-icon">
                        <i class="fas fa-star"></i>
                    </div>
                    <h3 class="card-title">Reviews</h3>
                    <p class="card-description">Monitor customer feedback and ratings.</p>
                    <a href="#" class="btn btn-secondary">View Reviews</a>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="dashboard-card">
            <h3 class="card-title">Quick Actions</h3>
            <div style="display: flex; gap: 15px; flex-wrap: wrap;">
                <a href="../Index.php" class="btn btn-outline">Back to Home</a>
                <a href="#" class="btn btn-outline">Settings</a>
                <a href="#" class="btn btn-outline">Help & Support</a>
            </div>
        </div>
    </div>
    
    <script src="js/main.js"></script>
</body>
</html>