<?php
require_once 'Database.php';

// Database connection instance
$database = new Database();
$pdo = $database->getConnection();

// =============================================
// USER AUTHENTICATION FUNCTIONS
// =============================================

function authenticate_user($email, $password) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT id, first_name, last_name, email, password FROM users WHERE email = ? AND is_active = TRUE");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password'])) {
        // Update last login
        $update_stmt = $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $update_stmt->execute([$user['id']]);
        
        return $user;
    }
    
    return false;
}

function authenticate_business($email, $password) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT id, business_name, email, password FROM businesses WHERE email = ? AND is_active = TRUE");
    $stmt->execute([$email]);
    $business = $stmt->fetch();
    
    if ($business && password_verify($password, $business['password'])) {
        // Update last login
        $update_stmt = $pdo->prepare("UPDATE businesses SET last_login = NOW() WHERE id = ?");
        $update_stmt->execute([$business['id']]);
        
        return $business;
    }
    
    return false;
}

function register_user($first_name, $last_name, $email, $password) {
    global $pdo;
    
    try {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $verification_token = bin2hex(random_bytes(32));
        
        $stmt = $pdo->prepare("INSERT INTO users (first_name, last_name, email, password, verification_token) VALUES (?, ?, ?, ?, ?)");
        $result = $stmt->execute([$first_name, $last_name, $email, $hashed_password, $verification_token]);
        
        if ($result) {
            return $pdo->lastInsertId();
        }
    } catch(PDOException $e) {
        // Handle duplicate email error
        if ($e->getCode() == 23000) {
            return false; // Email already exists
        }
        throw $e;
    }
    
    return false;
}

function register_business($business_name, $business_type, $contact_first_name, $contact_last_name, $email, $password, $phone) {
    global $pdo;
    
    try {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $verification_token = bin2hex(random_bytes(32));
        
        $stmt = $pdo->prepare("INSERT INTO businesses (business_name, business_type, contact_first_name, contact_last_name, email, password, phone, verification_token) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $result = $stmt->execute([$business_name, $business_type, $contact_first_name, $contact_last_name, $email, $hashed_password, $phone, $verification_token]);
        
        if ($result) {
            return $pdo->lastInsertId();
        }
    } catch(PDOException $e) {
        // Handle duplicate email error
        if ($e->getCode() == 23000) {
            return false; // Email already exists
        }
        throw $e;
    }
    
    return false;
}

// =============================================
// SESSION MANAGEMENT FUNCTIONS
// =============================================

function is_logged_in() {
    return isset($_SESSION['user_id']) || isset($_SESSION['business_id']);
}

function get_user_type() {
    if (isset($_SESSION['user_type'])) {
        return $_SESSION['user_type'];
    }
    return null;
}

function get_current_user_id() {
    if (isset($_SESSION['user_id'])) {
        return $_SESSION['user_id'];
    } elseif (isset($_SESSION['business_id'])) {
        return $_SESSION['business_id'];
    }
    return null;
}

function get_user_by_id($user_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND is_active = TRUE");
    $stmt->execute([$user_id]);
    return $stmt->fetch();
}

function get_business_by_id($business_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT * FROM businesses WHERE id = ? AND is_active = TRUE");
    $stmt->execute([$business_id]);
    return $stmt->fetch();
}

// =============================================
// UTILITY FUNCTIONS
// =============================================

function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

function generate_booking_reference() {
    return 'NAV' . strtoupper(uniqid());
}

function generate_join_code() {
    return strtoupper(substr(uniqid(), -8));
}

// =============================================
// ITINERARY FUNCTIONS
// =============================================

function create_itinerary($user_id, $title, $description, $destination, $start_date, $end_date, $budget = null) {
    global $pdo;
    
    $stmt = $pdo->prepare("INSERT INTO itineraries (user_id, title, description, destination, start_date, end_date, budget) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $result = $stmt->execute([$user_id, $title, $description, $destination, $start_date, $end_date, $budget]);
    
    if ($result) {
        return $pdo->lastInsertId();
    }
    
    return false;
}

function get_user_itineraries($user_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT * FROM itineraries WHERE user_id = ? ORDER BY created_at DESC");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}

function get_itinerary_by_id($itinerary_id, $user_id = null) {
    global $pdo;
    
    if ($user_id) {
        $stmt = $pdo->prepare("SELECT * FROM itineraries WHERE id = ? AND user_id = ?");
        $stmt->execute([$itinerary_id, $user_id]);
    } else {
        $stmt = $pdo->prepare("SELECT * FROM itineraries WHERE id = ?");
        $stmt->execute([$itinerary_id]);
    }
    
    return $stmt->fetch();
}

// =============================================
// BOOKING FUNCTIONS
// =============================================

function create_booking($user_id, $business_id, $service_id, $itinerary_id, $service_name, $booking_date, $check_in_date, $check_out_date, $quantity, $total_amount, $special_requests = null) {
    global $pdo;
    
    $booking_reference = generate_booking_reference();
    
    $stmt = $pdo->prepare("INSERT INTO bookings (user_id, business_id, service_id, itinerary_id, booking_reference, service_name, booking_date, check_in_date, check_out_date, quantity, total_amount, special_requests) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $result = $stmt->execute([$user_id, $business_id, $service_id, $itinerary_id, $booking_reference, $service_name, $booking_date, $check_in_date, $check_out_date, $quantity, $total_amount, $special_requests]);
    
    if ($result) {
        return $booking_reference;
    }
    
    return false;
}

function get_user_bookings($user_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT b.*, bs.service_name, bs.service_type, bus.business_name 
        FROM bookings b 
        LEFT JOIN business_services bs ON b.service_id = bs.id 
        LEFT JOIN businesses bus ON b.business_id = bus.id 
        WHERE b.user_id = ? 
        ORDER BY b.created_at DESC
    ");
    $stmt->execute([$user_id]);
    return $stmt->fetchAll();
}

// =============================================
// NOTIFICATION FUNCTIONS
// =============================================

function create_notification($user_id, $business_id, $type, $title, $message, $action_url = null) {
    global $pdo;
    
    $stmt = $pdo->prepare("INSERT INTO notifications (user_id, business_id, type, title, message, action_url) VALUES (?, ?, ?, ?, ?, ?)");
    $result = $stmt->execute([$user_id, $business_id, $type, $title, $message, $action_url]);
    
    return $result;
}

function get_user_notifications($user_id, $limit = 10) {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?");
    $stmt->execute([$user_id, $limit]);
    return $stmt->fetchAll();
}

function mark_notification_read($notification_id, $user_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = TRUE, read_at = NOW() WHERE id = ? AND user_id = ?");
    return $stmt->execute([$notification_id, $user_id]);
}

// =============================================
// ERROR HANDLING
// =============================================

function handle_database_error($e) {
    error_log("Database Error: " . $e->getMessage());
    
    // Don't expose database errors to users in production
    if (defined('DEBUG') && DEBUG) {
        return "Database Error: " . $e->getMessage();
    } else {
        return "An error occurred. Please try again later.";
    }
}

// =============================================
// VALIDATION FUNCTIONS
// =============================================

function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validate_password($password) {
    // At least 8 characters, 1 uppercase, 1 lowercase, 1 number
    return preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{8,}$/', $password);
}

function validate_phone($phone) {
    // Basic phone validation - adjust regex as needed
    return preg_match('/^[\+]?[1-9][\d]{0,15}$/', $phone);
}

// =============================================
// SECURITY FUNCTIONS
// =============================================

function generate_csrf_token() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function rate_limit_check($identifier, $max_attempts = 5, $time_window = 300) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as attempts 
        FROM sessions 
        WHERE user_id = ? AND last_activity > DATE_SUB(NOW(), INTERVAL ? SECOND)
    ");
    $stmt->execute([$identifier, $time_window]);
    $result = $stmt->fetch();
    
    return $result['attempts'] < $max_attempts;
}

?>
