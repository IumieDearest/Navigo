-- NaviGo Database Schema
-- Created for NaviGo Travel Planning Application
-- Version: 1.0

-- Create database
CREATE DATABASE IF NOT EXISTS navigo_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE navigo_db;

-- =============================================
-- USERS TABLE (Personal Accounts)
-- =============================================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    date_of_birth DATE,
    profile_picture VARCHAR(255),
    bio TEXT,
    preferences JSON,
    is_active BOOLEAN DEFAULT TRUE,
    email_verified BOOLEAN DEFAULT FALSE,
    verification_token VARCHAR(100),
    reset_token VARCHAR(100),
    reset_token_expires DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    INDEX idx_email (email),
    INDEX idx_active (is_active),
    INDEX idx_created_at (created_at)
);

-- =============================================
-- BUSINESSES TABLE (Business Partner Accounts)
-- =============================================
CREATE TABLE businesses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    business_name VARCHAR(100) NOT NULL,
    business_type ENUM('hotel', 'restaurant', 'tour', 'transport', 'other') NOT NULL,
    contact_first_name VARCHAR(50) NOT NULL,
    contact_last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    business_phone VARCHAR(20),
    website VARCHAR(255),
    business_address TEXT,
    city VARCHAR(50),
    state VARCHAR(50),
    country VARCHAR(50),
    postal_code VARCHAR(20),
    business_description TEXT,
    business_hours JSON,
    amenities JSON,
    social_media JSON,
    is_active BOOLEAN DEFAULT TRUE,
    is_verified BOOLEAN DEFAULT FALSE,
    verification_documents JSON,
    email_verified BOOLEAN DEFAULT FALSE,
    verification_token VARCHAR(100),
    reset_token VARCHAR(100),
    reset_token_expires DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    INDEX idx_email (email),
    INDEX idx_business_type (business_type),
    INDEX idx_active (is_active),
    INDEX idx_verified (is_verified),
    INDEX idx_created_at (created_at)
);

-- =============================================
-- ITINERARIES TABLE (Travel Plans)
-- =============================================
CREATE TABLE itineraries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    destination VARCHAR(100) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    budget DECIMAL(10,2),
    currency VARCHAR(3) DEFAULT 'USD',
    status ENUM('planning', 'confirmed', 'in_progress', 'completed', 'cancelled') DEFAULT 'planning',
    is_public BOOLEAN DEFAULT FALSE,
    is_shared BOOLEAN DEFAULT FALSE,
    share_token VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_destination (destination),
    INDEX idx_dates (start_date, end_date),
    INDEX idx_status (status),
    INDEX idx_public (is_public)
);

-- =============================================
-- ITINERARY_ITEMS TABLE (Activities/Events in Itinerary)
-- =============================================
CREATE TABLE itinerary_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    itinerary_id INT NOT NULL,
    day_number INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    activity_type ENUM('accommodation', 'transportation', 'attraction', 'restaurant', 'activity', 'other') NOT NULL,
    start_time TIME,
    end_time TIME,
    location VARCHAR(200),
    address TEXT,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    cost DECIMAL(10,2),
    currency VARCHAR(3) DEFAULT 'USD',
    booking_reference VARCHAR(100),
    notes TEXT,
    is_confirmed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (itinerary_id) REFERENCES itineraries(id) ON DELETE CASCADE,
    INDEX idx_itinerary_id (itinerary_id),
    INDEX idx_day_number (day_number),
    INDEX idx_activity_type (activity_type),
    INDEX idx_location (location)
);

-- =============================================
-- GROUP_TRAVELS TABLE (Group Travel Sessions)
-- =============================================
CREATE TABLE group_travels (
    id INT AUTO_INCREMENT PRIMARY KEY,
    creator_id INT NOT NULL,
    itinerary_id INT,
    group_name VARCHAR(100) NOT NULL,
    description TEXT,
    max_members INT DEFAULT 10,
    current_members INT DEFAULT 1,
    is_active BOOLEAN DEFAULT TRUE,
    join_code VARCHAR(20) UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (creator_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (itinerary_id) REFERENCES itineraries(id) ON DELETE SET NULL,
    INDEX idx_creator_id (creator_id),
    INDEX idx_join_code (join_code),
    INDEX idx_active (is_active)
);

-- =============================================
-- GROUP_MEMBERS TABLE (Group Travel Participants)
-- =============================================
CREATE TABLE group_members (
    id INT AUTO_INCREMENT PRIMARY KEY,
    group_id INT NOT NULL,
    user_id INT NOT NULL,
    role ENUM('creator', 'admin', 'member') DEFAULT 'member',
    joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_active BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (group_id) REFERENCES group_travels(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_group_user (group_id, user_id),
    INDEX idx_group_id (group_id),
    INDEX idx_user_id (user_id),
    INDEX idx_role (role)
);

-- =============================================
-- SAVED_PLACES TABLE (User's Saved Locations)
-- =============================================
CREATE TABLE saved_places (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    location VARCHAR(200) NOT NULL,
    address TEXT,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    place_type ENUM('restaurant', 'attraction', 'hotel', 'activity', 'other') NOT NULL,
    rating DECIMAL(3,2),
    price_level INT,
    website VARCHAR(255),
    phone VARCHAR(20),
    notes TEXT,
    tags JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_place_type (place_type),
    INDEX idx_location (location)
);

-- =============================================
-- BUSINESS_SERVICES TABLE (Services Offered by Businesses)
-- =============================================
CREATE TABLE business_services (
    id INT AUTO_INCREMENT PRIMARY KEY,
    business_id INT NOT NULL,
    service_name VARCHAR(200) NOT NULL,
    service_type ENUM('accommodation', 'restaurant', 'tour', 'transport', 'activity', 'other') NOT NULL,
    description TEXT,
    price DECIMAL(10,2),
    currency VARCHAR(3) DEFAULT 'USD',
    duration_hours DECIMAL(5,2),
    capacity INT,
    location VARCHAR(200),
    address TEXT,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    amenities JSON,
    availability_schedule JSON,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
    INDEX idx_business_id (business_id),
    INDEX idx_service_type (service_type),
    INDEX idx_active (is_active),
    INDEX idx_location (location)
);

-- =============================================
-- BOOKINGS TABLE (User Bookings with Businesses)
-- =============================================
CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    business_id INT NOT NULL,
    service_id INT,
    itinerary_id INT,
    booking_reference VARCHAR(50) UNIQUE NOT NULL,
    service_name VARCHAR(200) NOT NULL,
    booking_date DATE NOT NULL,
    check_in_date DATE,
    check_out_date DATE,
    quantity INT DEFAULT 1,
    total_amount DECIMAL(10,2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'USD',
    status ENUM('pending', 'confirmed', 'cancelled', 'completed', 'refunded') DEFAULT 'pending',
    payment_status ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending',
    payment_method VARCHAR(50),
    payment_reference VARCHAR(100),
    special_requests TEXT,
    cancellation_policy TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
    FOREIGN KEY (service_id) REFERENCES business_services(id) ON DELETE SET NULL,
    FOREIGN KEY (itinerary_id) REFERENCES itineraries(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_business_id (business_id),
    INDEX idx_booking_reference (booking_reference),
    INDEX idx_booking_date (booking_date),
    INDEX idx_status (status),
    INDEX idx_payment_status (payment_status)
);

-- =============================================
-- REVIEWS TABLE (User Reviews for Businesses)
-- =============================================
CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    business_id INT NOT NULL,
    booking_id INT,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    title VARCHAR(200),
    comment TEXT,
    is_verified BOOLEAN DEFAULT FALSE,
    is_public BOOLEAN DEFAULT TRUE,
    helpful_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
    FOREIGN KEY (booking_id) REFERENCES bookings(id) ON DELETE SET NULL,
    UNIQUE KEY unique_user_business_booking (user_id, business_id, booking_id),
    INDEX idx_user_id (user_id),
    INDEX idx_business_id (business_id),
    INDEX idx_rating (rating),
    INDEX idx_created_at (created_at)
);

-- =============================================
-- ANALYTICS TABLE (Business Performance Data)
-- =============================================
CREATE TABLE analytics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    business_id INT NOT NULL,
    metric_type ENUM('views', 'bookings', 'revenue', 'reviews', 'rating') NOT NULL,
    metric_value DECIMAL(15,2) NOT NULL,
    date_recorded DATE NOT NULL,
    additional_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
    INDEX idx_business_id (business_id),
    INDEX idx_metric_type (metric_type),
    INDEX idx_date_recorded (date_recorded)
);

-- =============================================
-- NOTIFICATIONS TABLE (System Notifications)
-- =============================================
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    business_id INT,
    type ENUM('booking', 'payment', 'review', 'system', 'promotion') NOT NULL,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    action_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    read_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_business_id (business_id),
    INDEX idx_type (type),
    INDEX idx_is_read (is_read),
    INDEX idx_created_at (created_at)
);

-- =============================================
-- SESSIONS TABLE (User Sessions)
-- =============================================
CREATE TABLE sessions (
    id VARCHAR(128) PRIMARY KEY,
    user_id INT,
    business_id INT,
    user_type ENUM('personal', 'business') NOT NULL,
    ip_address VARCHAR(45),
    user_agent TEXT,
    last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_business_id (business_id),
    INDEX idx_last_activity (last_activity)
);

-- =============================================
-- INSERT SAMPLE DATA
-- =============================================

-- Insert sample users
INSERT INTO users (first_name, last_name, email, password, phone, is_active, email_verified) VALUES
('John', 'Doe', 'john.doe@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '+1234567890', TRUE, TRUE),
('Jane', 'Smith', 'jane.smith@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '+1234567891', TRUE, TRUE),
('Mike', 'Johnson', 'mike.johnson@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '+1234567892', TRUE, TRUE);

-- Insert sample businesses
INSERT INTO businesses (business_name, business_type, contact_first_name, contact_last_name, email, password, phone, city, country, is_active, is_verified, email_verified) VALUES
('Grand Hotel Paris', 'hotel', 'Marie', 'Dubois', 'contact@grandhotelparis.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '+33123456789', 'Paris', 'France', TRUE, TRUE, TRUE),
('Tokyo Sushi Bar', 'restaurant', 'Hiroshi', 'Tanaka', 'info@tokyosushibar.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '+81312345678', 'Tokyo', 'Japan', TRUE, TRUE, TRUE),
('Adventure Tours NYC', 'tour', 'Sarah', 'Wilson', 'bookings@adventuretoursnyc.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '+12125551234', 'New York', 'USA', TRUE, TRUE, TRUE);

-- Insert sample itineraries
INSERT INTO itineraries (user_id, title, description, destination, start_date, end_date, budget, status) VALUES
(1, 'Paris Adventure', 'A romantic getaway to the City of Light', 'Paris, France', '2024-06-01', '2024-06-07', 2500.00, 'planning'),
(2, 'Tokyo Food Tour', 'Exploring the culinary delights of Tokyo', 'Tokyo, Japan', '2024-07-15', '2024-07-22', 3000.00, 'confirmed'),
(3, 'NYC Weekend', 'Quick weekend trip to New York', 'New York, USA', '2024-05-10', '2024-05-12', 800.00, 'completed');

-- Insert sample business services
INSERT INTO business_services (business_id, service_name, service_type, description, price, duration_hours, location, is_active) VALUES
(1, 'Deluxe Room', 'accommodation', 'Spacious room with city view', 200.00, 24.00, 'Paris, France', TRUE),
(1, 'Spa Package', 'activity', 'Relaxing spa treatment', 150.00, 2.00, 'Paris, France', TRUE),
(2, 'Omakase Dinner', 'restaurant', 'Chef\'s choice sushi experience', 120.00, 2.00, 'Tokyo, Japan', TRUE),
(3, 'City Walking Tour', 'tour', 'Guided walking tour of Manhattan', 50.00, 3.00, 'New York, USA', TRUE);

-- Insert sample saved places
INSERT INTO saved_places (user_id, name, description, location, place_type, rating, notes) VALUES
(1, 'Eiffel Tower', 'Iconic iron lattice tower', 'Paris, France', 'attraction', 4.8, 'Must visit at sunset'),
(2, 'Tsukiji Fish Market', 'Famous fish market', 'Tokyo, Japan', 'attraction', 4.5, 'Best sushi in the world'),
(3, 'Central Park', 'Large public park', 'New York, USA', 'attraction', 4.7, 'Great for morning runs');

-- =============================================
-- CREATE VIEWS FOR COMMON QUERIES
-- =============================================

-- View for user dashboard data
CREATE VIEW user_dashboard_data AS
SELECT 
    u.id,
    u.first_name,
    u.last_name,
    u.email,
    COUNT(DISTINCT i.id) as total_itineraries,
    COUNT(DISTINCT sp.id) as total_saved_places,
    COUNT(DISTINCT gt.id) as total_group_travels,
    u.last_login
FROM users u
LEFT JOIN itineraries i ON u.id = i.user_id
LEFT JOIN saved_places sp ON u.id = sp.user_id
LEFT JOIN group_travels gt ON u.id = gt.creator_id
WHERE u.is_active = TRUE
GROUP BY u.id;

-- View for business dashboard data
CREATE VIEW business_dashboard_data AS
SELECT 
    b.id,
    b.business_name,
    b.business_type,
    b.email,
    COUNT(DISTINCT bs.id) as total_services,
    COUNT(DISTINCT bk.id) as total_bookings,
    AVG(r.rating) as average_rating,
    COUNT(DISTINCT r.id) as total_reviews,
    b.last_login
FROM businesses b
LEFT JOIN business_services bs ON b.id = bs.business_id AND bs.is_active = TRUE
LEFT JOIN bookings bk ON b.id = bk.business_id
LEFT JOIN reviews r ON b.id = r.business_id
WHERE b.is_active = TRUE
GROUP BY b.id;

-- =============================================
-- CREATE STORED PROCEDURES
-- =============================================

-- Procedure to get user statistics
DELIMITER //
CREATE PROCEDURE GetUserStats(IN user_id INT)
BEGIN
    SELECT 
        (SELECT COUNT(*) FROM itineraries WHERE user_id = user_id) as itinerary_count,
        (SELECT COUNT(*) FROM saved_places WHERE user_id = user_id) as saved_places_count,
        (SELECT COUNT(*) FROM group_travels WHERE creator_id = user_id) as group_travels_count,
        (SELECT COUNT(*) FROM bookings WHERE user_id = user_id) as booking_count;
END //
DELIMITER ;

-- Procedure to get business statistics
DELIMITER //
CREATE PROCEDURE GetBusinessStats(IN business_id INT)
BEGIN
    SELECT 
        (SELECT COUNT(*) FROM business_services WHERE business_id = business_id AND is_active = TRUE) as services_count,
        (SELECT COUNT(*) FROM bookings WHERE business_id = business_id) as bookings_count,
        (SELECT AVG(rating) FROM reviews WHERE business_id = business_id) as average_rating,
        (SELECT COUNT(*) FROM reviews WHERE business_id = business_id) as reviews_count;
END //
DELIMITER ;

-- =============================================
-- CREATE TRIGGERS
-- =============================================

-- Trigger to update group member count
DELIMITER //
CREATE TRIGGER update_group_member_count
AFTER INSERT ON group_members
FOR EACH ROW
BEGIN
    UPDATE group_travels 
    SET current_members = current_members + 1 
    WHERE id = NEW.group_id;
END //
DELIMITER ;

-- Trigger to decrease group member count
DELIMITER //
CREATE TRIGGER decrease_group_member_count
AFTER DELETE ON group_members
FOR EACH ROW
BEGIN
    UPDATE group_travels 
    SET current_members = current_members - 1 
    WHERE id = OLD.group_id;
END //
DELIMITER ;

-- =============================================
-- CREATE INDEXES FOR PERFORMANCE
-- =============================================

-- Additional indexes for better performance
CREATE INDEX idx_itineraries_user_dates ON itineraries(user_id, start_date, end_date);
CREATE INDEX idx_bookings_user_date ON bookings(user_id, booking_date);
CREATE INDEX idx_reviews_business_rating ON reviews(business_id, rating);
CREATE INDEX idx_notifications_user_read ON notifications(user_id, is_read, created_at);

-- =============================================
-- GRANT PERMISSIONS (Adjust as needed)
-- =============================================

-- Create application user (uncomment and modify as needed)
-- CREATE USER 'navigo_user'@'localhost' IDENTIFIED BY 'secure_password';
-- GRANT SELECT, INSERT, UPDATE, DELETE ON navigo_db.* TO 'navigo_user'@'localhost';
-- FLUSH PRIVILEGES;

-- =============================================
-- END OF DATABASE SCHEMA
-- =============================================
