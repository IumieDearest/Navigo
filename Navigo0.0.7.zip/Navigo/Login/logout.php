<?php
session_start();

// Debug: Log logout attempt
error_log("Logout attempt from: " . ($_SERVER['HTTP_REFERER'] ?? 'unknown'));

// Clear all business-related session variables
unset($_SESSION['business_id']);
unset($_SESSION['user_type']);
unset($_SESSION['business_email']);
unset($_SESSION['business_name']);
unset($_SESSION['business_type']);

// Clear any other session variables if they exist
unset($_SESSION['user_id']);
unset($_SESSION['admin_id']);

// Destroy all session data
session_destroy();

// Clear any cookies if needed
if (isset($_COOKIE[session_name()])) {
    setcookie(session_name(), '', time() - 3600, '/');
}

// Redirect to home page
header('Location: ../Index.php');
exit();
?>
