/**
 * Business Dashboard Navigation System
 * Handles all navigation and button functionality across business dashboards
 */

class BusinessNavigation {
    constructor() {
        this.currentBusinessType = this.getBusinessType();
        this.init();
    }

    init() {
        this.setupSidebarNavigation();
        this.setupActionButtons();
        this.setupSearch();
        this.setupMobileMenu();
    }

    getBusinessType() {
        const path = window.location.pathname;
        if (path.includes('airlines-dashboard')) return 'airlines';
        if (path.includes('hotels-dashboard')) return 'hotels';
        if (path.includes('tour-operator-dashboard')) return 'tour-operator';
        if (path.includes('transportation-dashboard')) return 'transportation';
        if (path.includes('other-dashboard')) return 'other';
        return 'other';
    }

    setupSidebarNavigation() {
        const navItems = document.querySelectorAll('.nav-item');
        navItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const text = item.textContent.trim();
                this.navigateToPage(text);
            });
        });
    }

    setupActionButtons() {
        const actionButtons = document.querySelectorAll('.btn-primary');
        actionButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                const text = button.textContent.trim();
                this.handleActionButton(text);
            });
        });
    }

    setupSearch() {
        const searchInputs = document.querySelectorAll('.header-search input');
        searchInputs.forEach(input => {
            input.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.performSearch(input.value);
                }
            });
        });
    }

    setupMobileMenu() {
        // Mobile menu toggle functionality
        const mobileMenuButton = document.querySelector('.mobile-menu-button');
        if (mobileMenuButton) {
            mobileMenuButton.addEventListener('click', () => {
                document.querySelector('.dashboard-sidebar').classList.toggle('open');
            });
        }
    }

    navigateToPage(pageName) {
        const pageMap = {
            'Dashboard': 'index.php',
            'Flights': 'flights.php',
            'Rooms': 'rooms.php',
            'Tour Packages': 'tour-packages.php',
            'Fleet': 'fleet.php',
            'Services': 'services.php',
            'Bookings': 'bookings.php',
            'Analytics': 'analytics.php',
            'Passengers': 'passengers.php',
            'Guests': 'guests.php',
            'Tour Guides': 'tour-guides.php',
            'Drivers': 'drivers.php',
            'Customers': 'customers.php',
            'Reviews': 'reviews.php',
            'Settings': 'settings.php'
        };

        const fileName = pageMap[pageName] || 'index.php';
        
        // Update active nav item
        this.updateActiveNavItem(pageName);
        
        // Navigate to page using relative path
        window.location.href = fileName;
    }

    handleActionButton(buttonText) {
        const actionMap = {
            'Add Flight': 'add-flight.php',
            'Add Room': 'add-room.php',
            'Create Tour': 'create-tour.php',
            'Add Vehicle': 'add-vehicle.php',
            'Add Service': 'add-service.php'
        };

        const fileName = actionMap[buttonText] || 'index.php';
        
        window.location.href = fileName;
    }

    performSearch(query) {
        if (!query.trim()) return;
        
        const url = `search.php?q=${encodeURIComponent(query)}`;
        
        window.location.href = url;
    }

    updateActiveNavItem(activePage) {
        const navItems = document.querySelectorAll('.nav-item');
        navItems.forEach(item => {
            item.classList.remove('active');
            if (item.textContent.trim() === activePage) {
                item.classList.add('active');
            }
        });
    }

    // Utility method to show loading state
    showLoading(element) {
        const originalText = element.textContent;
        element.textContent = 'Loading...';
        element.disabled = true;
        
        return () => {
            element.textContent = originalText;
            element.disabled = false;
        };
    }

    // Utility method to show notifications
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.textContent = message;
        
        // Add to page
        document.body.appendChild(notification);
        
        // Auto remove after 3 seconds
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
}

// Initialize navigation when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new BusinessNavigation();
});

// Mobile sidebar toggle function (for backward compatibility)
function toggleSidebar() {
    document.querySelector('.dashboard-sidebar').classList.toggle('open');
}
