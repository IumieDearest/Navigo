<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check if business is logged in
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}

$business = get_business_by_id($_SESSION['business_id']);
if (!$business) {
    header('Location: ../../Login/business_login.php');
    exit();
}

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $business_name = sanitize_input($_POST['business_name']);
    $contact_email = sanitize_input($_POST['contact_email']);
    $phone = sanitize_input($_POST['phone']);
    $address = sanitize_input($_POST['address']);
    
    // Basic validation
    if (empty($business_name) || empty($contact_email)) {
        $error_message = 'Please fill in all required fields.';
    } else {
        // Here you would typically update the database
        $success_message = 'Settings updated successfully!';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - NaviGo Airlines</title>
    
    <!-- External Resources -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Stylesheets -->
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    
    <!-- Scripts -->
    <script src="../../js/dark-mode.js"></script>
    <script src="../../js/business-navigation.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <nav class="dashboard-sidebar">
            <div class="sidebar-header">
                <a href="../../Index.php" class="sidebar-logo">
                    <img src="../../Assets/Images/NaviGo_Logo.png" alt="NaviGo">
                    <span>NaviGo Airlines</span>
                </a>
            </div>
            
            <div class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-section-title">Main</div>
                    <a href="index.php" class="nav-item">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                    <a href="flights.php" class="nav-item">
                        <i class="fas fa-plane"></i>
                        Flights
                    </a>
                    <a href="bookings.php" class="nav-item">
                        <i class="fas fa-ticket-alt"></i>
                        Bookings
                    </a>
                    <a href="analytics.php" class="nav-item">
                        <i class="fas fa-chart-line"></i>
                        Analytics
                    </a>
                </div>
                
                <div class="nav-section">
                    <div class="nav-section-title">Management</div>
                    <a href="passengers.php" class="nav-item">
                        <i class="fas fa-users"></i>
                        Passengers
                    </a>
                    <a href="reviews.php" class="nav-item">
                        <i class="fas fa-star"></i>
                        Reviews
                    </a>
                    <a href="#" class="nav-item active">
                        <i class="fas fa-cog"></i>
                        Settings
                    </a>
                </div>
            </div>
        </nav>
        
        <!-- Main Content -->
        <main class="dashboard-main">
            <!-- Dark Mode Toggle -->
            <button class="dark-mode-toggle" style="position: fixed; top: 20px; left: 300px; z-index: 1000; background: var(--white); border: 1px solid var(--gray-300); border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; box-shadow: var(--shadow-sm); cursor: pointer; transition: all 0.3s ease; font-size: 14px;">
                <i class="fas fa-moon"></i>
            </button>
            
            <!-- Header -->
            <div class="dashboard-header">
                <div class="header-content">
                    <h1 class="header-title">Settings</h1>
                    <div class="header-actions">
                        <button class="btn btn-secondary" onclick="window.location.href='index.php'">
                            <i class="fas fa-arrow-left"></i>
                            Back to Dashboard
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Dashboard Content -->
            <div class="dashboard-content">
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-xl);">
                    <!-- Business Information -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Business Information</h3>
                            <p class="card-subtitle">Update your business details</p>
                        </div>
                        <div class="card-body">
                            <?php if ($error_message): ?>
                                <div class="alert alert-error mb-4">
                                    <i class="fas fa-exclamation-circle"></i>
                                    <?php echo htmlspecialchars($error_message); ?>
                                </div>
                            <?php endif; ?>

                            <?php if ($success_message): ?>
                                <div class="alert alert-success mb-4">
                                    <i class="fas fa-check-circle"></i>
                                    <?php echo htmlspecialchars($success_message); ?>
                                </div>
                            <?php endif; ?>

                            <form method="POST" action="settings.php">
                                <div class="space-y-4">
                                    <div>
                                        <label class="text-sm font-medium mb-1">Business Name *</label>
                                        <input type="text" name="business_name" required 
                                               value="<?php echo htmlspecialchars($business['business_name']); ?>"
                                               style="width: 100%; padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                    </div>
                                    
                                    <div>
                                        <label class="text-sm font-medium mb-1">Contact Email *</label>
                                        <input type="email" name="contact_email" required 
                                               value="<?php echo htmlspecialchars($business['email']); ?>"
                                               style="width: 100%; padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                    </div>
                                    
                                    <div>
                                        <label class="text-sm font-medium mb-1">Phone Number</label>
                                        <input type="tel" name="phone" 
                                               value="<?php echo htmlspecialchars($business['phone']); ?>"
                                               style="width: 100%; padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                    </div>
                                    
                                    <div>
                                        <label class="text-sm font-medium mb-1">Address</label>
                                        <textarea name="address" rows="3" 
                                                  style="width: 100%; padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);"><?php echo htmlspecialchars($business['address'] ?? ''); ?></textarea>
                                    </div>
                                </div>
                                
                                <div class="flex gap-3 mt-5">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save"></i>
                                        Save Changes
                                    </button>
                                    <button type="button" class="btn btn-secondary">
                                        <i class="fas fa-undo"></i>
                                        Reset
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Account Settings -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Account Settings</h3>
                            <p class="card-subtitle">Manage your account preferences</p>
                        </div>
                        <div class="card-body">
                            <div class="space-y-4">
                                <div class="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                    <div>
                                        <div class="font-medium">Change Password</div>
                                        <div class="text-sm text-gray-500">Update your account password</div>
                                    </div>
                                    <button class="btn btn-sm btn-secondary">
                                        <i class="fas fa-key"></i>
                                        Change
                                    </button>
                                </div>
                                
                                <div class="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                    <div>
                                        <div class="font-medium">Two-Factor Authentication</div>
                                        <div class="text-sm text-gray-500">Add extra security to your account</div>
                                    </div>
                                    <button class="btn btn-sm btn-secondary">
                                        <i class="fas fa-shield-alt"></i>
                                        Setup
                                    </button>
                                </div>
                                
                                <div class="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                    <div>
                                        <div class="font-medium">Notification Settings</div>
                                        <div class="text-sm text-gray-500">Manage email and push notifications</div>
                                    </div>
                                    <button class="btn btn-sm btn-secondary">
                                        <i class="fas fa-bell"></i>
                                        Configure
                                    </button>
                                </div>
                                
                                <div class="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                    <div>
                                        <div class="font-medium">API Access</div>
                                        <div class="text-sm text-gray-500">Manage API keys and integrations</div>
                                    </div>
                                    <button class="btn btn-sm btn-secondary">
                                        <i class="fas fa-code"></i>
                                        Manage
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Danger Zone -->
                <div class="card mt-6" style="border-color: var(--error);">
                    <div class="card-header" style="background: rgb(239 68 68 / 0.05);">
                        <h3 class="card-title" style="color: var(--error);">Danger Zone</h3>
                        <p class="card-subtitle">Irreversible and destructive actions</p>
                    </div>
                    <div class="card-body">
                        <div class="flex justify-between items-center p-3 bg-red-50 rounded-lg">
                            <div>
                                <div class="font-medium text-red-800">Delete Account</div>
                                <div class="text-sm text-red-600">Permanently delete your business account and all data</div>
                            </div>
                            <button class="btn btn-error">
                                <i class="fas fa-trash"></i>
                                Delete Account
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
