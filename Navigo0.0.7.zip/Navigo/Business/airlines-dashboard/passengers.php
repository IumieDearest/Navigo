<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check if business is logged in
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}

$business = get_business_by_id($_SESSION['business_id']);
if (!$business) {
    header('Location: ../../Login/business_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passengers - NaviGo Airlines</title>
    
    <!-- External Resources -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Stylesheets -->
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    
    <!-- Scripts -->
    <script src="../../js/dark-mode.js"></script>
    <script src="../../js/business-navigation.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <nav class="dashboard-sidebar">
            <div class="sidebar-header">
                <a href="../../Index.php" class="sidebar-logo">
                    <img src="../../Assets/Images/NaviGo_Logo.png" alt="NaviGo">
                    <span>NaviGo Airlines</span>
                </a>
            </div>
            
            <div class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-section-title">Main</div>
                    <a href="index.php" class="nav-item">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                    <a href="flights.php" class="nav-item">
                        <i class="fas fa-plane"></i>
                        Flights
                    </a>
                    <a href="bookings.php" class="nav-item">
                        <i class="fas fa-ticket-alt"></i>
                        Bookings
                    </a>
                    <a href="analytics.php" class="nav-item">
                        <i class="fas fa-chart-line"></i>
                        Analytics
                    </a>
                </div>
                
                <div class="nav-section">
                    <div class="nav-section-title">Management</div>
                    <a href="#" class="nav-item active">
                        <i class="fas fa-users"></i>
                        Passengers
                    </a>
                    <a href="reviews.php" class="nav-item">
                        <i class="fas fa-star"></i>
                        Reviews
                    </a>
                    <a href="settings.php" class="nav-item">
                        <i class="fas fa-cog"></i>
                        Settings
                    </a>
                </div>
            </div>
        </nav>
        
        <!-- Main Content -->
        <main class="dashboard-main">
            <!-- Dark Mode Toggle -->
            <button class="dark-mode-toggle" style="position: fixed; top: 20px; left: 300px; z-index: 1000; background: var(--white); border: 1px solid var(--gray-300); border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; box-shadow: var(--shadow-sm); cursor: pointer; transition: all 0.3s ease; font-size: 14px;">
                <i class="fas fa-moon"></i>
            </button>
            
            <!-- Header -->
            <div class="dashboard-header">
                <div class="header-content">
                    <h1 class="header-title">Passenger Management</h1>
                    <div class="header-actions">
                        <div class="header-search">
                            <i class="fas fa-search"></i>
                            <input type="text" placeholder="Search passengers...">
                        </div>
                        <button class="btn btn-primary">
                            <i class="fas fa-plus"></i>
                            Add Passenger
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Dashboard Content -->
            <div class="dashboard-content">
                <!-- Passenger Stats -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-header">
                            <div>
                                <div class="stat-value">8,934</div>
                                <div class="stat-label">Total Passengers</div>
                            </div>
                            <div class="stat-icon primary">
                                <i class="fas fa-users"></i>
                            </div>
                        </div>
                        <div class="stat-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +8% from last month
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-header">
                            <div>
                                <div class="stat-value">2,456</div>
                                <div class="stat-label">Frequent Flyers</div>
                            </div>
                            <div class="stat-icon success">
                                <i class="fas fa-star"></i>
                            </div>
                        </div>
                        <div class="stat-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +12% from last month
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-header">
                            <div>
                                <div class="stat-value">4.8</div>
                                <div class="stat-label">Avg. Satisfaction</div>
                            </div>
                            <div class="stat-icon warning">
                                <i class="fas fa-smile"></i>
                            </div>
                        </div>
                        <div class="stat-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +0.2 from last month
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-header">
                            <div>
                                <div class="stat-value">89%</div>
                                <div class="stat-label">Retention Rate</div>
                            </div>
                            <div class="stat-icon info">
                                <i class="fas fa-heart"></i>
                            </div>
                        </div>
                        <div class="stat-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +3% from last month
                        </div>
                    </div>
                </div>

                <!-- Passenger Filters -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: var(--space-md);">
                            <div>
                                <label class="text-sm font-medium mb-1">Status</label>
                                <select class="w-full" style="padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                    <option>All Passengers</option>
                                    <option>Active</option>
                                    <option>Frequent Flyers</option>
                                    <option>VIP</option>
                                    <option>Inactive</option>
                                </select>
                            </div>
                            <div>
                                <label class="text-sm font-medium mb-1">Tier</label>
                                <select class="w-full" style="padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                    <option>All Tiers</option>
                                    <option>Gold</option>
                                    <option>Silver</option>
                                    <option>Bronze</option>
                                    <option>Basic</option>
                                </select>
                            </div>
                            <div>
                                <label class="text-sm font-medium mb-1">Last Flight</label>
                                <select class="w-full" style="padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                    <option>Any Time</option>
                                    <option>Last 7 Days</option>
                                    <option>Last 30 Days</option>
                                    <option>Last 90 Days</option>
                                </select>
                            </div>
                            <div class="flex items-end">
                                <button class="btn btn-primary w-full">
                                    <i class="fas fa-filter"></i>
                                    Apply Filters
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Passengers Table -->
                <div class="table-container">
                    <div class="table-header">
                        <h3 class="table-title">Passenger List</h3>
                        <div class="flex gap-2">
                            <button class="btn btn-sm btn-secondary">
                                <i class="fas fa-download"></i>
                                Export
                            </button>
                            <button class="btn btn-sm btn-secondary">
                                <i class="fas fa-envelope"></i>
                                Send Email
                            </button>
                        </div>
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Passenger</th>
                                <th>Email</th>
                                <th>Tier</th>
                                <th>Total Flights</th>
                                <th>Last Flight</th>
                                <th>Total Spent</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="flex items-center gap-3">
                                        <div style="width: 40px; height: 40px; background: var(--primary-blue); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                                            JD
                                        </div>
                                        <div>
                                            <div class="font-medium">John Doe</div>
                                            <div class="text-sm text-gray-500">ID: #P001</div>
                                        </div>
                                    </div>
                                </td>
                                <td>john.doe@email.com</td>
                                <td><span class="badge badge-warning">Gold</span></td>
                                <td>45</td>
                                <td>2024-01-15</td>
                                <td>$12,450</td>
                                <td><span class="badge badge-success">Active</span></td>
                                <td>
                                    <div class="flex gap-1">
                                        <button class="btn btn-sm btn-secondary" title="View Profile">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-primary" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-success" title="Message">
                                            <i class="fas fa-envelope"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="flex items-center gap-3">
                                        <div style="width: 40px; height: 40px; background: var(--success); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                                            JS
                                        </div>
                                        <div>
                                            <div class="font-medium">Jane Smith</div>
                                            <div class="text-sm text-gray-500">ID: #P002</div>
                                        </div>
                                    </div>
                                </td>
                                <td>jane.smith@email.com</td>
                                <td><span class="badge badge-gray">Silver</span></td>
                                <td>23</td>
                                <td>2024-01-16</td>
                                <td>$6,780</td>
                                <td><span class="badge badge-success">Active</span></td>
                                <td>
                                    <div class="flex gap-1">
                                        <button class="btn btn-sm btn-secondary" title="View Profile">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-primary" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-success" title="Message">
                                            <i class="fas fa-envelope"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="flex items-center gap-3">
                                        <div style="width: 40px; height: 40px; background: var(--warning); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                                            MJ
                                        </div>
                                        <div>
                                            <div class="font-medium">Mike Johnson</div>
                                            <div class="text-sm text-gray-500">ID: #P003</div>
                                        </div>
                                    </div>
                                </td>
                                <td>mike.johnson@email.com</td>
                                <td><span class="badge badge-info">Bronze</span></td>
                                <td>12</td>
                                <td>2024-01-17</td>
                                <td>$3,240</td>
                                <td><span class="badge badge-success">Active</span></td>
                                <td>
                                    <div class="flex gap-1">
                                        <button class="btn btn-sm btn-secondary" title="View Profile">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-primary" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-success" title="Message">
                                            <i class="fas fa-envelope"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="flex items-center gap-3">
                                        <div style="width: 40px; height: 40px; background: var(--error); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: bold;">
                                            SW
                                        </div>
                                        <div>
                                            <div class="font-medium">Sarah Wilson</div>
                                            <div class="text-sm text-gray-500">ID: #P004</div>
                                        </div>
                                    </div>
                                </td>
                                <td>sarah.wilson@email.com</td>
                                <td><span class="badge badge-gray">Basic</span></td>
                                <td>3</td>
                                <td>2023-12-15</td>
                                <td>$890</td>
                                <td><span class="badge badge-warning">Inactive</span></td>
                                <td>
                                    <div class="flex gap-1">
                                        <button class="btn btn-sm btn-secondary" title="View Profile">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-primary" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-success" title="Message">
                                            <i class="fas fa-envelope"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
