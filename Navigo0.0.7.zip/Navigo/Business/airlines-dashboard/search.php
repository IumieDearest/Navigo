<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check if business is logged in
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}

$business = get_business_by_id($_SESSION['business_id']);
if (!$business) {
    header('Location: ../../Login/business_login.php');
    exit();
}

$search_query = isset($_GET['q']) ? sanitize_input($_GET['q']) : '';
$search_results = [];

// Mock search results - in real implementation, this would query the database
if (!empty($search_query)) {
    $search_results = [
        'flights' => [
            ['id' => 'NAV-101', 'route' => 'NYC → LAX', 'departure' => '08:00 AM', 'status' => 'On Time'],
            ['id' => 'NAV-102', 'route' => 'LAX → CHI', 'departure' => '02:00 PM', 'status' => 'Delayed']
        ],
        'bookings' => [
            ['id' => 'NAV-001', 'passenger' => 'John Doe', 'flight' => 'NAV-101', 'amount' => '$450'],
            ['id' => 'NAV-002', 'passenger' => 'Jane Smith', 'flight' => 'NAV-102', 'amount' => '$320']
        ],
        'passengers' => [
            ['id' => 'P001', 'name' => 'John Doe', 'email' => 'john.doe@email.com', 'tier' => 'Gold'],
            ['id' => 'P002', 'name' => 'Jane Smith', 'email' => 'jane.smith@email.com', 'tier' => 'Silver']
        ]
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results - NaviGo Airlines</title>
    
    <!-- External Resources -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Stylesheets -->
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    
    <!-- Scripts -->
    <script src="../../js/dark-mode.js"></script>
    <script src="../../js/business-navigation.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <nav class="dashboard-sidebar">
            <div class="sidebar-header">
                <a href="../../Index.php" class="sidebar-logo">
                    <img src="../../Assets/Images/NaviGo_Logo.png" alt="NaviGo">
                    <span>NaviGo Airlines</span>
                </a>
            </div>
            
            <div class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-section-title">Main</div>
                    <a href="index.php" class="nav-item">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                    <a href="flights.php" class="nav-item">
                        <i class="fas fa-plane"></i>
                        Flights
                    </a>
                    <a href="bookings.php" class="nav-item">
                        <i class="fas fa-ticket-alt"></i>
                        Bookings
                    </a>
                    <a href="analytics.php" class="nav-item">
                        <i class="fas fa-chart-line"></i>
                        Analytics
                    </a>
                </div>
                
                <div class="nav-section">
                    <div class="nav-section-title">Management</div>
                    <a href="passengers.php" class="nav-item">
                        <i class="fas fa-users"></i>
                        Passengers
                    </a>
                    <a href="reviews.php" class="nav-item">
                        <i class="fas fa-star"></i>
                        Reviews
                    </a>
                    <a href="settings.php" class="nav-item">
                        <i class="fas fa-cog"></i>
                        Settings
                    </a>
                </div>
            </div>
        </nav>
        
        <!-- Main Content -->
        <main class="dashboard-main">
            <!-- Dark Mode Toggle -->
            <button class="dark-mode-toggle" style="position: fixed; top: 20px; left: 300px; z-index: 1000; background: var(--white); border: 1px solid var(--gray-300); border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; box-shadow: var(--shadow-sm); cursor: pointer; transition: all 0.3s ease; font-size: 14px;">
                <i class="fas fa-moon"></i>
            </button>
            
            <!-- Header -->
            <div class="dashboard-header">
                <div class="header-content">
                    <h1 class="header-title">Search Results</h1>
                    <div class="header-actions">
                        <div class="header-search">
                            <i class="fas fa-search"></i>
                            <input type="text" placeholder="Search again..." value="<?php echo htmlspecialchars($search_query); ?>">
                        </div>
                        <button class="btn btn-secondary" onclick="window.location.href='index.php'">
                            <i class="fas fa-arrow-left"></i>
                            Back to Dashboard
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Dashboard Content -->
            <div class="dashboard-content">
                <?php if (empty($search_query)): ?>
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-search" style="font-size: 3rem; color: var(--gray-300); margin-bottom: var(--space-md);"></i>
                            <h3 class="text-lg font-semibold mb-2">Enter a search term</h3>
                            <p class="text-gray-500">Search for flights, bookings, passengers, and more.</p>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="mb-4">
                        <p class="text-gray-600">Search results for: <strong>"<?php echo htmlspecialchars($search_query); ?>"</strong></p>
                    </div>

                    <!-- Flights Results -->
                    <?php if (!empty($search_results['flights'])): ?>
                        <div class="card mb-4">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <i class="fas fa-plane mr-2"></i>
                                    Flights (<?php echo count($search_results['flights']); ?>)
                                </h3>
                            </div>
                            <div class="card-body">
                                <div class="space-y-3">
                                    <?php foreach ($search_results['flights'] as $flight): ?>
                                        <div class="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                            <div>
                                                <div class="font-semibold"><?php echo htmlspecialchars($flight['id']); ?></div>
                                                <div class="text-sm text-gray-500"><?php echo htmlspecialchars($flight['route']); ?></div>
                                            </div>
                                            <div class="text-right">
                                                <div class="text-sm"><?php echo htmlspecialchars($flight['departure']); ?></div>
                                                <span class="badge badge-success"><?php echo htmlspecialchars($flight['status']); ?></span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Bookings Results -->
                    <?php if (!empty($search_results['bookings'])): ?>
                        <div class="card mb-4">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <i class="fas fa-ticket-alt mr-2"></i>
                                    Bookings (<?php echo count($search_results['bookings']); ?>)
                                </h3>
                            </div>
                            <div class="card-body">
                                <div class="space-y-3">
                                    <?php foreach ($search_results['bookings'] as $booking): ?>
                                        <div class="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                            <div>
                                                <div class="font-semibold"><?php echo htmlspecialchars($booking['id']); ?></div>
                                                <div class="text-sm text-gray-500"><?php echo htmlspecialchars($booking['passenger']); ?></div>
                                            </div>
                                            <div class="text-right">
                                                <div class="text-sm"><?php echo htmlspecialchars($booking['flight']); ?></div>
                                                <div class="font-semibold"><?php echo htmlspecialchars($booking['amount']); ?></div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Passengers Results -->
                    <?php if (!empty($search_results['passengers'])): ?>
                        <div class="card mb-4">
                            <div class="card-header">
                                <h3 class="card-title">
                                    <i class="fas fa-users mr-2"></i>
                                    Passengers (<?php echo count($search_results['passengers']); ?>)
                                </h3>
                            </div>
                            <div class="card-body">
                                <div class="space-y-3">
                                    <?php foreach ($search_results['passengers'] as $passenger): ?>
                                        <div class="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                                            <div>
                                                <div class="font-semibold"><?php echo htmlspecialchars($passenger['name']); ?></div>
                                                <div class="text-sm text-gray-500"><?php echo htmlspecialchars($passenger['email']); ?></div>
                                            </div>
                                            <div class="text-right">
                                                <div class="text-sm">ID: <?php echo htmlspecialchars($passenger['id']); ?></div>
                                                <span class="badge badge-warning"><?php echo htmlspecialchars($passenger['tier']); ?></span>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <?php if (empty($search_results['flights']) && empty($search_results['bookings']) && empty($search_results['passengers'])): ?>
                        <div class="card">
                            <div class="card-body text-center">
                                <i class="fas fa-search" style="font-size: 3rem; color: var(--gray-300); margin-bottom: var(--space-md);"></i>
                                <h3 class="text-lg font-semibold mb-2">No results found</h3>
                                <p class="text-gray-500">Try searching with different keywords or check your spelling.</p>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </main>
    </div>

    <script>
        // Handle search form submission
        document.querySelector('.header-search input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                const query = this.value.trim();
                if (query) {
                    window.location.href = 'search.php?q=' + encodeURIComponent(query);
                }
            }
        });
    </script>
</body>
</html>
