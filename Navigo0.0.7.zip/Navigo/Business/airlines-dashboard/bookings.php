<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check if business is logged in
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}

$business = get_business_by_id($_SESSION['business_id']);
if (!$business) {
    header('Location: ../../Login/business_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookings Management - NaviGo Airlines</title>
    
    <!-- External Resources -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Stylesheets -->
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    
    <!-- Scripts -->
    <script src="../../js/dark-mode.js"></script>
    <script src="../../js/business-navigation.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <nav class="dashboard-sidebar">
            <div class="sidebar-header">
                <a href="../../Index.php" class="sidebar-logo">
                    <img src="../../Assets/Images/NaviGo_Logo.png" alt="NaviGo">
                    <span>NaviGo Airlines</span>
                </a>
            </div>
            
            <div class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-section-title">Main</div>
                    <a href="index.php" class="nav-item">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                    <a href="flights.php" class="nav-item">
                        <i class="fas fa-plane"></i>
                        Flights
                    </a>
                    <a href="#" class="nav-item active">
                        <i class="fas fa-ticket-alt"></i>
                        Bookings
                    </a>
                    <a href="analytics.php" class="nav-item">
                        <i class="fas fa-chart-line"></i>
                        Analytics
                    </a>
                </div>
                
                <div class="nav-section">
                    <div class="nav-section-title">Management</div>
                    <a href="passengers.php" class="nav-item">
                        <i class="fas fa-users"></i>
                        Passengers
                    </a>
                    <a href="reviews.php" class="nav-item">
                        <i class="fas fa-star"></i>
                        Reviews
                    </a>
                    <a href="settings.php" class="nav-item">
                        <i class="fas fa-cog"></i>
                        Settings
                    </a>
                </div>
            </div>
        </nav>
        
        <!-- Main Content -->
        <main class="dashboard-main">
            <!-- Dark Mode Toggle -->
            <button class="dark-mode-toggle" style="position: fixed; top: 20px; left: 300px; z-index: 1000; background: var(--white); border: 1px solid var(--gray-300); border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; box-shadow: var(--shadow-sm); cursor: pointer; transition: all 0.3s ease; font-size: 14px;">
                <i class="fas fa-moon"></i>
            </button>
            
            <!-- Header -->
            <div class="dashboard-header">
                <div class="header-content">
                    <h1 class="header-title">Bookings Management</h1>
                    <div class="header-actions">
                        <div class="header-search">
                            <i class="fas fa-search"></i>
                            <input type="text" placeholder="Search bookings...">
                        </div>
                        <button class="btn btn-primary">
                            <i class="fas fa-download"></i>
                            Export Bookings
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Dashboard Content -->
            <div class="dashboard-content">
                <!-- Booking Stats -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-header">
                            <div>
                                <div class="stat-value">1,247</div>
                                <div class="stat-label">Total Bookings</div>
                            </div>
                            <div class="stat-icon primary">
                                <i class="fas fa-ticket-alt"></i>
                            </div>
                        </div>
                        <div class="stat-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +8% from last month
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-header">
                            <div>
                                <div class="stat-value">$2.4M</div>
                                <div class="stat-label">Total Revenue</div>
                            </div>
                            <div class="stat-icon success">
                                <i class="fas fa-dollar-sign"></i>
                            </div>
                        </div>
                        <div class="stat-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +15% from last month
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-header">
                            <div>
                                <div class="stat-value">89%</div>
                                <div class="stat-label">Booking Rate</div>
                            </div>
                            <div class="stat-icon warning">
                                <i class="fas fa-chart-pie"></i>
                            </div>
                        </div>
                        <div class="stat-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +3% from last month
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-header">
                            <div>
                                <div class="stat-value">4.8</div>
                                <div class="stat-label">Avg. Rating</div>
                            </div>
                            <div class="stat-icon info">
                                <i class="fas fa-star"></i>
                            </div>
                        </div>
                        <div class="stat-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +0.2 from last month
                        </div>
                    </div>
                </div>

                <!-- Booking Filters -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: var(--space-md);">
                            <div>
                                <label class="text-sm font-medium mb-1">Status</label>
                                <select class="w-full" style="padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                    <option>All Status</option>
                                    <option>Confirmed</option>
                                    <option>Pending</option>
                                    <option>Cancelled</option>
                                    <option>Refunded</option>
                                </select>
                            </div>
                            <div>
                                <label class="text-sm font-medium mb-1">Flight</label>
                                <select class="w-full" style="padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                    <option>All Flights</option>
                                    <option>NAV-101</option>
                                    <option>NAV-102</option>
                                    <option>NAV-103</option>
                                    <option>NAV-104</option>
                                </select>
                            </div>
                            <div>
                                <label class="text-sm font-medium mb-1">Date Range</label>
                                <input type="date" class="w-full" style="padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                            </div>
                            <div class="flex items-end">
                                <button class="btn btn-primary w-full">
                                    <i class="fas fa-filter"></i>
                                    Apply Filters
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Bookings Table -->
                <div class="table-container">
                    <div class="table-header">
                        <h3 class="table-title">Recent Bookings</h3>
                        <div class="flex gap-2">
                            <button class="btn btn-sm btn-secondary">
                                <i class="fas fa-download"></i>
                                Export
                            </button>
                            <button class="btn btn-sm btn-secondary">
                                <i class="fas fa-print"></i>
                                Print
                            </button>
                        </div>
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Booking ID</th>
                                <th>Passenger</th>
                                <th>Flight</th>
                                <th>Route</th>
                                <th>Date</th>
                                <th>Seat</th>
                                <th>Status</th>
                                <th>Amount</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><strong>#NAV-001</strong></td>
                                <td>
                                    <div>
                                        <div class="font-medium">John Doe</div>
                                        <div class="text-sm text-gray-500">john.doe@email.com</div>
                                    </div>
                                </td>
                                <td>NAV-101</td>
                                <td>NYC → LAX</td>
                                <td>2024-01-15</td>
                                <td>12A</td>
                                <td><span class="badge badge-success">Confirmed</span></td>
                                <td>$450</td>
                                <td>
                                    <div class="flex gap-1">
                                        <button class="btn btn-sm btn-secondary" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-primary" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-error" title="Cancel">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>#NAV-002</strong></td>
                                <td>
                                    <div>
                                        <div class="font-medium">Jane Smith</div>
                                        <div class="text-sm text-gray-500">jane.smith@email.com</div>
                                    </div>
                                </td>
                                <td>NAV-102</td>
                                <td>LAX → CHI</td>
                                <td>2024-01-16</td>
                                <td>8B</td>
                                <td><span class="badge badge-warning">Pending</span></td>
                                <td>$320</td>
                                <td>
                                    <div class="flex gap-1">
                                        <button class="btn btn-sm btn-secondary" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-primary" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-error" title="Cancel">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>#NAV-003</strong></td>
                                <td>
                                    <div>
                                        <div class="font-medium">Mike Johnson</div>
                                        <div class="text-sm text-gray-500">mike.johnson@email.com</div>
                                    </div>
                                </td>
                                <td>NAV-103</td>
                                <td>CHI → MIA</td>
                                <td>2024-01-17</td>
                                <td>15C</td>
                                <td><span class="badge badge-success">Confirmed</span></td>
                                <td>$280</td>
                                <td>
                                    <div class="flex gap-1">
                                        <button class="btn btn-sm btn-secondary" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-primary" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-error" title="Cancel">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>#NAV-004</strong></td>
                                <td>
                                    <div>
                                        <div class="font-medium">Sarah Wilson</div>
                                        <div class="text-sm text-gray-500">sarah.wilson@email.com</div>
                                    </div>
                                </td>
                                <td>NAV-104</td>
                                <td>MIA → NYC</td>
                                <td>2024-01-18</td>
                                <td>3A</td>
                                <td><span class="badge badge-error">Cancelled</span></td>
                                <td>$380</td>
                                <td>
                                    <div class="flex gap-1">
                                        <button class="btn btn-sm btn-secondary" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-success" title="Refund">
                                            <i class="fas fa-undo"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
