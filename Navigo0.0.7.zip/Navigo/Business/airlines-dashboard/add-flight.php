<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check if business is logged in
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}

$business = get_business_by_id($_SESSION['business_id']);
if (!$business) {
    header('Location: ../../Login/business_login.php');
    exit();
}

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $flight_number = sanitize_input($_POST['flight_number']);
    $departure_airport = sanitize_input($_POST['departure_airport']);
    $arrival_airport = sanitize_input($_POST['arrival_airport']);
    $departure_time = sanitize_input($_POST['departure_time']);
    $arrival_time = sanitize_input($_POST['arrival_time']);
    $aircraft_type = sanitize_input($_POST['aircraft_type']);
    $capacity = sanitize_input($_POST['capacity']);
    $price = sanitize_input($_POST['price']);
    
    // Basic validation
    if (empty($flight_number) || empty($departure_airport) || empty($arrival_airport) || 
        empty($departure_time) || empty($arrival_time) || empty($aircraft_type) || 
        empty($capacity) || empty($price)) {
        $error_message = 'Please fill in all required fields.';
    } else {
        // Here you would typically save to database
        $success_message = 'Flight added successfully!';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Flight - NaviGo Airlines</title>
    
    <!-- External Resources -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Stylesheets -->
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    
    <!-- Scripts -->
    <script src="../../js/dark-mode.js"></script>
    <script src="../../js/business-navigation.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <nav class="dashboard-sidebar">
            <div class="sidebar-header">
                <a href="../../Index.php" class="sidebar-logo">
                    <img src="../../Assets/Images/NaviGo_Logo.png" alt="NaviGo">
                    <span>NaviGo Airlines</span>
                </a>
            </div>
            
            <div class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-section-title">Main</div>
                    <a href="index.php" class="nav-item">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                    <a href="flights.php" class="nav-item active">
                        <i class="fas fa-plane"></i>
                        Flights
                    </a>
                    <a href="bookings.php" class="nav-item">
                        <i class="fas fa-ticket-alt"></i>
                        Bookings
                    </a>
                    <a href="analytics.php" class="nav-item">
                        <i class="fas fa-chart-line"></i>
                        Analytics
                    </a>
                </div>
                
                <div class="nav-section">
                    <div class="nav-section-title">Management</div>
                    <a href="passengers.php" class="nav-item">
                        <i class="fas fa-users"></i>
                        Passengers
                    </a>
                    <a href="reviews.php" class="nav-item">
                        <i class="fas fa-star"></i>
                        Reviews
                    </a>
                    <a href="settings.php" class="nav-item">
                        <i class="fas fa-cog"></i>
                        Settings
                    </a>
                </div>
            </div>
        </nav>
        
        <!-- Main Content -->
        <main class="dashboard-main">
            <!-- Dark Mode Toggle -->
            <button class="dark-mode-toggle" style="position: fixed; top: 20px; left: 300px; z-index: 1000; background: var(--white); border: 1px solid var(--gray-300); border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; box-shadow: var(--shadow-sm); cursor: pointer; transition: all 0.3s ease; font-size: 14px;">
                <i class="fas fa-moon"></i>
            </button>
            
            <!-- Header -->
            <div class="dashboard-header">
                <div class="header-content">
                    <h1 class="header-title">Add New Flight</h1>
                    <div class="header-actions">
                        <button class="btn btn-secondary" onclick="window.location.href='flights.php'">
                            <i class="fas fa-arrow-left"></i>
                            Back to Flights
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Dashboard Content -->
            <div class="dashboard-content">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Flight Information</h3>
                        <p class="card-subtitle">Enter the details for the new flight</p>
                    </div>
                    <div class="card-body">
                        <?php if ($error_message): ?>
                            <div class="alert alert-error mb-4">
                                <i class="fas fa-exclamation-circle"></i>
                                <?php echo htmlspecialchars($error_message); ?>
                            </div>
                        <?php endif; ?>

                        <?php if ($success_message): ?>
                            <div class="alert alert-success mb-4">
                                <i class="fas fa-check-circle"></i>
                                <?php echo htmlspecialchars($success_message); ?>
                            </div>
                        <?php endif; ?>

                        <form method="POST" action="add-flight.php">
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: var(--space-lg);">
                                <div>
                                    <label class="text-sm font-medium mb-1">Flight Number *</label>
                                    <input type="text" name="flight_number" required 
                                           placeholder="e.g., NAV-101" 
                                           value="<?php echo isset($_POST['flight_number']) ? htmlspecialchars($_POST['flight_number']) : ''; ?>"
                                           style="width: 100%; padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                </div>
                                
                                <div>
                                    <label class="text-sm font-medium mb-1">Aircraft Type *</label>
                                    <select name="aircraft_type" required 
                                            style="width: 100%; padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                        <option value="">Select Aircraft</option>
                                        <option value="Boeing 737" <?php echo (isset($_POST['aircraft_type']) && $_POST['aircraft_type'] == 'Boeing 737') ? 'selected' : ''; ?>>Boeing 737</option>
                                        <option value="Airbus A320" <?php echo (isset($_POST['aircraft_type']) && $_POST['aircraft_type'] == 'Airbus A320') ? 'selected' : ''; ?>>Airbus A320</option>
                                        <option value="Airbus A321" <?php echo (isset($_POST['aircraft_type']) && $_POST['aircraft_type'] == 'Airbus A321') ? 'selected' : ''; ?>>Airbus A321</option>
                                        <option value="Boeing 777" <?php echo (isset($_POST['aircraft_type']) && $_POST['aircraft_type'] == 'Boeing 777') ? 'selected' : ''; ?>>Boeing 777</option>
                                    </select>
                                </div>
                                
                                <div>
                                    <label class="text-sm font-medium mb-1">Departure Airport *</label>
                                    <select name="departure_airport" required 
                                            style="width: 100%; padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                        <option value="">Select Airport</option>
                                        <option value="NYC" <?php echo (isset($_POST['departure_airport']) && $_POST['departure_airport'] == 'NYC') ? 'selected' : ''; ?>>New York (NYC)</option>
                                        <option value="LAX" <?php echo (isset($_POST['departure_airport']) && $_POST['departure_airport'] == 'LAX') ? 'selected' : ''; ?>>Los Angeles (LAX)</option>
                                        <option value="CHI" <?php echo (isset($_POST['departure_airport']) && $_POST['departure_airport'] == 'CHI') ? 'selected' : ''; ?>>Chicago (CHI)</option>
                                        <option value="MIA" <?php echo (isset($_POST['departure_airport']) && $_POST['departure_airport'] == 'MIA') ? 'selected' : ''; ?>>Miami (MIA)</option>
                                    </select>
                                </div>
                                
                                <div>
                                    <label class="text-sm font-medium mb-1">Arrival Airport *</label>
                                    <select name="arrival_airport" required 
                                            style="width: 100%; padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                        <option value="">Select Airport</option>
                                        <option value="NYC" <?php echo (isset($_POST['arrival_airport']) && $_POST['arrival_airport'] == 'NYC') ? 'selected' : ''; ?>>New York (NYC)</option>
                                        <option value="LAX" <?php echo (isset($_POST['arrival_airport']) && $_POST['arrival_airport'] == 'LAX') ? 'selected' : ''; ?>>Los Angeles (LAX)</option>
                                        <option value="CHI" <?php echo (isset($_POST['arrival_airport']) && $_POST['arrival_airport'] == 'CHI') ? 'selected' : ''; ?>>Chicago (CHI)</option>
                                        <option value="MIA" <?php echo (isset($_POST['arrival_airport']) && $_POST['arrival_airport'] == 'MIA') ? 'selected' : ''; ?>>Miami (MIA)</option>
                                    </select>
                                </div>
                                
                                <div>
                                    <label class="text-sm font-medium mb-1">Departure Time *</label>
                                    <input type="datetime-local" name="departure_time" required 
                                           value="<?php echo isset($_POST['departure_time']) ? htmlspecialchars($_POST['departure_time']) : ''; ?>"
                                           style="width: 100%; padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                </div>
                                
                                <div>
                                    <label class="text-sm font-medium mb-1">Arrival Time *</label>
                                    <input type="datetime-local" name="arrival_time" required 
                                           value="<?php echo isset($_POST['arrival_time']) ? htmlspecialchars($_POST['arrival_time']) : ''; ?>"
                                           style="width: 100%; padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                </div>
                                
                                <div>
                                    <label class="text-sm font-medium mb-1">Capacity *</label>
                                    <input type="number" name="capacity" required min="1" max="500"
                                           placeholder="e.g., 180" 
                                           value="<?php echo isset($_POST['capacity']) ? htmlspecialchars($_POST['capacity']) : ''; ?>"
                                           style="width: 100%; padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                </div>
                                
                                <div>
                                    <label class="text-sm font-medium mb-1">Base Price ($) *</label>
                                    <input type="number" name="price" required min="0" step="0.01"
                                           placeholder="e.g., 299.99" 
                                           value="<?php echo isset($_POST['price']) ? htmlspecialchars($_POST['price']) : ''; ?>"
                                           style="width: 100%; padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                </div>
                            </div>
                            
                            <div class="flex gap-3 mt-5">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save"></i>
                                    Add Flight
                                </button>
                                <button type="button" class="btn btn-secondary" onclick="window.location.href='flights.php'">
                                    <i class="fas fa-times"></i>
                                    Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
