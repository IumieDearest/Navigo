<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check if business is logged in
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}

$business = get_business_by_id($_SESSION['business_id']);
if (!$business) {
    header('Location: ../../Login/business_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flights Management - NaviGo Airlines</title>
    
    <!-- External Resources -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Stylesheets -->
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    
    <!-- Scripts -->
    <script src="../../js/dark-mode.js"></script>
    <script src="../../js/business-navigation.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <nav class="dashboard-sidebar">
            <div class="sidebar-header">
                <a href="../../Index.php" class="sidebar-logo">
                    <img src="../../Assets/Images/NaviGo_Logo.png" alt="NaviGo">
                    <span>NaviGo Airlines</span>
                </a>
            </div>
            
            <div class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-section-title">Main</div>
                    <a href="index.php" class="nav-item">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                    <a href="#" class="nav-item active">
                        <i class="fas fa-plane"></i>
                        Flights
                    </a>
                    <a href="bookings.php" class="nav-item">
                        <i class="fas fa-ticket-alt"></i>
                        Bookings
                    </a>
                    <a href="analytics.php" class="nav-item">
                        <i class="fas fa-chart-line"></i>
                        Analytics
                    </a>
                </div>
                
                <div class="nav-section">
                    <div class="nav-section-title">Management</div>
                    <a href="passengers.php" class="nav-item">
                        <i class="fas fa-users"></i>
                        Passengers
                    </a>
                    <a href="reviews.php" class="nav-item">
                        <i class="fas fa-star"></i>
                        Reviews
                    </a>
                    <a href="settings.php" class="nav-item">
                        <i class="fas fa-cog"></i>
                        Settings
                    </a>
                </div>
            </div>
        </nav>
        
        <!-- Main Content -->
        <main class="dashboard-main">
            <!-- Dark Mode Toggle -->
            <button class="dark-mode-toggle" style="position: fixed; top: 20px; left: 300px; z-index: 1000; background: var(--white); border: 1px solid var(--gray-300); border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; box-shadow: var(--shadow-sm); cursor: pointer; transition: all 0.3s ease; font-size: 14px;">
                <i class="fas fa-moon"></i>
            </button>
            
            <!-- Header -->
            <div class="dashboard-header">
                <div class="header-content">
                    <h1 class="header-title">Flights Management</h1>
                    <div class="header-actions">
                        <div class="header-search">
                            <i class="fas fa-search"></i>
                            <input type="text" placeholder="Search flights...">
                        </div>
                        <button class="btn btn-primary" onclick="window.location.href='add-flight.php'">
                            <i class="fas fa-plus"></i>
                            Add Flight
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Dashboard Content -->
            <div class="dashboard-content">
                <!-- Flight Filters -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: var(--space-md);">
                            <div>
                                <label class="text-sm font-medium mb-1">Status</label>
                                <select class="w-full" style="padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                    <option>All Status</option>
                                    <option>Scheduled</option>
                                    <option>Boarding</option>
                                    <option>In Flight</option>
                                    <option>Landed</option>
                                    <option>Delayed</option>
                                    <option>Cancelled</option>
                                </select>
                            </div>
                            <div>
                                <label class="text-sm font-medium mb-1">Route</label>
                                <select class="w-full" style="padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                    <option>All Routes</option>
                                    <option>NYC → LAX</option>
                                    <option>LAX → CHI</option>
                                    <option>CHI → MIA</option>
                                    <option>MIA → NYC</option>
                                </select>
                            </div>
                            <div>
                                <label class="text-sm font-medium mb-1">Date Range</label>
                                <input type="date" class="w-full" style="padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                            </div>
                            <div class="flex items-end">
                                <button class="btn btn-primary w-full">
                                    <i class="fas fa-filter"></i>
                                    Apply Filters
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Flights Table -->
                <div class="table-container">
                    <div class="table-header">
                        <h3 class="table-title">Flight Schedule</h3>
                        <div class="flex gap-2">
                            <button class="btn btn-sm btn-secondary">
                                <i class="fas fa-download"></i>
                                Export
                            </button>
                            <button class="btn btn-sm btn-secondary">
                                <i class="fas fa-print"></i>
                                Print
                            </button>
                        </div>
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Flight No.</th>
                                <th>Route</th>
                                <th>Departure</th>
                                <th>Arrival</th>
                                <th>Aircraft</th>
                                <th>Status</th>
                                <th>Passengers</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><strong>NAV-101</strong></td>
                                <td>NYC → LAX</td>
                                <td>08:00 AM</td>
                                <td>11:30 AM</td>
                                <td>Boeing 737</td>
                                <td><span class="badge badge-success">On Time</span></td>
                                <td>156/180</td>
                                <td>
                                    <div class="flex gap-1">
                                        <button class="btn btn-sm btn-secondary" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-primary" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-error" title="Cancel">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>NAV-102</strong></td>
                                <td>LAX → CHI</td>
                                <td>02:00 PM</td>
                                <td>07:45 PM</td>
                                <td>Airbus A320</td>
                                <td><span class="badge badge-warning">Delayed</span></td>
                                <td>142/180</td>
                                <td>
                                    <div class="flex gap-1">
                                        <button class="btn btn-sm btn-secondary" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-primary" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-error" title="Cancel">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>NAV-103</strong></td>
                                <td>CHI → MIA</td>
                                <td>06:30 PM</td>
                                <td>11:15 PM</td>
                                <td>Boeing 737</td>
                                <td><span class="badge badge-success">Boarding</span></td>
                                <td>168/180</td>
                                <td>
                                    <div class="flex gap-1">
                                        <button class="btn btn-sm btn-secondary" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-primary" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-error" title="Cancel">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td><strong>NAV-104</strong></td>
                                <td>MIA → NYC</td>
                                <td>09:00 AM</td>
                                <td>12:30 PM</td>
                                <td>Airbus A321</td>
                                <td><span class="badge badge-error">Cancelled</span></td>
                                <td>0/180</td>
                                <td>
                                    <div class="flex gap-1">
                                        <button class="btn btn-sm btn-secondary" title="View Details">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-sm btn-primary" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-sm btn-success" title="Reactivate">
                                            <i class="fas fa-play"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
