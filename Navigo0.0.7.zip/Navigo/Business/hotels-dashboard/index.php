<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check if business is logged in
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}

// Verify business type matches dashboard
if (!isset($_SESSION['business_type']) || $_SESSION['business_type'] !== 'hotel') {
    header('Location: ../../Login/business_login.php');
    exit();
}

$business = get_business_by_id($_SESSION['business_id']);
if (!$business) {
    header('Location: ../../Login/business_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotels Dashboard - NaviGo</title>
    
    <!-- External Resources -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Stylesheets -->
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    
    <!-- Scripts -->
    <script src="../../js/dark-mode.js"></script>
    <script src="../../js/business-navigation.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <nav class="dashboard-sidebar">
            <div class="sidebar-header">
                <a href="../../Index.php" class="sidebar-logo">
                    <img src="../../Assets/Images/NaviGo_Logo.png" alt="NaviGo">
                    <span>NaviGo Hotels</span>
                </a>
            </div>
            
            <div class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-section-title">Main</div>
                    <a href="index.php" class="nav-item active">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                    <a href="rooms.php" class="nav-item">
                        <i class="fas fa-bed"></i>
                        Rooms
                    </a>
                    <a href="bookings.php" class="nav-item">
                        <i class="fas fa-calendar-check"></i>
                        Bookings
                    </a>
                    <a href="analytics.php" class="nav-item">
                        <i class="fas fa-chart-line"></i>
                        Analytics
                    </a>
                </div>
                
                <div class="nav-section">
                    <div class="nav-section-title">Management</div>
                    <a href="guests.php" class="nav-item">
                        <i class="fas fa-users"></i>
                        Guests
                    </a>
                    <a href="reviews.php" class="nav-item">
                        <i class="fas fa-star"></i>
                        Reviews
                    </a>
                    <a href="settings.php" class="nav-item">
                        <i class="fas fa-cog"></i>
                        Settings
                    </a>
                </div>
            </div>
        </nav>
        
        <!-- Main Content -->
        <main class="dashboard-main">
            <!-- Dark Mode Toggle -->
            <button class="dark-mode-toggle" style="position: fixed; top: 20px; left: 300px; z-index: 1000; background: var(--white); border: 1px solid var(--gray-300); border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; box-shadow: var(--shadow-sm); cursor: pointer; transition: all 0.3s ease; font-size: 14px;">
                <i class="fas fa-moon"></i>
            </button>
            
            <!-- Header -->
            <div class="dashboard-header">
                <div class="header-content">
                    <div>
                        <h1 class="header-title">Hotels Dashboard</h1>
                        <p class="text-sm text-gray-500">Welcome, <?php echo htmlspecialchars($_SESSION['business_name']); ?> (<?php echo htmlspecialchars($_SESSION['business_type']); ?>)</p>
                    </div>
                    <div class="header-actions">
                        <div class="header-search">
                            <i class="fas fa-search"></i>
                            <input type="text" placeholder="Search bookings, guests...">
                        </div>
                        <button class="btn btn-primary" onclick="window.location.href='add-room.php'">
                            <i class="fas fa-plus"></i>
                            Add Room
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Dashboard Content -->
            <div class="dashboard-content">
                <!-- Stats Cards -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-header">
                            <div>
                                <div class="stat-value">156</div>
                                <div class="stat-label">Total Rooms</div>
                            </div>
                            <div class="stat-icon primary">
                                <i class="fas fa-bed"></i>
                            </div>
                        </div>
                        <div class="stat-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +5 rooms this month
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-header">
                            <div>
                                <div class="stat-value">89%</div>
                                <div class="stat-label">Occupancy Rate</div>
                            </div>
                            <div class="stat-icon success">
                                <i class="fas fa-chart-pie"></i>
                            </div>
                        </div>
                        <div class="stat-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +3% from last month
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-header">
                            <div>
                                <div class="stat-value">$1.8M</div>
                                <div class="stat-label">Revenue</div>
                            </div>
                            <div class="stat-icon warning">
                                <i class="fas fa-dollar-sign"></i>
                            </div>
                        </div>
                        <div class="stat-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +12% from last month
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-header">
                            <div>
                                <div class="stat-value">4.6</div>
                                <div class="stat-label">Average Rating</div>
                            </div>
                            <div class="stat-icon info">
                                <i class="fas fa-star"></i>
                            </div>
                        </div>
                        <div class="stat-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +0.1 from last month
                        </div>
                    </div>
                </div>
                
                <!-- Charts Row -->
                <div style="display: grid; grid-template-columns: 2fr 1fr; gap: var(--space-lg); margin-bottom: var(--space-xl);">
                    <!-- Occupancy Chart -->
                    <div class="chart-container">
                        <div class="chart-header">
                            <h3 class="chart-title">Occupancy Analytics</h3>
                            <div class="flex gap-2">
                                <button class="btn btn-sm btn-secondary">7D</button>
                                <button class="btn btn-sm btn-primary">30D</button>
                                <button class="btn btn-sm btn-secondary">90D</button>
                            </div>
                        </div>
                        <div class="chart-placeholder">
                            <div class="text-center">
                                <i class="fas fa-chart-area" style="font-size: 3rem; color: var(--gray-300); margin-bottom: var(--space-md);"></i>
                                <p>Occupancy Chart Placeholder</p>
                                <p class="text-sm text-gray-500">Interactive chart will be implemented here</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Room Types -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Room Types</h3>
                        </div>
                        <div class="card-body">
                            <div style="display: flex; flex-direction: column; gap: var(--space-md);">
                                <div class="flex justify-between items-center">
                                    <span class="text-sm">Standard</span>
                                    <span class="font-semibold">45 rooms</span>
                                </div>
                                <div class="flex justify-between items-center">
                                    <span class="text-sm">Deluxe</span>
                                    <span class="font-semibold">32 rooms</span>
                                </div>
                                <div class="flex justify-between items-center">
                                    <span class="text-sm">Suite</span>
                                    <span class="font-semibold">18 rooms</span>
                                </div>
                                <div class="flex justify-between items-center">
                                    <span class="text-sm">Presidential</span>
                                    <span class="font-semibold">8 rooms</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Bookings Table -->
                <div class="table-container">
                    <div class="table-header">
                        <h3 class="table-title">Recent Bookings</h3>
                    </div>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Booking ID</th>
                                <th>Guest</th>
                                <th>Room</th>
                                <th>Check-in</th>
                                <th>Check-out</th>
                                <th>Status</th>
                                <th>Amount</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>#HTL-001</td>
                                <td>John Doe</td>
                                <td>Deluxe Suite #201</td>
                                <td>2024-01-15</td>
                                <td>2024-01-18</td>
                                <td><span class="badge badge-success">Confirmed</span></td>
                                <td>$450</td>
                            </tr>
                            <tr>
                                <td>#HTL-002</td>
                                <td>Jane Smith</td>
                                <td>Standard Room #105</td>
                                <td>2024-01-16</td>
                                <td>2024-01-19</td>
                                <td><span class="badge badge-warning">Pending</span></td>
                                <td>$180</td>
                            </tr>
                            <tr>
                                <td>#HTL-003</td>
                                <td>Mike Johnson</td>
                                <td>Presidential Suite #501</td>
                                <td>2024-01-17</td>
                                <td>2024-01-20</td>
                                <td><span class="badge badge-success">Confirmed</span></td>
                                <td>$1,200</td>
                            </tr>
                            <tr>
                                <td>#HTL-004</td>
                                <td>Sarah Wilson</td>
                                <td>Deluxe Room #302</td>
                                <td>2024-01-18</td>
                                <td>2024-01-21</td>
                                <td><span class="badge badge-error">Cancelled</span></td>
                                <td>$320</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    
    <script>
        // Mobile sidebar toggle
        function toggleSidebar() {
            document.querySelector('.dashboard-sidebar').classList.toggle('open');
        }
        
        // Add mobile menu button for smaller screens
        if (window.innerWidth <= 1024) {
            const header = document.querySelector('.dashboard-header');
            const menuButton = document.createElement('button');
            menuButton.innerHTML = '<i class="fas fa-bars"></i>';
            menuButton.className = 'btn btn-secondary';
            menuButton.onclick = toggleSidebar;
            menuButton.style.marginRight = 'auto';
            header.querySelector('.header-content').insertBefore(menuButton, header.querySelector('.header-actions'));
        }
    </script>
</body>
</html>
