<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check if business is logged in
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}

$business = get_business_by_id($_SESSION['business_id']);
if (!$business) {
    header('Location: ../../Login/business_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rooms Management - NaviGo Hotels</title>
    
    <!-- External Resources -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Stylesheets -->
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    
    <!-- Scripts -->
    <script src="../../js/dark-mode.js"></script>
    <script src="../../js/business-navigation.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <nav class="dashboard-sidebar">
            <div class="sidebar-header">
                <a href="../../Index.php" class="sidebar-logo">
                    <img src="../../Assets/Images/NaviGo_Logo.png" alt="NaviGo">
                    <span>NaviGo Hotels</span>
                </a>
            </div>
            
            <div class="sidebar-nav">
                <div class="nav-section">
                    <div class="nav-section-title">Main</div>
                    <a href="index.php" class="nav-item">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                    <a href="#" class="nav-item active">
                        <i class="fas fa-bed"></i>
                        Rooms
                    </a>
                    <a href="bookings.php" class="nav-item">
                        <i class="fas fa-calendar-check"></i>
                        Bookings
                    </a>
                    <a href="analytics.php" class="nav-item">
                        <i class="fas fa-chart-line"></i>
                        Analytics
                    </a>
                </div>
                
                <div class="nav-section">
                    <div class="nav-section-title">Management</div>
                    <a href="guests.php" class="nav-item">
                        <i class="fas fa-users"></i>
                        Guests
                    </a>
                    <a href="reviews.php" class="nav-item">
                        <i class="fas fa-star"></i>
                        Reviews
                    </a>
                    <a href="settings.php" class="nav-item">
                        <i class="fas fa-cog"></i>
                        Settings
                    </a>
                </div>
            </div>
        </nav>
        
        <!-- Main Content -->
        <main class="dashboard-main">
            <!-- Dark Mode Toggle -->
            <button class="dark-mode-toggle" style="position: fixed; top: 20px; left: 300px; z-index: 1000; background: var(--white); border: 1px solid var(--gray-300); border-radius: 50%; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; box-shadow: var(--shadow-sm); cursor: pointer; transition: all 0.3s ease; font-size: 14px;">
                <i class="fas fa-moon"></i>
            </button>
            
            <!-- Header -->
            <div class="dashboard-header">
                <div class="header-content">
                    <h1 class="header-title">Rooms Management</h1>
                    <div class="header-actions">
                        <div class="header-search">
                            <i class="fas fa-search"></i>
                            <input type="text" placeholder="Search rooms...">
                        </div>
                        <button class="btn btn-primary" onclick="window.location.href='add-room.php'">
                            <i class="fas fa-plus"></i>
                            Add Room
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Dashboard Content -->
            <div class="dashboard-content">
                <!-- Room Stats -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-header">
                            <div>
                                <div class="stat-value">156</div>
                                <div class="stat-label">Total Rooms</div>
                            </div>
                            <div class="stat-icon primary">
                                <i class="fas fa-bed"></i>
                            </div>
                        </div>
                        <div class="stat-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +5 rooms this month
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-header">
                            <div>
                                <div class="stat-value">89%</div>
                                <div class="stat-label">Occupancy Rate</div>
                            </div>
                            <div class="stat-icon success">
                                <i class="fas fa-chart-pie"></i>
                            </div>
                        </div>
                        <div class="stat-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +3% from last month
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-header">
                            <div>
                                <div class="stat-value">$1.8M</div>
                                <div class="stat-label">Revenue</div>
                            </div>
                            <div class="stat-icon warning">
                                <i class="fas fa-dollar-sign"></i>
                            </div>
                        </div>
                        <div class="stat-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +12% from last month
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-header">
                            <div>
                                <div class="stat-value">4.6</div>
                                <div class="stat-label">Avg. Rating</div>
                            </div>
                            <div class="stat-icon info">
                                <i class="fas fa-star"></i>
                            </div>
                        </div>
                        <div class="stat-change positive">
                            <i class="fas fa-arrow-up"></i>
                            +0.1 from last month
                        </div>
                    </div>
                </div>

                <!-- Room Filters -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: var(--space-md);">
                            <div>
                                <label class="text-sm font-medium mb-1">Room Type</label>
                                <select class="w-full" style="padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                    <option>All Types</option>
                                    <option>Standard</option>
                                    <option>Deluxe</option>
                                    <option>Suite</option>
                                    <option>Presidential</option>
                                </select>
                            </div>
                            <div>
                                <label class="text-sm font-medium mb-1">Status</label>
                                <select class="w-full" style="padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                    <option>All Status</option>
                                    <option>Available</option>
                                    <option>Occupied</option>
                                    <option>Maintenance</option>
                                    <option>Out of Order</option>
                                </select>
                            </div>
                            <div>
                                <label class="text-sm font-medium mb-1">Floor</label>
                                <select class="w-full" style="padding: var(--space-sm); border: 1px solid var(--gray-300); border-radius: var(--radius-md);">
                                    <option>All Floors</option>
                                    <option>1st Floor</option>
                                    <option>2nd Floor</option>
                                    <option>3rd Floor</option>
                                    <option>4th Floor</option>
                                    <option>5th Floor</option>
                                </select>
                            </div>
                            <div class="flex items-end">
                                <button class="btn btn-primary w-full">
                                    <i class="fas fa-filter"></i>
                                    Apply Filters
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Rooms Grid -->
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: var(--space-lg);">
                    <!-- Room Card 1 -->
                    <div class="card">
                        <div class="card-body">
                            <div class="flex justify-between items-start mb-3">
                                <div>
                                    <h3 class="font-semibold text-lg">Room #101</h3>
                                    <p class="text-sm text-gray-500">Standard Room</p>
                                </div>
                                <span class="badge badge-success">Available</span>
                            </div>
                            <div class="mb-3">
                                <div class="flex justify-between text-sm mb-1">
                                    <span>Floor:</span>
                                    <span>1st Floor</span>
                                </div>
                                <div class="flex justify-between text-sm mb-1">
                                    <span>Capacity:</span>
                                    <span>2 Guests</span>
                                </div>
                                <div class="flex justify-between text-sm mb-1">
                                    <span>Price:</span>
                                    <span class="font-semibold">$120/night</span>
                                </div>
                                <div class="flex justify-between text-sm">
                                    <span>Amenities:</span>
                                    <span>WiFi, TV, AC</span>
                                </div>
                            </div>
                            <div class="flex gap-2">
                                <button class="btn btn-sm btn-primary flex-1">
                                    <i class="fas fa-edit"></i>
                                    Edit
                                </button>
                                <button class="btn btn-sm btn-secondary flex-1">
                                    <i class="fas fa-eye"></i>
                                    View
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Room Card 2 -->
                    <div class="card">
                        <div class="card-body">
                            <div class="flex justify-between items-start mb-3">
                                <div>
                                    <h3 class="font-semibold text-lg">Room #201</h3>
                                    <p class="text-sm text-gray-500">Deluxe Suite</p>
                                </div>
                                <span class="badge badge-warning">Occupied</span>
                            </div>
                            <div class="mb-3">
                                <div class="flex justify-between text-sm mb-1">
                                    <span>Floor:</span>
                                    <span>2nd Floor</span>
                                </div>
                                <div class="flex justify-between text-sm mb-1">
                                    <span>Capacity:</span>
                                    <span>4 Guests</span>
                                </div>
                                <div class="flex justify-between text-sm mb-1">
                                    <span>Price:</span>
                                    <span class="font-semibold">$250/night</span>
                                </div>
                                <div class="flex justify-between text-sm">
                                    <span>Amenities:</span>
                                    <span>WiFi, TV, AC, Mini Bar</span>
                                </div>
                            </div>
                            <div class="flex gap-2">
                                <button class="btn btn-sm btn-primary flex-1">
                                    <i class="fas fa-edit"></i>
                                    Edit
                                </button>
                                <button class="btn btn-sm btn-secondary flex-1">
                                    <i class="fas fa-eye"></i>
                                    View
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Room Card 3 -->
                    <div class="card">
                        <div class="card-body">
                            <div class="flex justify-between items-start mb-3">
                                <div>
                                    <h3 class="font-semibold text-lg">Room #501</h3>
                                    <p class="text-sm text-gray-500">Presidential Suite</p>
                                </div>
                                <span class="badge badge-error">Maintenance</span>
                            </div>
                            <div class="mb-3">
                                <div class="flex justify-between text-sm mb-1">
                                    <span>Floor:</span>
                                    <span>5th Floor</span>
                                </div>
                                <div class="flex justify-between text-sm mb-1">
                                    <span>Capacity:</span>
                                    <span>6 Guests</span>
                                </div>
                                <div class="flex justify-between text-sm mb-1">
                                    <span>Price:</span>
                                    <span class="font-semibold">$500/night</span>
                                </div>
                                <div class="flex justify-between text-sm">
                                    <span>Amenities:</span>
                                    <span>WiFi, TV, AC, Mini Bar, Jacuzzi</span>
                                </div>
                            </div>
                            <div class="flex gap-2">
                                <button class="btn btn-sm btn-primary flex-1">
                                    <i class="fas fa-edit"></i>
                                    Edit
                                </button>
                                <button class="btn btn-sm btn-secondary flex-1">
                                    <i class="fas fa-eye"></i>
                                    View
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>
</html>
