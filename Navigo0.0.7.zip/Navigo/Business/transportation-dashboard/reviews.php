<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check authentication for business user
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}
// Only allow Transportation business type
if (!isset($_SESSION['business_type']) || $_SESSION['business_type'] !== 'transport') {
    header('Location: ../../Login/business_login.php');
    exit();
}
$business_id = $_SESSION['business_id'];

// Initialize database connection
$database = new Database();
$pdo = $database->getConnection();

// Pagination
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Status/visibility messages
$success = '';
$error = '';

// Handle status/response actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['review_id']) && isset($_POST['action'])) {
    $review_id = intval($_POST['review_id']);
    $action = $_POST['action'];
    if ($action === 'hide') {
        // Hide review from public
        $stmt = $pdo->prepare("UPDATE reviews SET is_hidden=1 WHERE id=? AND business_id=?");
        $stmt->execute([$review_id, $business_id]);
        $success = "Review hidden.";
    } elseif ($action === 'show') {
        $stmt = $pdo->prepare("UPDATE reviews SET is_hidden=0 WHERE id=? AND business_id=?");
        $stmt->execute([$review_id, $business_id]);
        $success = "Review is now public.";
    } elseif ($action === 'reply') {
        $reply = trim($_POST['reply_text'] ?? '');
        if ($reply !== '') {
            $stmt = $pdo->prepare("UPDATE reviews SET business_reply=? WHERE id=? AND business_id=?");
            $stmt->execute([$reply, $review_id, $business_id]);
            $success = "Reply saved.";
        } else {
            $error = "Reply cannot be empty.";
        }
    }
    // Prevent resubmission
    header("Location: reviews.php?page=$page");
    exit();
}

// Get reviews for this business' trips (by passengers)
// Assume: reviews table has columns: id, trip_id, user_id, business_id, rating, comment, created_at, is_hidden, business_reply
$stmt = $pdo->prepare("
    SELECT r.id, r.trip_id, r.user_id, r.rating, r.comment, r.created_at, r.is_hidden, r.business_reply,
           u.first_name, u.last_name, t.route, t.departure_time
    FROM reviews r
    JOIN users u ON r.user_id = u.id
    JOIN trips t ON r.trip_id = t.id
    WHERE r.business_id=?
    ORDER BY r.created_at DESC
    LIMIT $per_page OFFSET $offset
");
$stmt->execute([$business_id]);
$reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Total review count for pagination
$stmt2 = $pdo->prepare("SELECT COUNT(*) FROM reviews WHERE business_id=?");
$stmt2->execute([$business_id]);
$total_reviews = (int)$stmt2->fetchColumn();
$total_pages = max(1, ceil($total_reviews / $per_page));

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reviews - Transportation Business Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    <style>
        .reviews-table { width:100%; border-collapse:collapse; background:#fff; }
        .reviews-table th, .reviews-table td { border:1px solid #e5e5e5; padding:10px 10px; }
        .reviews-table th { background:#F5FAFF; color:#1458a6; font-weight:600; }
        .reviews-table tr:nth-child(even) { background:#f9f9f9; }
        .badge-rating { background:#f3fae6; color:#219620; border-radius:8px; display:inline-block; min-width:2em; text-align:center; font-weight:600;}
        .hide-btn, .show-btn, .reply-btn { padding:3px 11px; border:none; border-radius:6px; cursor:pointer; font-weight:500; }
        .hide-btn { background:#eee; color:#a12c2c;}
        .show-btn { background:#e5f3ff; color:#1458a6;}
        .reply-btn { background:#1482e5; color:#fff;}
        .business-reply { background:#f3faff; border-left: 4px solid #1EA7FF; margin:7px 0 0 0; padding:9px 13px;}
        .pagination { margin-top:24px; text-align:center; }
        .pagination a, .pagination span { display:inline-block; margin:0 5px; padding:6px 12px; border-radius:5px; text-decoration:none; }
        .pagination .current { background:#1EA7FF; color:white; font-weight:600;}
        .pagination a { color:#1458a6; border:1px solid #eee; background:#fafbfd; }
        .review-hidden { color:#999; font-style:italic;}
        .review-actions form { display:inline; }
        .reply-form textarea { width:95%; min-height:35px; font-size:1em; }
        .reply-form { margin-top:7px;}
    </style>
    <script>
        function toggleReplyBox(id) {
            const box = document.getElementById('reply-box-' + id);
            if(box.style.display === 'none') {
                box.style.display = '';
            } else {
                box.style.display = 'none';
            }
        }
    </script>
</head>
<body>
    <div class="dashboard-container">
        <?php include 'sidebar.php'; ?>
        <main class="dashboard-main">
        <section>
        <h1>Trip Reviews</h1>
        <?php if ($success): ?>
            <div class="notice success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="notice error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if (empty($reviews)): ?>
            <div class="notice warning" style="margin:1.5em 0">No reviews received yet for your trips.</div>
        <?php else: ?>
        <div class="table-responsive">
        <table class="reviews-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Passenger</th>
                    <th>Trip / Date</th>
                    <th>Rating</th>
                    <th>Review</th>
                    <th>Business Reply</th>
                    <th>Visibility</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($reviews as $idx => $rev): ?>
                <tr>
                    <td><?php echo $offset + $idx + 1; ?></td>
                    <td>
                        <?php echo htmlspecialchars($rev['first_name'] . ' ' . $rev['last_name']); ?>
                    </td>
                    <td>
                        <?php echo htmlspecialchars($rev['route']); ?>
                        <br>
                        <small><?php echo date('M d, Y H:i', strtotime($rev['departure_time'])); ?></small>
                    </td>
                    <td>
                        <span class="badge-rating"><?php echo intval($rev['rating']); ?>/5</span>
                    </td>
                    <td>
                        <?php if ($rev['is_hidden']): ?>
                            <span class="review-hidden">(Hidden from passengers)</span><br>
                        <?php endif; ?>
                        <?php echo nl2br(htmlspecialchars($rev['comment'])); ?>
                        <div style="font-size:0.93em; color:#888; margin-top:3px">
                            <small>Posted <?php echo date('M d, Y H:i', strtotime($rev['created_at'])); ?></small>
                        </div>
                    </td>
                    <td>
                        <?php if ($rev['business_reply']): ?>
                            <div class="business-reply"><?php echo nl2br(htmlspecialchars($rev['business_reply'])); ?></div>
                        <?php endif; ?>
                        <button type="button" class="reply-btn" onclick="toggleReplyBox(<?php echo $rev['id']; ?>)">
                            <?php echo $rev['business_reply'] ? 'Edit Reply' : 'Reply'; ?>
                        </button>
                        <div class="reply-form" id="reply-box-<?php echo $rev['id']; ?>" style="display:none">
                            <form method="post">
                                <input type="hidden" name="review_id" value="<?php echo $rev['id']; ?>">
                                <input type="hidden" name="action" value="reply">
                                <textarea name="reply_text" required><?php echo htmlspecialchars($rev['business_reply']); ?></textarea><br>
                                <button type="submit" class="reply-btn">Save Reply</button>
                                <button type="button" class="hide-btn" style="margin-left:8px;" onclick="toggleReplyBox(<?php echo $rev['id']; ?>)">Cancel</button>
                            </form>
                        </div>
                    </td>
                    <td>
                        <?php if ($rev['is_hidden']): ?>
                            <span class="badge review-hidden">Hidden</span>
                        <?php else: ?>
                            <span class="badge" style="background:#e7faf1;color:#188947;">Visible</span>
                        <?php endif; ?>
                    </td>
                    <td class="review-actions">
                        <form method="post" style="display:inline">
                            <input type="hidden" name="review_id" value="<?php echo $rev['id']; ?>">
                            <?php if ($rev['is_hidden']): ?>
                                <input type="hidden" name="action" value="show">
                                <button type="submit" class="show-btn">Show</button>
                            <?php else: ?>
                                <input type="hidden" name="action" value="hide">
                                <button type="submit" class="hide-btn">Hide</button>
                            <?php endif; ?>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php endif; ?>

        <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?php echo $page - 1; ?>">&larr; Prev</a>
                <?php endif; ?>
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <?php if ($i == $page): ?>
                        <span class="current"><?php echo $i; ?></span>
                    <?php elseif ($i == 1 || $i == $total_pages || abs($i-$page) <= 2): ?>
                        <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                    <?php elseif ($i == $page-3 || $i == $page+3): ?>
                        ...
                    <?php endif; ?>
                <?php endfor; ?>
                <?php if ($page < $total_pages): ?>
                    <a href="?page=<?php echo $page + 1; ?>">Next &rarr;</a>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        </section>
        </main>
    </div>
</body>
</html>
