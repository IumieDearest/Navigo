<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check authentication for business user
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}

// Only allow Transportation business type
if (!isset($_SESSION['business_type']) || $_SESSION['business_type'] !== 'transport') {
    header('Location: ../../Login/business_login.php');
    exit();
}

$business_id = $_SESSION['business_id'];

// Initialize database connection
$database = new Database();
$pdo = $database->getConnection();

$success = '';
$error = '';

// Fetch business settings
$stmt = $pdo->prepare("SELECT * FROM businesses WHERE id=?");
$stmt->execute([$business_id]);
$business = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$business) {
    $error = "Business not found.";
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $business_name = trim($_POST['business_name'] ?? '');
    $contact_email = trim($_POST['contact_email'] ?? '');
    $contact_phone = trim($_POST['contact_phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $notification_pref = isset($_POST['notification_pref']) ? 1 : 0;

    // Basic validation
    if ($business_name === '') $error = "Business name is required.";
    elseif ($contact_email === '' || !filter_var($contact_email, FILTER_VALIDATE_EMAIL)) $error = "A valid contact email is required.";
    elseif ($contact_phone === '') $error = "Contact phone is required.";

    if (!$error) {
        // Update settings
        $stmt = $pdo->prepare("UPDATE businesses SET business_name=?, contact_email=?, contact_phone=?, address=?, receive_notifications=? WHERE id=?");
        $result = $stmt->execute([$business_name, $contact_email, $contact_phone, $address, $notification_pref, $business_id]);
        if ($result) {
            $success = "Settings updated successfully.";
            // Refresh business details
            $stmt = $pdo->prepare("SELECT * FROM businesses WHERE id=?");
            $stmt->execute([$business_id]);
            $business = $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            $error = "Failed to update settings. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Account Settings - Transportation Dashboard</title>
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    <style>
        .settings-form { max-width:520px; margin: 2em auto; background:#fff; padding:2em 1.75em 2.5em 1.75em; border-radius:12px; box-shadow: 0 1px 8px rgba(40,74,104,0.06);}
        .settings-form label {font-weight:500; color:#1458a6; display:block; margin-bottom:0.52em;}
        .settings-form input[type="text"], .settings-form input[type="email"], .settings-form textarea {width:100%; padding:0.7em; border:1px solid #e5e5e5; border-radius:6px; margin-bottom:1.25em;}
        .settings-form input[type="checkbox"] {transform:scale(1.1);}
        .settings-form .form-group {margin-bottom:1.2em;}
        .settings-form button {background:#1458a6;color:#fff; border:none; border-radius:6px; padding:0.7em 2.2em; font-size:1em;}
        .success-message {padding:0.7em 1em; margin-bottom:1em; background:#d6f7e2;color:#178947; border-radius:7px;}
        .error-message {padding:0.7em 1em; margin-bottom:1em; background:#ffe1e1;color:#b70d2f; border-radius:7px;}
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php include 'sidebar.php'; ?>
        <main class="dashboard-main">
            <section>
                <h1>Account Settings</h1>
                <?php if ($success): ?>
                    <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>

                <form class="settings-form" method="post" novalidate>
                    <div class="form-group">
                        <label for="business_name">Business Name</label>
                        <input type="text" name="business_name" id="business_name" required
                            value="<?php echo htmlspecialchars($business['business_name'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="contact_email">Contact Email</label>
                        <input type="email" name="contact_email" id="contact_email" required
                            value="<?php echo htmlspecialchars($business['contact_email'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="contact_phone">Contact Phone</label>
                        <input type="text" name="contact_phone" id="contact_phone" required
                            value="<?php echo htmlspecialchars($business['contact_phone'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="address">Business Address</label>
                        <textarea name="address" id="address" rows="3"><?php echo htmlspecialchars($business['address'] ?? ''); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label>
                            <input type="checkbox" name="notification_pref" <?php echo (!empty($business['receive_notifications'])) ? 'checked' : ''; ?>>
                            Receive email notifications (e.g. for new bookings)
                        </label>
                    </div>
                    <div>
                        <button type="submit">Save Changes</button>
                    </div>
                </form>
            </section>
        </main>
    </div>
</body>
</html>
