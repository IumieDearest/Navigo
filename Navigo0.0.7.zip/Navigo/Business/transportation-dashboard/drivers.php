<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check authentication for business user
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}

// Only allow Transportation business type
if (!isset($_SESSION['business_type']) || $_SESSION['business_type'] !== 'transport') {
    header('Location: ../../Login/business_login.php');
    exit();
}
$business_id = $_SESSION['business_id'];

// Initialize database connection
$database = new Database();
$pdo = $database->getConnection();

$errors = [];
$success = '';
$driver_id = null;
$is_editing = false;

// Handle form submit (add/edit)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $license_number = trim($_POST['license_number'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $status = trim($_POST['status'] ?? 'active');
    $driver_id = $_POST['driver_id'] ?? null;

    // Simple validation
    if ($first_name === '') $errors[] = "First name is required.";
    if ($last_name === '') $errors[] = "Last name is required.";
    if ($license_number === '') $errors[] = "License number is required.";
    if ($phone === '') $errors[] = "Phone is required.";
    if (!in_array($status, ['active', 'inactive'])) $status = 'active';

    // Duplicate license check (exclude current when editing)
    if (empty($errors)) {
        if ($driver_id) {
            $stmt = $pdo->prepare("SELECT id FROM drivers WHERE license_number=? AND business_id=? AND id!=?");
            $stmt->execute([$license_number, $business_id, $driver_id]);
        } else {
            $stmt = $pdo->prepare("SELECT id FROM drivers WHERE license_number=? AND business_id=?");
            $stmt->execute([$license_number, $business_id]);
        }
        if ($stmt->fetch()) {
            $errors[] = "A driver with this license number already exists.";
        }
    }

    // Insert or update
    if (empty($errors)) {
        if ($driver_id) {
            // Update
            $stmt = $pdo->prepare("UPDATE drivers SET first_name=?, last_name=?, license_number=?, phone=?, status=? WHERE id=? AND business_id=?");
            if ($stmt->execute([$first_name, $last_name, $license_number, $phone, $status, $driver_id, $business_id])) {
                $success = "Driver updated successfully.";
            } else {
                $errors[] = "Failed to update driver.";
            }
        } else {
            // Insert
            $stmt = $pdo->prepare("INSERT INTO drivers (business_id, first_name, last_name, license_number, phone, status) VALUES (?, ?, ?, ?, ?, ?)");
            if ($stmt->execute([$business_id, $first_name, $last_name, $license_number, $phone, $status])) {
                $success = "Driver added successfully.";
            } else {
                $errors[] = "Failed to add driver.";
            }
        }
        if (empty($errors)) {
            header("Location: drivers.php?success=1");
            exit();
        }
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $del_id = intval($_GET['delete']);
    // Only soft delete (set status to inactive)
    $stmt = $pdo->prepare("UPDATE drivers SET status='inactive' WHERE id=? AND business_id=?");
    $stmt->execute([$del_id, $business_id]);
    header("Location: drivers.php?deleted=1");
    exit();
}

// Handle edit
$edit_driver = null;
if (isset($_GET['edit'])) {
    $is_editing = true;
    $driver_id = intval($_GET['edit']);
    $stmt = $pdo->prepare("SELECT * FROM drivers WHERE id=? AND business_id=?");
    $stmt->execute([$driver_id, $business_id]);
    $edit_driver = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$edit_driver) {
        $errors[] = "Driver not found.";
        $is_editing = false;
    }
}

// Fetch list of drivers
$stmt = $pdo->prepare("SELECT * FROM drivers WHERE business_id = ? ORDER BY status DESC, last_name ASC, first_name ASC");
$stmt->execute([$business_id]);
$drivers = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Success messages
if (isset($_GET['success'])) $success = "Driver saved successfully.";
if (isset($_GET['deleted'])) $success = "Driver removed (marked as inactive).";

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Drivers - Transportation Dashboard</title>
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    <style>
        .driver-table { width:100%; border-collapse:collapse; margin-top:1.5em; background:#fff;}
        .driver-table th, .driver-table td { border:1px solid #e5e5e5; padding:8px 10px; }
        .driver-table th { background:#EFF7FF; font-weight:600; color:#174d83;}
        .driver-table tr:nth-child(even) { background:#fafbfc;}
        .badge { padding:2px 10px; border-radius:9px; font-size:0.97em;}
        .badge.active { background:#d3f9d8; color:#209620;}
        .badge.inactive { background:#ffe1de; color:#ba2f02;}
        .driver-actions { text-align:center;}
        .btn-edit, .btn-delete { background:none; border:none; color:#1675d1; padding: 2px 8px; font-size:1em; cursor:pointer;}
        .btn-delete { color:#dc2626;}
        .drivers-form { margin-bottom:2.5em; margin-top:1.5em; background:#fff; border-radius:8px; box-shadow:0 1px 6px #e6eafa80; padding:1.2em 2em; max-width:450px;}
        .drivers-form label { display:block; font-weight:600; margin-top:0.7em;}
        .drivers-form input, .drivers-form select { width:100%; padding:0.6em; margin-top:0.1em; border:1px solid #dbeafe; border-radius:5px; font-size:1em;}
        .drivers-form .form-actions { margin-top:1.6em;}
        .drivers-form button { background:#1ea7ff; color:white; padding:0.6em 1.7em; border:none; border-radius:6px; font-size:1em; font-weight:600; cursor:pointer;}
        .drivers-form .cancel-link { margin-left:1em; color:#1458a6; text-decoration:underline; background:none; border:none; cursor:pointer;}
        .success-message { background:#dafbe1; color:#265c2a; padding:0.9em 1em; border-radius:6px; margin-bottom:1.2em;}
        .error-message { background:#ffe6e7; color:#ba2226; padding:0.9em 1em; border-radius:6px; margin-bottom:1.2em;}
        @media (max-width: 700px) {
            .drivers-form { max-width:100%; padding:1em; }
            .driver-table th, .driver-table td { font-size:0.97em; padding:6px;}
        }
    </style>
</head>
<body>
<div class="dashboard-container">
    <?php include 'sidebar.php'; ?>
    <main class="dashboard-main">
        <section>
            <h1>Drivers</h1>
            <?php if ($success): ?>
                <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            <?php if (!empty($errors)): ?>
                <div class="error-message">
                    <?php foreach ($errors as $e): echo htmlspecialchars($e) . "<br>"; endforeach; ?>
                </div>
            <?php endif; ?>

            <!-- Driver Add/Edit Form -->
            <form class="drivers-form" method="post" action="drivers.php<?php echo $is_editing && $edit_driver ? '?edit=' . intval($edit_driver['id']) : ''; ?>">
                <h2><?php echo $is_editing ? 'Edit Driver' : 'Add New Driver'; ?></h2>
                <input type="hidden" name="driver_id" value="<?php echo $is_editing && $edit_driver ? intval($edit_driver['id']) : ''; ?>">
                <label for="first_name">First Name</label>
                <input type="text" name="first_name" id="first_name" required value="<?php echo htmlspecialchars($edit_driver['first_name'] ?? $_POST['first_name'] ?? ''); ?>">

                <label for="last_name">Last Name</label>
                <input type="text" name="last_name" id="last_name" required value="<?php echo htmlspecialchars($edit_driver['last_name'] ?? $_POST['last_name'] ?? ''); ?>">

                <label for="license_number">License Number</label>
                <input type="text" name="license_number" id="license_number" required value="<?php echo htmlspecialchars($edit_driver['license_number'] ?? $_POST['license_number'] ?? ''); ?>">

                <label for="phone">Phone</label>
                <input type="text" name="phone" id="phone" required value="<?php echo htmlspecialchars($edit_driver['phone'] ?? $_POST['phone'] ?? ''); ?>">

                <label for="status">Status</label>
                <select name="status" id="status">
                    <option value="active" <?php
                        $status_val = $edit_driver['status'] ?? $_POST['status'] ?? 'active';
                        echo $status_val == "active" ? "selected" : "";
                    ?>>Active</option>
                    <option value="inactive" <?php echo $status_val == "inactive" ? "selected" : ""; ?>>Inactive</option>
                </select>
                <div class="form-actions">
                    <button type="submit"><?php echo $is_editing ? 'Update Driver' : 'Add Driver'; ?></button>
                    <?php if ($is_editing): ?>
                        <a href="drivers.php" class="cancel-link">Cancel</a>
                    <?php endif; ?>
                </div>
            </form>

            <!-- Drivers Table -->
            <div class="table-responsive">
                <table class="driver-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>License Number</th>
                            <th>Phone</th>
                            <th>Status</th>
                            <th class="driver-actions">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($drivers)): ?>
                        <tr><td colspan="6"><em>No drivers found. Add some!</em></td></tr>
                    <?php else: foreach ($drivers as $idx => $driver): ?>
                        <tr>
                            <td><?php echo $idx + 1; ?></td>
                            <td><?php echo htmlspecialchars($driver['first_name'] . ' ' . $driver['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($driver['license_number']); ?></td>
                            <td><?php echo htmlspecialchars($driver['phone']); ?></td>
                            <td>
                                <span class="badge <?php echo htmlspecialchars(strtolower($driver['status'])); ?>">
                                    <?php echo ucfirst($driver['status']); ?>
                                </span>
                            </td>
                            <td class="driver-actions">
                                <a href="drivers.php?edit=<?php echo intval($driver['id']); ?>" class="btn-edit" title="Edit"><i class="fa fa-edit"></i> Edit</a>
                                <?php if ($driver['status'] === 'active'): ?>
                                <a href="drivers.php?delete=<?php echo intval($driver['id']); ?>" class="btn-delete" onclick="return confirm('Mark this driver as inactive?');" title="Delete">
                                    <i class="fa fa-trash"></i> Remove
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
</div>
</body>
</html>
