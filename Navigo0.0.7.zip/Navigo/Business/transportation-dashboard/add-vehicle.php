<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check authentication for business user
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}

// Only allow Transportation business type
if (!isset($_SESSION['business_type']) || $_SESSION['business_type'] !== 'transport') {
    header('Location: ../../Login/business_login.php');
    exit();
}

$errors = [];
$success = '';
$vehicle_types = ['Bus', 'Van', 'Truck', 'Shuttle', 'Car', 'Other'];

// Initialize database connection
$database = new Database();
$pdo = $database->getConnection();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $vehicle_name = sanitize_input($_POST['vehicle_name'] ?? '');
    $vehicle_type = sanitize_input($_POST['vehicle_type'] ?? '');
    $plate_number = sanitize_input($_POST['plate_number'] ?? '');
    $capacity = sanitize_input($_POST['capacity'] ?? '');
    $status = sanitize_input($_POST['status'] ?? 'active');

    // Validation
    if (empty($vehicle_name)) $errors[] = "Vehicle name is required.";
    if (empty($vehicle_type)) $errors[] = "Vehicle type is required.";
    if (empty($plate_number)) $errors[] = "Plate number is required.";
    if (!is_numeric($capacity) || intval($capacity) <= 0) $errors[] = "Capacity must be a positive number.";

    // Duplicate plate check
    if (empty($errors)) {
        $business_id = $_SESSION['business_id'];
        $stmt = $pdo->prepare("SELECT id FROM vehicles WHERE plate_number = ? AND business_id = ?");
        $stmt->execute([$plate_number, $business_id]);
        if ($stmt->fetch()) {
            $errors[] = "A vehicle with this plate number already exists.";
        }
    }

    // Insert if no errors
    if (empty($errors)) {
        $stmt = $pdo->prepare(
            "INSERT INTO vehicles (business_id, vehicle_name, vehicle_type, plate_number, capacity, status) VALUES (?, ?, ?, ?, ?, ?)"
        );
        $result = $stmt->execute([
            $business_id,
            $vehicle_name,
            $vehicle_type,
            $plate_number,
            $capacity,
            $status
        ]);
        if ($result) {
            $success = "Vehicle added successfully!";
        } else {
            $errors[] = "Error adding vehicle, please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Vehicle - Transportation Dashboard</title>
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div class="dashboard-container">
        <?php include 'sidebar.php'; ?>
        <main class="dashboard-main">
            <section class="form-card">
                <h1>Add Vehicle</h1>
                <?php if ($success): ?>
                    <div class="success-message"><?php echo $success; ?></div>
                <?php endif; ?>
                <?php if (!empty($errors)): ?>
                    <div class="error-message">
                        <ul>
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <form method="post" action="">
                    <div class="form-group">
                        <label for="vehicle_name">Vehicle Name</label>
                        <input type="text" name="vehicle_name" id="vehicle_name" required value="<?php echo htmlspecialchars($_POST['vehicle_name'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="vehicle_type">Vehicle Type</label>
                        <select name="vehicle_type" id="vehicle_type" required>
                            <option value="">Select Type</option>
                            <?php foreach ($vehicle_types as $type): ?>
                                <option value="<?php echo htmlspecialchars($type); ?>" <?php echo (($_POST['vehicle_type'] ?? '') == $type) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($type); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="plate_number">Plate Number</label>
                        <input type="text" name="plate_number" id="plate_number" required value="<?php echo htmlspecialchars($_POST['plate_number'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="capacity">Capacity</label>
                        <input type="number" name="capacity" id="capacity" min="1" required value="<?php echo htmlspecialchars($_POST['capacity'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select name="status" id="status">
                            <option value="active" <?php echo (($_POST['status'] ?? 'active') == 'active') ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?php echo (($_POST['status'] ?? '') == 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Add Vehicle</button>
                        <a href="index.php" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </section>
        </main>
    </div>
</body>
</html>
