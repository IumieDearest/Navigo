<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check authentication for business user
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}

// Only allow Transportation business type
if (!isset($_SESSION['business_type']) || $_SESSION['business_type'] !== 'transport') {
    header('Location: ../../Login/business_login.php');
    exit();
}

$business_id = $_SESSION['business_id'];

// Initialize database connection
$database = new Database();
$pdo = $database->getConnection();

// Handle possible status update or cancellation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['booking_id'])) {
    $booking_id = intval($_POST['booking_id']);
    if (isset($_POST['action']) && $_POST['action'] === 'cancel') {
        // Cancel the booking
        $stmt = $pdo->prepare("UPDATE bookings SET status='Cancelled' WHERE id=? AND business_id=?");
        $stmt->execute([$booking_id, $business_id]);
    } elseif (isset($_POST['action']) && $_POST['action'] === 'confirm') {
        // Confirm the booking
        $stmt = $pdo->prepare("UPDATE bookings SET status='Confirmed' WHERE id=? AND business_id=?");
        $stmt->execute([$booking_id, $business_id]);
    }
    header('Location: bookings.php');
    exit();
}

// Pagination variables
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Fetch bookings related to business
$stmt = $pdo->prepare("
    SELECT b.id, b.user_id, b.trip_id, b.status, b.created_at, 
           t.route, t.departure_time, t.arrival_time, t.price, t.vehicle_id, 
           u.first_name, u.last_name, u.email
    FROM bookings b
    JOIN trips t ON b.trip_id = t.id
    JOIN users u ON b.user_id = u.id
    WHERE t.business_id = ?
    ORDER BY b.created_at DESC
    LIMIT $per_page OFFSET $offset
");
$stmt->execute([$business_id]);
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// For pagination control
$stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings b JOIN trips t ON b.trip_id = t.id WHERE t.business_id = ?");
$stmt->execute([$business_id]);
$total_bookings = $stmt->fetchColumn();
$total_pages = max(1, ceil($total_bookings / $per_page));
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Bookings - Transportation Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    <style>
        .bookings-table { width:100%; border-collapse:collapse; background:#fff; }
        .bookings-table th, .bookings-table td { border:1px solid #e5e5e5; padding:10px 8px; }
        .bookings-table th { background:#F5FAFF; color:#1458a6; font-weight:600; }
        .bookings-table tr:nth-child(even) { background:#f9f9f9; }
        .badge { display:inline-block; padding:0.3em 0.7em; border-radius:10px; font-size:0.95em; font-weight:600;}
        .badge.Confirmed { background:#d3f9d8; color:#209620;}
        .badge.Pending { background:#fff7d6; color:#744700;}
        .badge.Cancelled { background:#ffe5e8; color:#b8231d;}
        .bookings-btn { padding:0.3em 1em; border:none; border-radius:6px; background:#1482e5; color:white; cursor:pointer;}
        .bookings-btn.cancel { background:#fc4646; }
        .pagination { margin-top:20px; text-align:center; }
        .pagination a, .pagination span { display:inline-block; margin:0 5px; padding:6px 12px; border-radius:5px; text-decoration:none; }
        .pagination .current { background:#1EA7FF; color:white; font-weight:600;}
        .pagination a { color:#1458a6; border:1px solid #eee; background:#fafbfd; }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>
        <main class="dashboard-main">
            <section>
                <h1>Bookings</h1>
                <?php if (empty($bookings)): ?>
                    <div class="notice warning" style="margin:1.5em 0">No bookings found for your trips yet.</div>
                <?php else: ?>
                <div class="table-responsive">
                <table class="bookings-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Passenger</th>
                            <th>Email</th>
                            <th>Trip</th>
                            <th>Vehicle</th>
                            <th>Departure</th>
                            <th>Arrival</th>
                            <th>Price</th>
                            <th>Status</th>
                            <th>Booked at</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($bookings as $idx => $booking): ?>
                        <tr>
                            <td><?php echo $offset + $idx + 1; ?></td>
                            <td><?php echo htmlspecialchars($booking['first_name'] . ' ' . $booking['last_name']); ?></td>
                            <td><a href="mailto:<?php echo htmlspecialchars($booking['email']); ?>"><?php echo htmlspecialchars($booking['email']); ?></a></td>
                            <td><?php echo htmlspecialchars($booking['route']); ?></td>
                            <td>
                                <?php
                                // Vehicle lookup inline for now
                                $vehicle_id = $booking['vehicle_id'];
                                $vstmt = $pdo->prepare("SELECT vehicle_name FROM vehicles WHERE id=?");
                                $vstmt->execute([$vehicle_id]);
                                $vehname = $vstmt->fetchColumn();
                                echo htmlspecialchars($vehname ?? 'N/A');
                                ?>
                            </td>
                            <td><?php echo date('M d, Y H:i', strtotime($booking['departure_time'])); ?></td>
                            <td><?php echo date('M d, Y H:i', strtotime($booking['arrival_time'])); ?></td>
                            <td><?php echo number_format($booking['price'], 2); ?></td>
                            <td>
                                <span class="badge <?php echo htmlspecialchars($booking['status']); ?>">
                                    <?php echo htmlspecialchars($booking['status']); ?>
                                </span>
                            </td>
                            <td><?php echo date('M d, Y H:i', strtotime($booking['created_at'])); ?></td>
                            <td>
                                <?php if ($booking['status'] === 'Pending'): ?>
                                    <form method="post" style="display:inline">
                                        <input type="hidden" name="booking_id" value="<?php echo (int)$booking['id']; ?>">
                                        <button type="submit" name="action" value="confirm" class="bookings-btn">Confirm</button>
                                    </form>
                                    <form method="post" style="display:inline">
                                        <input type="hidden" name="booking_id" value="<?php echo (int)$booking['id']; ?>">
                                        <button type="submit" name="action" value="cancel" class="bookings-btn cancel" onclick="return confirm('Cancel this booking?')">Cancel</button>
                                    </form>
                                <?php elseif ($booking['status'] === 'Confirmed'): ?>
                                    <form method="post" style="display:inline">
                                        <input type="hidden" name="booking_id" value="<?php echo (int)$booking['id']; ?>">
                                        <button type="submit" name="action" value="cancel" class="bookings-btn cancel" onclick="return confirm('Cancel this booking?')">Cancel</button>
                                    </form>
                                <?php else: ?>
                                    <span style="color:#bbb;">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
                <?php endif; ?>

                <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page - 1; ?>">&larr; Prev</a>
                    <?php endif; ?>
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="current"><?php echo $i; ?></span>
                        <?php elseif ($i == 1 || $i == $total_pages || abs($i-$page) <= 2): ?>
                            <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        <?php elseif ($i == $page-3 || $i == $page+3): ?>
                            ...
                        <?php endif; ?>
                    <?php endfor; ?>
                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?php echo $page + 1; ?>">Next &rarr;</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

            </section>
        </main>
    </div>
</body>
</html>
