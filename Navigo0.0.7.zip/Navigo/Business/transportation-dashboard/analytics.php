<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check auth
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}
// Only allow Transportation business type
if (!isset($_SESSION['business_type']) || $_SESSION['business_type'] !== 'transport') {
    header('Location: ../../Login/business_login.php');
    exit();
}

$business_id = $_SESSION['business_id'];

// Initialize database connection
$database = new Database();
$pdo = $database->getConnection();

// Vehicle statistics
$total_vehicles = 0;
$active_vehicles = 0;
$inactive_vehicles = 0;

// Trips stats
$total_trips = 0;
$trips_this_month = 0;
$total_passengers = 0;
$upcoming_trips = 0;

// Vehicle usage chart data
$vehicle_usage_labels = [];
$vehicle_usage_counts = [];

// Fetch vehicle stats
$stmt = $pdo->prepare("SELECT COUNT(*) as total, SUM(status='active') as active, SUM(status='inactive') as inactive FROM vehicles WHERE business_id = ?");
$stmt->execute([$business_id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if ($row) {
    $total_vehicles = (int)$row['total'];
    $active_vehicles = (int)$row['active'];
    $inactive_vehicles = (int)$row['inactive'];
}

// Fetch trip stats
$stmt = $pdo->prepare("SELECT COUNT(*) as total FROM trips WHERE business_id = ?");
$stmt->execute([$business_id]);
$total_trips = (int)($stmt->fetchColumn());

$stmt = $pdo->prepare("SELECT COUNT(*) FROM trips WHERE business_id=? AND MONTH(departure_time) = MONTH(CURDATE()) AND YEAR(departure_time)=YEAR(CURDATE())");
$stmt->execute([$business_id]);
$trips_this_month = (int)($stmt->fetchColumn());

$stmt = $pdo->prepare("SELECT SUM(passenger_count) FROM trips WHERE business_id=?");
$stmt->execute([$business_id]);
$total_passengers = (int)($stmt->fetchColumn() ?: 0);

$stmt = $pdo->prepare("SELECT COUNT(*) FROM trips WHERE business_id=? AND departure_time > NOW()");
$stmt->execute([$business_id]);
$upcoming_trips = (int)($stmt->fetchColumn());

// Vehicle usage: how many trips per vehicle
$stmt = $pdo->prepare("SELECT v.vehicle_name, COUNT(t.id) as trip_count 
                       FROM vehicles v 
                       LEFT JOIN trips t ON v.id = t.vehicle_id 
                       WHERE v.business_id=? 
                       GROUP BY v.id 
                       ORDER BY v.vehicle_name ASC");
$stmt->execute([$business_id]);
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $vehicle_usage_labels[] = $row['vehicle_name'];
    $vehicle_usage_counts[] = (int)$row['trip_count'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Transportation Analytics - NaviGo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Fonts & Icons -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="../../js/dark-mode.js"></script>
    <style>
        .analytics-cards {
            display: flex;
            gap: 24px;
            margin-bottom: 32px;
            flex-wrap: wrap;
        }
        .analytics-card {
            background: var(--dashboard-card-bg, #fff);
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
            padding: 24px;
            min-width: 200px;
            flex: 1 1 240px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .card-title {
            font-size: 1rem;
            color: #7B93B9;
            margin-bottom: 8px;
        }
        .card-value {
            font-size: 2.4rem;
            font-weight: 700;
            color: #1458a6;
        }
        .analytics-content {
            max-width: 1100px;
            margin: 32px auto;
            padding: 0 24px;
        }
        .chart-section {
            background: var(--dashboard-card-bg, #fff);
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.04);
            padding: 24px;
            margin-top: 16px;
        }
        .no-data-msg {
            color: #adadad;
            font-style: italic;
            text-align: center;
            padding: 32px 0;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <nav class="dashboard-sidebar">
            <div class="sidebar-header">
                <a href="../../Index.php" class="sidebar-logo">
                    <img src="../../Assets/Images/NaviGo_Logo.png" alt="NaviGo">
                </a>
                <h2 class="sidebar-title">NaviGo</h2>
            </div>
            <ul class="sidebar-menu">
                <li><a href="index.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="fleet.php"><i class="fas fa-car"></i> Fleet</a></li>
                <li><a href="bookings.php"><i class="fas fa-calendar-check"></i> Bookings</a></li>
                <li class="active"><a href="analytics.php"><i class="fas fa-chart-line"></i> Analytics</a></li>
                <li><a href="drivers.php"><i class="fas fa-users"></i> Drivers</a></li>
                <li><a href="reviews.php"><i class="fas fa-star"></i> Reviews</a></li>
                <li><a href="settings.php"><i class="fas fa-cog"></i> Settings</a></li>
                <li><a href="../../Login/logout.php" onclick="return confirm('Log out?');"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>
        <main class="dashboard-main">
            <header class="dashboard-header">
                <h1>Transportation Analytics</h1>
            </header>
            <section class="analytics-content">
                <div class="analytics-cards">
                    <div class="analytics-card">
                        <div class="card-title"><i class="fas fa-bus"></i> Total Vehicles</div>
                        <div class="card-value"><?php echo $total_vehicles; ?></div>
                    </div>
                    <div class="analytics-card">
                        <div class="card-title"><i class="fas fa-check-circle"></i> Active Vehicles</div>
                        <div class="card-value"><?php echo $active_vehicles; ?></div>
                    </div>
                    <div class="analytics-card">
                        <div class="card-title"><i class="fas fa-ban"></i> Inactive Vehicles</div>
                        <div class="card-value"><?php echo $inactive_vehicles; ?></div>
                    </div>
                    <div class="analytics-card">
                        <div class="card-title"><i class="fas fa-route"></i> Total Trips</div>
                        <div class="card-value"><?php echo $total_trips; ?></div>
                    </div>
                    <div class="analytics-card">
                        <div class="card-title"><i class="fas fa-calendar-alt"></i> This Month's Trips</div>
                        <div class="card-value"><?php echo $trips_this_month; ?></div>
                    </div>
                    <div class="analytics-card">
                        <div class="card-title"><i class="fas fa-user-friends"></i> Total Passengers</div>
                        <div class="card-value"><?php echo $total_passengers; ?></div>
                    </div>
                    <div class="analytics-card">
                        <div class="card-title"><i class="fas fa-clock"></i> Upcoming Trips</div>
                        <div class="card-value"><?php echo $upcoming_trips; ?></div>
                    </div>
                </div>

                <!-- Chart -->
                <div class="chart-section">
                    <h2><i class="fas fa-chart-pie"></i> Vehicle Usage (Trips per Vehicle)</h2>
                    <?php if (count($vehicle_usage_labels) > 0 && array_sum($vehicle_usage_counts) > 0): ?>
                        <canvas id="vehicleUsageChart" height="100"></canvas>
                    <?php else: ?>
                        <div class="no-data-msg">No vehicle trip data to display.</div>
                    <?php endif; ?>
                </div>

                <div class="chart-section">
                    <h2><i class="fas fa-calendar-week"></i> Monthly Trip Volume (past 6 months)</h2>
                    <canvas id="monthlyTripsChart" height="90"></canvas>
                </div>
            </section>
        </main>
    </div>
    <script>
    // Vehicle Usage Chart
    <?php if (count($vehicle_usage_labels) > 0 && array_sum($vehicle_usage_counts) > 0): ?>
    const usageCtx = document.getElementById('vehicleUsageChart').getContext('2d');
    new Chart(usageCtx, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($vehicle_usage_labels); ?>,
            datasets: [{
                label: 'Trips',
                data: <?php echo json_encode($vehicle_usage_counts); ?>,
                backgroundColor: 'rgba(30,167,255,0.60)',
                borderColor: '#1EA7FF',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero:true, ticks:{precision:0}}
            }
        }
    });
    <?php endif; ?>

    // Monthly Trips Chart
    <?php
    // Get past 6 months' trip count
    $monthly_labels = [];
    $monthly_trips = [];
    for ($i = 5; $i >= 0; $i--) {
        $date = new DateTime("first day of -$i months");
        $label = $date->format("M Y");
        $monthly_labels[] = $label;
        $year = $date->format("Y");
        $month = $date->format("m");
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM trips WHERE business_id=? AND MONTH(departure_time)=? AND YEAR(departure_time)=?");
        $stmt->execute([$business_id, $month, $year]);
        $monthly_trips[] = (int)$stmt->fetchColumn();
    }
    ?>
    const monthlyTripsChart = document.getElementById('monthlyTripsChart').getContext('2d');
    new Chart(monthlyTripsChart, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($monthly_labels); ?>,
            datasets: [{
                label: 'Trips',
                data: <?php echo json_encode($monthly_trips); ?>,
                backgroundColor: 'rgba(20,88,166,0.18)',
                borderColor: '#1458a6',
                borderWidth: 3,
                pointBackgroundColor: '#1EA7FF'
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true, ticks:{precision:0} }
            }
        }
    });
    </script>
</body>
</html>
