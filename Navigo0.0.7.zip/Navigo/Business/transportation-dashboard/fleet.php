<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check authentication for business user
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}
// Only allow Transportation business type
if (!isset($_SESSION['business_type']) || $_SESSION['business_type'] !== 'transport') {
    header('Location: ../../Login/business_login.php');
    exit();
}
$business_id = $_SESSION['business_id'];

// Initialize database connection
$database = new Database();
$pdo = $database->getConnection();

// Vehicle Actions: Delete (soft), Set active/inactive
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['vehicle_id'])) {
    $vehicle_id = intval($_POST['vehicle_id']);
    if (isset($_POST['action'])) {
        // Soft delete by setting to inactive
        if ($_POST['action'] === 'delete') {
            $stmt = $pdo->prepare("UPDATE vehicles SET status='inactive' WHERE id=? AND business_id=?");
            $stmt->execute([$vehicle_id, $business_id]);
        } elseif ($_POST['action'] === 'activate') {
            $stmt = $pdo->prepare("UPDATE vehicles SET status='active' WHERE id=? AND business_id=?");
            $stmt->execute([$vehicle_id, $business_id]);
        } elseif ($_POST['action'] === 'deactivate') {
            $stmt = $pdo->prepare("UPDATE vehicles SET status='inactive' WHERE id=? AND business_id=?");
            $stmt->execute([$vehicle_id, $business_id]);
        }
    }
    header("Location: fleet.php");
    exit();
}

// Pagination
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Vehicle filtering (All, Active, Inactive)
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
$status_query = '';
$status_bind = [];
if ($status_filter === 'active') {
    $status_query = "AND status='active'";
    $status_bind = ['active'];
} elseif ($status_filter === 'inactive') {
    $status_query = "AND status='inactive'";
    $status_bind = ['inactive'];
}

// Count for pagination
$count_stmt = $pdo->prepare("SELECT COUNT(*) FROM vehicles WHERE business_id=? $status_query");
$count_stmt->execute(array_merge([$business_id], $status_bind));
$total_vehicles = $count_stmt->fetchColumn();
$total_pages = max(1, ceil($total_vehicles / $per_page));

// Get vehicle list
$sql = "SELECT * FROM vehicles WHERE business_id=? $status_query ORDER BY id DESC LIMIT $per_page OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute(array_merge([$business_id], $status_bind));
$vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);

$vehicle_types = ['Bus', 'Van', 'Truck', 'Shuttle', 'Car', 'Other'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fleet Management - Transportation Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    <style>
        .fleet-table { width:100%; border-collapse:collapse; background:#fff; }
        .fleet-table th, .fleet-table td { border:1px solid #e5e5e5; padding:10px 8px; }
        .fleet-table th { background:#F5FAFF; color:#1458a6; font-weight:600; }
        .fleet-table tr:nth-child(even) { background:#f9f9f9; }
        .badge { display:inline-block; padding:0.3em 0.7em; border-radius:10px; font-size:0.95em; font-weight:600;}
        .badge.active { background:#d3f9d8; color:#209620;}
        .badge.inactive { background:#ffe5e8; color:#b8231d;}
        .fleet-btn { padding:0.3em 1em; border:none; border-radius:6px; background:#1482e5; color:white; cursor:pointer;}
        .fleet-btn.deactivate { background:#fc4646; }
        .fleet-btn.delete { background:#888; }
        .fleet-btn.activate { background:#18ad50; }
        .fleet-actions { display:flex; gap:0.3em; justify-content:center;}
        .pagination { margin-top:20px; text-align:center; }
        .pagination a, .pagination span { display:inline-block; margin:0 5px; padding:6px 12px; border-radius:5px; text-decoration:none; }
        .pagination .current { background:#1EA7FF; color:white; font-weight:600;}
        .pagination a { color:#1458a6; border:1px solid #eee; background:#fafbfd; }
        .tabbar {display:flex; gap:10px; margin-bottom:15px;}
        .tabbar a {padding:7px 22px; border-radius:6px; background:#e7f3fc; color:#1e293b; text-decoration:none;}
        .tabbar .active {background:#1EA7FF;color:white; font-weight:600;}
        .add-vehicle-btn {float:right; margin-bottom:10px; background:#1EA7FF; color:white; border:none; border-radius:8px; padding:8px 20px; font-weight:600;}
        .add-vehicle-btn:hover { background:#1883c4;}
        .fleet-header-wrap {display:flex; justify-content:space-between; align-items:center;}
    </style>
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>
        <main class="dashboard-main">
            <section>
                <div class="fleet-header-wrap">
                    <h1>Fleet Management</h1>
                    <a href="add-vehicle.php" class="add-vehicle-btn"><i class="fa fa-plus"></i> Add Vehicle</a>
                </div>
                <div class="tabbar">
                    <a href="?status=all" class="<?php if($status_filter=='all') echo 'active'; ?>">All</a>
                    <a href="?status=active" class="<?php if($status_filter=='active') echo 'active'; ?>">Active</a>
                    <a href="?status=inactive" class="<?php if($status_filter=='inactive') echo 'active'; ?>">Inactive</a>
                </div>
                <?php if (empty($vehicles)): ?>
                    <div class="notice warning" style="margin:1.5em 0">No vehicles found<?php echo ($status_filter=="active") ? " (Active)" : (($status_filter=="inactive")?" (Inactive)":""); ?>.</div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="fleet-table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Vehicle Name</th>
                                <th>Type</th>
                                <th>Plate Number</th>
                                <th>Capacity</th>
                                <th>Status</th>
                                <th class="fleet-actions">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($vehicles as $idx => $vehicle): ?>
                            <tr>
                                <td><?php echo $offset + $idx + 1; ?></td>
                                <td><?php echo htmlspecialchars($vehicle['vehicle_name']); ?></td>
                                <td><?php echo htmlspecialchars($vehicle['vehicle_type']); ?></td>
                                <td><?php echo htmlspecialchars($vehicle['plate_number']); ?></td>
                                <td><?php echo htmlspecialchars($vehicle['capacity']); ?></td>
                                <td>
                                    <span class="badge <?php echo htmlspecialchars(strtolower($vehicle['status'])); ?>">
                                        <?php echo ucfirst($vehicle['status']); ?>
                                    </span>
                                </td>
                                <td class="fleet-actions">
                                    <?php if ($vehicle['status'] === 'active'): ?>
                                        <form method="post" style="display:inline">
                                            <input type="hidden" name="vehicle_id" value="<?php echo intval($vehicle['id']); ?>">
                                            <button type="submit" name="action" value="deactivate" class="fleet-btn deactivate" onclick="return confirm('Deactivate this vehicle?');">Deactivate</button>
                                        </form>
                                    <?php else: ?>
                                        <form method="post" style="display:inline">
                                            <input type="hidden" name="vehicle_id" value="<?php echo intval($vehicle['id']); ?>">
                                            <button type="submit" name="action" value="activate" class="fleet-btn activate" onclick="return confirm('Activate this vehicle?');">Activate</button>
                                        </form>
                                    <?php endif; ?>
                                    <form method="post" style="display:inline">
                                        <input type="hidden" name="vehicle_id" value="<?php echo intval($vehicle['id']); ?>">
                                        <button type="submit" name="action" value="delete" class="fleet-btn delete" onclick="return confirm('Remove this vehicle? This will ONLY set it as inactive.');">Remove</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>

                <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?status=<?php echo urlencode($status_filter); ?>&page=<?php echo $page - 1; ?>">&larr; Prev</a>
                    <?php endif; ?>
                    <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="current"><?php echo $i; ?></span>
                        <?php elseif ($i == 1 || $i == $total_pages || abs($i-$page) <= 2): ?>
                            <a href="?status=<?php echo urlencode($status_filter); ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        <?php elseif ($i == $page-3 || $i == $page+3): ?>
                            ...
                        <?php endif; ?>
                    <?php endfor; ?>
                    <?php if ($page < $total_pages): ?>
                        <a href="?status=<?php echo urlencode($status_filter); ?>&page=<?php echo $page + 1; ?>">Next &rarr;</a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </section>
        </main>
    </div>
</body>
</html>
