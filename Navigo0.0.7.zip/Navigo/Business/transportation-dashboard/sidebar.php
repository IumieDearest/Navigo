<!-- Sidebar -->
<nav class="dashboard-sidebar">
    <div class="sidebar-header">
        <a href="../../Index.php" class="sidebar-logo">
            <img src="../../Assets/Images/NaviGo_Logo.png" alt="NaviGo">
            <span>NaviGo Transport</span>
        </a>
    </div>
    
    <div class="sidebar-nav">
        <div class="nav-section">
            <div class="nav-section-title">Main</div>
            <a href="index.php" class="nav-item">
                <i class="fas fa-tachometer-alt"></i>
                Dashboard
            </a>
            <a href="fleet.php" class="nav-item active">
                <i class="fas fa-car"></i>
                Fleet
            </a>
            <a href="bookings.php" class="nav-item">
                <i class="fas fa-calendar-check"></i>
                Bookings
            </a>
            <a href="analytics.php" class="nav-item">
                <i class="fas fa-chart-line"></i>
                Analytics
            </a>
        </div>
        
        <div class="nav-section">
            <div class="nav-section-title">Management</div>
            <a href="drivers.php" class="nav-item">
                <i class="fas fa-users"></i>
                Drivers
            </a>
            <a href="reviews.php" class="nav-item">
                <i class="fas fa-star"></i>
                Reviews
            </a>
            <a href="settings.php" class="nav-item">
                <i class="fas fa-cog"></i>
                Settings
            </a>
        </div>
    </div>
</nav>
