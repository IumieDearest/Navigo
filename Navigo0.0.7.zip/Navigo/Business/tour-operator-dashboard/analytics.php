<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check auth
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}
// Only allow Tour Operator business type
if (!isset($_SESSION['business_type']) || $_SESSION['business_type'] !== 'Tour Operator') {
    header('Location: ../../Login/business_login.php');
    exit();
}

$business_id = $_SESSION['business_id'];

// Initialize stats
$total_tours = 0;
$active_tours = 0;
$inactive_tours = 0;
$tours_this_month = 0;
$total_bookings = 0;
$total_customers = 0;
$revenue_this_month = 0;
$upcoming_tours = 0;

// Tour stats
$stmt = $pdo->prepare("SELECT COUNT(*) as total, SUM(status='active') as active, SUM(status='inactive') as inactive FROM tours WHERE business_id=?");
$stmt->execute([$business_id]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);
if ($row) {
    $total_tours = (int)$row['total'];
    $active_tours = (int)$row['active'];
    $inactive_tours = (int)$row['inactive'];
}

// Tours this month
$stmt = $pdo->prepare("SELECT COUNT(*) FROM tours WHERE business_id=? AND MONTH(start_date)=MONTH(CURDATE()) AND YEAR(start_date)=YEAR(CURDATE())");
$stmt->execute([$business_id]);
$tours_this_month = (int)$stmt->fetchColumn();

// Total bookings
$stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE business_id=?");
$stmt->execute([$business_id]);
$total_bookings = (int)$stmt->fetchColumn();

// Total unique customers
$stmt = $pdo->prepare("SELECT COUNT(DISTINCT user_id) FROM bookings WHERE business_id=?");
$stmt->execute([$business_id]);
$total_customers = (int)$stmt->fetchColumn();

// Revenue this month
$stmt = $pdo->prepare(
    "SELECT SUM(price) FROM bookings WHERE business_id=? AND MONTH(created_at)=MONTH(CURDATE()) AND YEAR(created_at)=YEAR(CURDATE()) AND status='Confirmed'"
);
$stmt->execute([$business_id]);
$revenue_this_month = (float)($stmt->fetchColumn() ?? 0);

// Upcoming tours
$stmt = $pdo->prepare("SELECT COUNT(*) FROM tours WHERE business_id=? AND start_date >= CURDATE()");
$stmt->execute([$business_id]);
$upcoming_tours = (int)$stmt->fetchColumn();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tour Operator Analytics</title>
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .stats-grid { display:flex; flex-wrap: wrap; gap:2rem; margin:2em 0 2.5em 0; }
        .stats-card { background: #fff; border-radius: 14px; box-shadow:0 2px 17px #203c5722; padding: 1.6em 2em; flex: 1 1 220px; min-width:220px; }
        .stats-title { color:#1EA7FF; font-weight:600; font-size:1.07em; margin-bottom:.4em; }
        .stats-value { font-size:1.7em; font-weight: bold; color: #22324B; }
        .section-heading { font-size:1.24em; font-weight:600; margin-bottom:.6em; }
        .dashboard-charts { display: flex; flex-wrap: wrap; gap:2em; }
        .chart-container { background:#fff; border-radius:12px; box-shadow:0 2px 14px #233b5711; padding:1.2em 2em; flex: 1 1 360px; min-width:320px; }
    </style>
</head>
<body>
<div class="dashboard-container">
    <?php include 'sidebar.php'; ?>
    <main class="dashboard-main">
        <h1>Analytics</h1>
        <div class="stats-grid">
            <div class="stats-card">
                <div class="stats-title">Total Tours</div>
                <div class="stats-value"><?php echo $total_tours; ?></div>
            </div>
            <div class="stats-card">
                <div class="stats-title">Active Tours</div>
                <div class="stats-value"><?php echo $active_tours; ?></div>
            </div>
            <div class="stats-card">
                <div class="stats-title">Inactive Tours</div>
                <div class="stats-value"><?php echo $inactive_tours; ?></div>
            </div>
            <div class="stats-card">
                <div class="stats-title">Tours This Month</div>
                <div class="stats-value"><?php echo $tours_this_month; ?></div>
            </div>
            <div class="stats-card">
                <div class="stats-title">Upcoming Tours</div>
                <div class="stats-value"><?php echo $upcoming_tours; ?></div>
            </div>
            <div class="stats-card">
                <div class="stats-title">Total Bookings</div>
                <div class="stats-value"><?php echo $total_bookings; ?></div>
            </div>
            <div class="stats-card">
                <div class="stats-title">Unique Customers</div>
                <div class="stats-value"><?php echo $total_customers; ?></div>
            </div>
            <div class="stats-card">
                <div class="stats-title">Revenue This Month</div>
                <div class="stats-value">₱<?php echo number_format($revenue_this_month, 2); ?></div>
            </div>
        </div>

        <div class="dashboard-charts">
        <!-- Bookings per Tour Chart -->
        <div class="chart-container">
            <div class="section-heading">Top 5 Tours by Bookings</div>
            <canvas id="topToursChart" height="185"></canvas>
            <?php
            // Top 5 tours by booking count
            $tour_names = [];
            $booking_counts = [];
            $stmt = $pdo->prepare("
                SELECT t.title, COUNT(b.id) as book_count
                FROM tours t
                LEFT JOIN bookings b ON t.id = b.tour_id
                WHERE t.business_id = ?
                GROUP BY t.id
                ORDER BY book_count DESC, t.title ASC
                LIMIT 5
            ");
            $stmt->execute([$business_id]);
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $tour_names[] = $row['title'];
                $booking_counts[] = (int)$row['book_count'];
            }
            ?>
        </div>
        <!-- Monthly Bookings Chart -->
        <div class="chart-container">
            <div class="section-heading">Bookings (Past 6 Months)</div>
            <canvas id="monthlyBookingsChart" height="185"></canvas>
            <?php
            // Past 6 months booking stats
            $monthly_labels = [];
            $monthly_bookings = [];
            for ($i = 5; $i >= 0; $i--) {
                $date = new DateTime("first day of -$i months");
                $label = $date->format("M Y");
                $monthly_labels[] = $label;
                $year = $date->format("Y");
                $month = $date->format("m");
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE business_id=? AND MONTH(created_at)=? AND YEAR(created_at)=?");
                $stmt->execute([$business_id, $month, $year]);
                $monthly_bookings[] = (int)$stmt->fetchColumn();
            }
            ?>
        </div>
        </div>
    </main>
</div>
<script>
<?php if (count($tour_names) > 0): ?>
const topToursChart = document.getElementById('topToursChart').getContext('2d');
new Chart(topToursChart, {
    type: 'bar',
    data: {
        labels: <?php echo json_encode($tour_names); ?>,
        datasets: [{
            label: 'Bookings',
            data: <?php echo json_encode($booking_counts); ?>,
            backgroundColor: 'rgba(30, 167, 255, 0.28)',
            borderColor: '#1ea7ff',
            borderWidth: 2,
            hoverBackgroundColor: 'rgba(20,88,166,0.23)'
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: { beginAtZero: true, ticks:{precision:0} }
        }
    }
});
<?php endif; ?>

// Monthly Bookings Chart
<?php if (count($monthly_labels) > 0): ?>
const monthlyBookingsChart = document.getElementById('monthlyBookingsChart').getContext('2d');
new Chart(monthlyBookingsChart, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($monthly_labels); ?>,
        datasets: [{
            label: 'Bookings',
            data: <?php echo json_encode($monthly_bookings); ?>,
            backgroundColor: 'rgba(31, 184, 98, 0.14)',
            borderColor: '#19a972',
            borderWidth: 3,
            pointBackgroundColor: '#19a972'
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: { beginAtZero: true, ticks:{precision:0} }
        }
    }
});
<?php endif; ?>
</script>
</body>
</html>
