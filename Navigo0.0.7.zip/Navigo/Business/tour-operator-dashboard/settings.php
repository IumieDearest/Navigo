<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check authentication for business user
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}

// Only allow Tour Operator business type
if (!isset($_SESSION['business_type']) || $_SESSION['business_type'] !== 'Tour Operator') {
    header('Location: ../../Login/business_login.php');
    exit();
}

$business_id = $_SESSION['business_id'];

$success = '';
$error = '';

// Fetch current business settings
$stmt = $pdo->prepare("SELECT * FROM businesses WHERE id=?");
$stmt->execute([$business_id]);
$business = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$business) {
    $error = "Business not found.";
}

// Handle settings form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $business_name = trim($_POST['business_name'] ?? '');
    $contact_email = trim($_POST['contact_email'] ?? '');
    $contact_phone = trim($_POST['contact_phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $notification_pref = isset($_POST['notification_pref']) ? 1 : 0;

    // Validation
    if ($business_name === '') $error = "Business name is required.";
    elseif ($contact_email === '' || !filter_var($contact_email, FILTER_VALIDATE_EMAIL)) $error = "A valid contact email is required.";
    elseif ($contact_phone === '') $error = "Contact phone is required.";

    if (!$error) {
        // Update business settings in database
        $stmt = $pdo->prepare("UPDATE businesses SET business_name=?, contact_email=?, contact_phone=?, address=?, receive_notifications=? WHERE id=?");
        $result = $stmt->execute([
            $business_name, $contact_email, $contact_phone, $address, $notification_pref, $business_id
        ]);

        if ($result) {
            $success = "Settings updated successfully.";
            // Refresh $business array so it reflects new changes in form
            $stmt = $pdo->prepare("SELECT * FROM businesses WHERE id=?");
            $stmt->execute([$business_id]);
            $business = $stmt->fetch(PDO::FETCH_ASSOC);
        } else {
            $error = "Failed to update settings. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Tour Operator Settings - NaviGo</title>
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    <style>
        .settings-form {
            max-width: 540px;
            margin: 2em auto;
            padding: 2em 2.5em 2em 2.5em;
            background: #fff;
            border-radius: 14px;
            box-shadow: 0 2px 16px rgba(32,51,105,0.07);
        }
        .settings-form .form-group {
            margin-bottom: 1.3em;
        }
        .settings-form label {
            display: block;
            font-weight: 500;
            margin-bottom: .15em;
        }
        .settings-form input[type="text"],
        .settings-form input[type="email"],
        .settings-form textarea {
            width: 100%;
            padding: .6em;
            border: 1px solid #d6d6e6;
            border-radius: 6px;
            font-size: 1em;
        }
        .settings-form textarea { min-height: 64px;}
        .settings-form input[type="checkbox"] {
            margin-right: 0.6em;
            vertical-align: middle;
        }
        .settings-form button[type="submit"] {
            background: #1ea7ff;
            color: #fff;
            border: none;
            border-radius: 6px;
            padding: 0.7em 2.3em;
            font-size: 1em;
            font-weight: 600;
            cursor: pointer;
            margin-top: 1em;
        }
        .success-message {
            display: block;
            margin: 1em auto 1.3em auto;
            max-width: 540px;
            background: #e7f8ee;
            color: #28996d;
            border-radius: 6px;
            padding: 1em 1.2em;
        }
        .error-message {
            display: block;
            margin: 1em auto 1.3em auto;
            max-width: 540px;
            background: #ffeaea;
            color: #cc281e;
            border-radius: 6px;
            padding: 1em 1.2em;
        }
        @media (max-width: 700px) {
            .settings-form { padding: 1.1em; }
        }
    </style>
</head>
<body>
<div class="dashboard-container">
    <?php include 'sidebar.php'; ?>
    <main class="dashboard-main">
        <section>
            <h1>Account Settings</h1>
            <?php if ($success): ?>
                <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <form class="settings-form" method="post" novalidate>
                <div class="form-group">
                    <label for="business_name">Business Name</label>
                    <input type="text" name="business_name" id="business_name" required
                        value="<?php echo htmlspecialchars($business['business_name'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="contact_email">Contact Email</label>
                    <input type="email" name="contact_email" id="contact_email" required
                        value="<?php echo htmlspecialchars($business['contact_email'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="contact_phone">Contact Phone</label>
                    <input type="text" name="contact_phone" id="contact_phone" required
                        value="<?php echo htmlspecialchars($business['contact_phone'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label for="address">Business Address</label>
                    <textarea name="address" id="address" rows="3"><?php echo htmlspecialchars($business['address'] ?? ''); ?></textarea>
                </div>
                <div class="form-group">
                    <label>
                        <input type="checkbox" name="notification_pref" <?php echo (!empty($business['receive_notifications'])) ? 'checked' : ''; ?>>
                        Receive email notifications (e.g. for new bookings)
                    </label>
                </div>
                <div>
                    <button type="submit">Save Changes</button>
                </div>
            </form>
        </section>
    </main>
</div>
</body>
</html>

