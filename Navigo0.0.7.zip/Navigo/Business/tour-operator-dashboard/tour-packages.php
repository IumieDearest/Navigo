<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Check authentication for tour operator business user
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}
if (!isset($_SESSION['business_type']) || $_SESSION['business_type'] !== 'Tour Operator') {
    header('Location: ../../Login/business_login.php');
    exit();
}
$business_id = $_SESSION['business_id'];

// Handle deletion (soft delete - set status to inactive)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete' && isset($_POST['tour_id'])) {
    $tour_id = intval($_POST['tour_id']);
    $stmt = $pdo->prepare("UPDATE tours SET status='inactive' WHERE id=? AND business_id=?");
    $stmt->execute([$tour_id, $business_id]);
    header("Location: tour-packages.php");
    exit();
}

// Pagination settings
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 10;
$offset = ($page - 1) * $per_page;

// Filter by status (active/inactive/all)
$status_filter = $_GET['status'] ?? 'all';
$status_query = '';
if ($status_filter == 'active') {
    $status_query = "AND t.status='active'";
} elseif ($status_filter == 'inactive') {
    $status_query = "AND t.status='inactive'";
}

// Fetch tours for this business
$stmt = $pdo->prepare("
    SELECT t.*, 
           (SELECT COUNT(*) FROM bookings b WHERE b.tour_id = t.id) as bookings_count
    FROM tours t
    WHERE t.business_id = ? $status_query
    ORDER BY t.start_date DESC, t.id DESC
    LIMIT $per_page OFFSET $offset
");
$stmt->execute([$business_id]);
$tours = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Count total for pagination
$stmt = $pdo->prepare("SELECT COUNT(*) FROM tours t WHERE t.business_id=? $status_query");
$stmt->execute([$business_id]);
$total_tours = $stmt->fetchColumn();
$total_pages = max(1, ceil($total_tours / $per_page));

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tour Packages - Tour Operator Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    <script src="../../js/dark-mode.js"></script>
    <script src="../../js/business-navigation.js"></script>
</head>
<body>
<div class="dashboard-container">
    <?php include 'sidebar.php'; ?>
    <main class="dashboard-main">
        <section>
            <div class="section-header" style="display:flex; align-items:center; justify-content:space-between;">
                <h2>Tour Packages</h2>
                <a href="create-tour.php" class="btn-main">+ Create Tour</a>
            </div>
            <div style="margin-bottom:0.7em;display:flex;align-items:center;gap:2em">
                <form method="get" style="display:inline">
                    <label for="status" style="font-size:0.95em;">Show:</label>
                    <select name="status" id="status" onchange="this.form.submit()" style="padding:0.2em 1.3em; border-radius:4px;">
                        <option value="all" <?php if($status_filter==='all') echo 'selected'; ?>>All Tours</option>
                        <option value="active" <?php if($status_filter==='active') echo 'selected'; ?>>Active Only</option>
                        <option value="inactive" <?php if($status_filter==='inactive') echo 'selected'; ?>>Inactive Only</option>
                    </select>
                </form>
            </div>
            <div class="responsive-table-wrapper">
                <table class="main-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Tour Name</th>
                            <th>Dates</th>
                            <th>Price</th>
                            <th>Capacity</th>
                            <th>Bookings</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (!$tours): ?>
                        <tr>
                            <td colspan="8" style="text-align:center; color:#666;">No tours found.</td>
                        </tr>
                    <?php else: foreach ($tours as $idx => $t): ?>
                        <tr>
                            <td><?php echo $offset + $idx + 1; ?></td>
                            <td>
                                <?php echo htmlspecialchars($t['name']); ?><br>
                                <a href="view-tour.php?id=<?php echo (int)$t['id']; ?>" class="small-link">Details</a>
                            </td>
                            <td>
                                <?php echo date('M d, Y', strtotime($t['start_date'])); ?>
                                &ndash;
                                <?php echo date('M d, Y', strtotime($t['end_date'])); ?>
                            </td>
                            <td>$<?php echo number_format($t['price'], 2); ?></td>
                            <td><?php echo (int)$t['capacity']; ?></td>
                            <td>
                                <?php echo (int)$t['bookings_count']; ?>
                                <a href="bookings.php?tour_id=<?php echo (int)$t['id']; ?>" title="View Bookings" class="small-link" style="margin-left:4px;">&#x1F441;</a>
                            </td>
                            <td>
                                <span class="status-badge status-<?php echo htmlspecialchars($t['status']); ?>">
                                    <?php echo ucfirst($t['status']); ?>
                                </span>
                            </td>
                            <td>
                                <a href="edit-tour.php?id=<?php echo (int)$t['id']; ?>" class="edit-btn">Edit</a>
                                <?php if($t['status'] === 'active'): ?>
                                    <form method="post" style="display:inline"
                                          onsubmit="return confirm('Are you sure you want to deactivate this tour?');">
                                        <input type="hidden" name="tour_id" value="<?php echo (int)$t['id']; ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <button type="submit" class="delete-btn">Deactivate</button>
                                    </form>
                                <?php else: ?>
                                    <span style="color:#999;font-size:0.98em;">&mdash;</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page-1; ?>&status=<?php echo urlencode($status_filter); ?>">&larr; Prev</a>
                    <?php endif; ?>
                    <?php for ($i=1; $i<=$total_pages; $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="current"><?php echo $i; ?></span>
                        <?php elseif ($i == 1 || $i == $total_pages || abs($i-$page) <= 2): ?>
                            <a href="?page=<?php echo $i; ?>&status=<?php echo urlencode($status_filter); ?>"><?php echo $i; ?></a>
                        <?php elseif ($i == $page-3 || $i == $page+3): ?>
                            ...
                        <?php endif; ?>
                    <?php endfor; ?>
                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?php echo $page+1; ?>&status=<?php echo urlencode($status_filter); ?>">Next &rarr;</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

        </section>
    </main>
</div>
</body>
</html>
