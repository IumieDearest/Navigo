<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Auth check for tour operator
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}
if (!isset($_SESSION['business_type']) || $_SESSION['business_type'] !== 'Tour Operator') {
    header('Location: ../../Login/business_login.php');
    exit();
}
$business_id = $_SESSION['business_id'];

$errors = [];
$success = '';

$tour_name = '';
$description = '';
$start_date = '';
$end_date = '';
$price = '';
$capacity = '';
$status = 'active';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tour_name = trim($_POST['tour_name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $start_date = trim($_POST['start_date'] ?? '');
    $end_date = trim($_POST['end_date'] ?? '');
    $price = trim($_POST['price'] ?? '');
    $capacity = trim($_POST['capacity'] ?? '');
    $status = trim($_POST['status'] ?? 'active');

    if ($tour_name === '') $errors[] = "Tour name is required.";
    if ($description === '') $errors[] = "Description is required.";
    if ($start_date === '') $errors[] = "Start date is required.";
    if ($end_date === '') $errors[] = "End date is required.";
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $start_date)) $errors[] = "Start date format is invalid.";
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $end_date)) $errors[] = "End date format is invalid.";
    if ($price === '' || !is_numeric($price) || $price < 0) $errors[] = "Enter a valid price.";
    if ($capacity === '' || !is_numeric($capacity) || intval($capacity) <= 0) $errors[] = "Enter a valid capacity.";
    if (!in_array($status, ['active', 'inactive'])) $status = 'active';
    if ($start_date !== '' && $end_date !== '' && $start_date > $end_date) $errors[] = "Start date must be before end date.";

    // Duplicate tour for name+date window in this business
    if (empty($errors)) {
        $stmt = $pdo->prepare(
            "SELECT id FROM tours WHERE business_id=? AND name=? AND start_date=?"
        );
        $stmt->execute([$business_id, $tour_name, $start_date]);
        if ($stmt->fetch()) {
            $errors[] = "A tour with this name and start date already exists.";
        }
    }

    // Insert tour if no errors
    if (empty($errors)) {
        $stmt = $pdo->prepare(
            "INSERT INTO tours (business_id, name, description, start_date, end_date, price, capacity, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
        );
        $res = $stmt->execute([
            $business_id,
            $tour_name,
            $description,
            $start_date,
            $end_date,
            $price,
            $capacity,
            $status
        ]);

        if ($res) {
            $success = "Tour created successfully!";
            // Reset fields
            $tour_name = $description = $start_date = $end_date = $price = $capacity = '';
            $status = 'active';
        } else {
            $errors[] = "Failed to create tour. Please try again.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Tour - Tour Operator Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    <style>
        .form-section { max-width: 560px; background: #fff; margin: 2em auto; padding:32px 36px 24px 36px; border-radius:13px; box-shadow:0 2px 16px #e6efff; }
        .form-section h1 { color: #1458a6; margin-bottom: 1.2em; }
        .form-group { margin-bottom: 1.1em; }
        .form-label { font-weight:500; color:#174167; margin-bottom:.3em; display:block;}
        .form-input, .form-textarea, .form-select { width:100%; padding:10px 11px; border-radius:7px; border:1px solid #e5e9f0; margin-top:5px; font-size:1.04em; }
        .form-textarea { min-height: 70px; max-height: 160px;}
        .form-input[type="date"] { max-width:180px;}
        .form-row { display: flex; gap: 20px; }
        .form-row > .form-group { flex:1;}
        .btn-main { background:#209cee; color:white; padding:10px 2.6em; font-size:1.12em; border:none; border-radius:8px; font-weight:600; box-shadow:0 1px 5px #dbebf8; cursor:pointer;}
        .notice.success { background:#d7faea; color:#0d7553;}
        .notice.error { background:#ffe7e4; color:#b8231d;}
    </style>
</head>
<body>
<div class="dashboard-container">
    <?php include 'sidebar.php'; ?>
    <main class="dashboard-main">
        <div class="form-section">
            <h1>Create New Tour</h1>
            <?php if ($success): ?>
                <div class="notice success" style="margin-bottom:1em"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            <?php if ($errors): ?>
                <div class="notice error" style="margin-bottom:1em">
                    <?php foreach ($errors as $e): ?>
                        <?php echo htmlspecialchars($e); ?><br>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <form method="post" autocomplete="off">
                <div class="form-group">
                    <label class="form-label" for="tour_name">Tour Name <span style="color:#b8231d">*</span></label>
                    <input class="form-input" type="text" name="tour_name" id="tour_name" required maxlength="120" value="<?php echo htmlspecialchars($tour_name); ?>">
                </div>
                <div class="form-group">
                    <label class="form-label" for="description">Description <span style="color:#b8231d">*</span></label>
                    <textarea class="form-textarea" name="description" id="description" maxlength="1024" required><?php echo htmlspecialchars($description); ?></textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="start_date">Start Date <span style="color:#b8231d">*</span></label>
                        <input class="form-input" type="date" name="start_date" id="start_date" required value="<?php echo htmlspecialchars($start_date); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="end_date">End Date <span style="color:#b8231d">*</span></label>
                        <input class="form-input" type="date" name="end_date" id="end_date" required value="<?php echo htmlspecialchars($end_date); ?>">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label class="form-label" for="price">Price ($) <span style="color:#b8231d">*</span></label>
                        <input class="form-input" type="number" name="price" id="price" required step="0.01" min="0" value="<?php echo htmlspecialchars($price); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="capacity">Capacity <span style="color:#b8231d">*</span></label>
                        <input class="form-input" type="number" name="capacity" id="capacity" required min="1" step="1" value="<?php echo htmlspecialchars($capacity); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label" for="status">Status</label>
                    <select class="form-select" name="status" id="status">
                        <option value="active"<?php if ($status==='active') echo ' selected'; ?>>Active</option>
                        <option value="inactive"<?php if ($status==='inactive') echo ' selected'; ?>>Inactive</option>
                    </select>
                </div>
                <button class="btn-main" type="submit">Create Tour</button>
            </form>
        </div>
    </main>
</div>
</body>
</html>
