<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Auth and business type check
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}
if (!isset($_SESSION['business_type']) || $_SESSION['business_type'] !== 'Tour Operator') {
    header('Location: ../../Login/business_login.php');
    exit();
}

$business_id = $_SESSION['business_id'];

// Pagination variables
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 10;
$offset = ($page - 1) * $per_page;

$success = '';
$error = '';

// Handle status/response actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['review_id']) && isset($_POST['action'])) {
    $review_id = intval($_POST['review_id']);
    $action = $_POST['action'];
    if ($action === 'hide') {
        $stmt = $pdo->prepare("UPDATE reviews SET is_hidden=1 WHERE id=? AND business_id=?");
        $stmt->execute([$review_id, $business_id]);
        $success = "Review hidden.";
    } elseif ($action === 'show') {
        $stmt = $pdo->prepare("UPDATE reviews SET is_hidden=0 WHERE id=? AND business_id=?");
        $stmt->execute([$review_id, $business_id]);
        $success = "Review is now public.";
    } elseif ($action === 'reply') {
        $reply = trim($_POST['reply_text'] ?? '');
        if ($reply !== '') {
            $stmt = $pdo->prepare("UPDATE reviews SET business_reply=? WHERE id=? AND business_id=?");
            $stmt->execute([$reply, $review_id, $business_id]);
            $success = "Reply saved.";
        } else {
            $error = "Reply cannot be empty.";
        }
    }
    // Prevent resubmission
    header("Location: reviews.php?page=$page");
    exit();
}

// Fetch total
$stmt = $pdo->prepare("SELECT COUNT(*) FROM reviews WHERE business_id=?");
$stmt->execute([$business_id]);
$total_reviews = (int)$stmt->fetchColumn();
$total_pages = max(1, ceil($total_reviews / $per_page));

// Fetch reviews with paging
$stmt = $pdo->prepare(
    "SELECT r.*, u.first_name, u.last_name, u.profile_pic, t.name as tour_name
     FROM reviews r
     JOIN users u ON r.user_id = u.id
     JOIN tours t ON r.tour_id = t.id
     WHERE r.business_id=?
     ORDER BY r.created_at DESC
     LIMIT $per_page OFFSET $offset"
);
$stmt->execute([$business_id]);
$reviews = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reviews - Tour Operator Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    <style>
        .reviews-table { width:100%; border-collapse:collapse; background:#fff; }
        .reviews-table th, .reviews-table td { border:1px solid #ebebeb; padding:12px 8px; }
        .reviews-table th { background:#f5faff; color:#1458a6; font-weight:600; }
        .reviews-table tr:nth-child(even) { background:#f9f9f9; }
        .user-col { display:flex; align-items:center; gap:0.7em;}
        .user-avatar { width:36px; height:36px; border-radius:50%; object-fit:cover; border:1px solid #dfdfdf;}
        .tour-name-badge { background:#e1eaff; color:#2053b6; border-radius:5px; padding:2px 8px; font-size:0.95em;}
        .review-rating { color:#FFB800; font-size:1.15em;}
        .badge.review-hidden { background:#fbeaf3; color:#b8231d;}
        .review-actions form { display:inline; }
        .review-actions button { margin-right:6px; border-radius:5px; padding:0.32em 0.85em; border:none; background:#e8e8e8; color:#444; font-weight:600; cursor:pointer;}
        .review-actions .hide-btn { background:#ffeaea; color:#b8231d;}
        .review-actions .show-btn { background:#e7f5e7; color:#1e8248;}
        .review-reply-box {margin-top:2px;}
        .review-reply-box textarea { font-size:1em; border-radius:5px; border:1px solid #ddd; min-height:32px; width:95%; resize:vertical; }
        .badge { display:inline-block; padding:0.3em 0.7em; border-radius:10px; font-size:0.95em; font-weight:600;}
        .pagination { margin-top:20px; text-align:center;}
        .pagination a, .pagination span { display:inline-block; margin:0 5px; padding:6px 12px; border-radius:5px; text-decoration:none; }
        .pagination .current { background:#1EA7FF; color:white; font-weight:600;}
        .pagination a { color:#1458a6; border:1px solid #eee; background:#fafbfd;}
    </style>
</head>
<body>
    <div class="dashboard-container">
        <?php include 'sidebar.php'; ?>
        <main class="dashboard-main">
            <section>
                <h1>Tour Reviews</h1>

                <?php if ($success): ?>
                    <div class="notice success"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="notice error"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>

                <?php if (empty($reviews)): ?>
                    <div class="notice info" style="margin:1.5em 0">No reviews yet for your tours.</div>
                <?php else: ?>
                <div class="table-responsive">
                <table class="reviews-table">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Tour</th>
                            <th>Rating</th>
                            <th>Review</th>
                            <th>Submitted</th>
                            <th>Status</th>
                            <th>Reply / Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($reviews as $rev): ?>
                        <tr>
                            <td>
                                <div class="user-col">
                                    <img class="user-avatar" src="<?php echo htmlspecialchars($rev['profile_pic'] ?? '../../Assets/Images/default_profile.png'); ?>" alt="avatar">
                                    <span><?php echo htmlspecialchars(trim($rev['first_name'] . ' ' . $rev['last_name'])); ?></span>
                                </div>
                            </td>
                            <td>
                                <span class="tour-name-badge"><?php echo htmlspecialchars($rev['tour_name']); ?></span>
                            </td>
                            <td>
                                <span class="review-rating">
                                    <?php
                                        $full_stars = intval($rev['rating']);
                                        $half_star = ($rev['rating'] - $full_stars) >= 0.5;
                                        for ($i = 0; $i < $full_stars; $i++) echo '★';
                                        if ($half_star) echo '½';
                                    ?>
                                </span>
                            </td>
                            <td style="max-width:280px;">
                                <?php echo nl2br(htmlspecialchars($rev['review_text'])); ?>
                            </td>
                            <td>
                                <?php echo date('M d, Y', strtotime($rev['created_at'])); ?>
                            </td>
                            <td>
                                <?php if (!empty($rev['is_hidden'])): ?>
                                    <span class="badge review-hidden">Hidden</span>
                                <?php else: ?>
                                    <span class="badge" style="background:#e7faf1;color:#188947;">Visible</span>
                                <?php endif; ?>
                            </td>
                            <td class="review-actions">
                                <!-- Hide/Show Review -->
                                <form method="post" style="display:inline">
                                    <input type="hidden" name="review_id" value="<?php echo $rev['id']; ?>">
                                    <?php if (!empty($rev['is_hidden'])): ?>
                                        <input type="hidden" name="action" value="show">
                                        <button type="submit" class="show-btn">Show</button>
                                    <?php else: ?>
                                        <input type="hidden" name="action" value="hide">
                                        <button type="submit" class="hide-btn">Hide</button>
                                    <?php endif; ?>
                                </form>
                                <!-- Reply Section -->
                                <div class="review-reply-box">
                                    <form method="post" style="margin-top:4px;">
                                        <input type="hidden" name="review_id" value="<?php echo $rev['id']; ?>">
                                        <input type="hidden" name="action" value="reply">
                                        <textarea name="reply_text" placeholder="Write a reply..." rows="2"><?php echo htmlspecialchars($rev['business_reply'] ?? ''); ?></textarea>
                                        <button type="submit">Reply</button>
                                    </form>
                                    <?php if ($rev['business_reply']): ?>
                                        <div style="margin-top:3px; font-size:0.98em; color:#2b645d;">
                                            <strong>Your reply:</strong> <?php echo nl2br(htmlspecialchars($rev['business_reply'])); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
                <?php endif; ?>

                <?php if ($total_pages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?php echo $page - 1; ?>">&larr; Prev</a>
                        <?php endif; ?>
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <?php if ($i == $page): ?>
                                <span class="current"><?php echo $i; ?></span>
                            <?php elseif ($i == 1 || $i == $total_pages || abs($i-$page) <= 2): ?>
                                <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            <?php elseif ($i == $page-3 || $i == $page+3): ?>
                                ...
                            <?php endif; ?>
                        <?php endfor; ?>
                        <?php if ($page < $total_pages): ?>
                            <a href="?page=<?php echo $page + 1; ?>">Next &rarr;</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

            </section>
        </main>
    </div>
</body>
</html>
