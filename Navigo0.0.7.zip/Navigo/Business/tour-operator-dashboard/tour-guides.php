<?php
session_start();
require_once '../../Config/Database.php';
require_once '../../Config/functions.php';

// Auth and business type check
if (!isset($_SESSION['business_id']) || $_SESSION['user_type'] !== 'business') {
    header('Location: ../../Login/business_login.php');
    exit();
}
if (!isset($_SESSION['business_type']) || $_SESSION['business_type'] !== 'Tour Operator') {
    header('Location: ../../Login/business_login.php');
    exit();
}
$business_id = $_SESSION['business_id'];

// Form handling logic
$errors = [];
$success = '';

$guide_id = '';
$name = '';
$email = '';
$phone = '';
$status = 'active';

// Handle form submission for add/update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guide_action'])) {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $status = trim($_POST['status'] ?? 'active');
    $guide_id = intval($_POST['guide_id'] ?? 0);

    // Validate
    if ($name === '') $errors[] = 'Name is required.';
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid email is required.';
    if ($phone === '') $errors[] = 'Phone is required.';
    if (!in_array($status, ['active', 'inactive'])) $status = 'active';

    // Prevent duplicate email for same business
    if (empty($errors)) {
        if ($_POST['guide_action'] === 'add') {
            $stmt = $pdo->prepare("SELECT id FROM tour_guides WHERE business_id=? AND email=?");
            $stmt->execute([$business_id, $email]);
            if ($stmt->fetch()) {
                $errors[] = 'A tour guide with this email already exists.';
            }
        } elseif ($_POST['guide_action'] === 'update') {
            $stmt = $pdo->prepare("SELECT id FROM tour_guides WHERE business_id=? AND email=? AND id!=?");
            $stmt->execute([$business_id, $email, $guide_id]);
            if ($stmt->fetch()) {
                $errors[] = 'A tour guide with this email already exists.';
            }
        }
    }

    if (empty($errors)) {
        if ($_POST['guide_action'] === 'add') {
            $stmt = $pdo->prepare("INSERT INTO tour_guides (business_id, name, email, phone, status) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$business_id, $name, $email, $phone, $status]);
            $success = "Tour guide added successfully!";
            $name = $email = $phone = '';
            $status = 'active';
        } elseif ($_POST['guide_action'] === 'update' && $guide_id > 0) {
            $stmt = $pdo->prepare("UPDATE tour_guides SET name=?, email=?, phone=?, status=? WHERE id=? AND business_id=?");
            $stmt->execute([$name, $email, $phone, $status, $guide_id, $business_id]);
            $success = "Tour guide updated.";
            $name = $email = $phone = '';
            $status = 'active';
            $guide_id = '';
        }
    }
}

// Handle delete
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_guide_id'])) {
    $delete_id = intval($_POST['delete_guide_id']);
    $stmt = $pdo->prepare("DELETE FROM tour_guides WHERE id=? AND business_id=?");
    $stmt->execute([$delete_id, $business_id]);
    $success = "Deleted tour guide.";
}

// Fetch tour guides list, with simple pagination
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 12;
$offset = ($page - 1) * $per_page;

$stmt = $pdo->prepare("SELECT SQL_CALC_FOUND_ROWS * FROM tour_guides WHERE business_id=? ORDER BY name ASC LIMIT $per_page OFFSET $offset");
$stmt->execute([$business_id]);
$tour_guides = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total_res = $pdo->query("SELECT FOUND_ROWS()");
$total_guides = (int)$total_res->fetchColumn();
$total_pages = max(1, ceil($total_guides / $per_page));

// If editing
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['edit']) && ctype_digit($_GET['edit'])) {
    $edit_id = intval($_GET['edit']);
    $stmt = $pdo->prepare("SELECT * FROM tour_guides WHERE business_id=? AND id=?");
    $stmt->execute([$business_id, $edit_id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($row) {
        $guide_id = $row['id'];
        $name = $row['name'];
        $email = $row['email'];
        $phone = $row['phone'];
        $status = $row['status'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tour Guides - Tour Operator Dashboard</title>
    <link rel="stylesheet" href="../../css/business-dashboard-shared.css">
    <link rel="stylesheet" href="../../css/business_dashboard.css">
    <style>
        .tg-table { width:100%; border-collapse:collapse; background:#fff; margin-top:2em;}
        .tg-table th, .tg-table td { border:1px solid #e5e5e5; padding:10px 8px;}
        .tg-table th { background:#F5FAFF; color:#1458a6; font-weight:600;}
        .tg-table tr:nth-child(even) { background:#fafbfd; }
        .status-badge { border-radius:10px; font-size:0.95em; padding:0.25em 0.65em; font-weight:600;}
        .status-active { background:#d3f9d8; color:#209620;}
        .status-inactive { background:#ffe8e8; color:#b8231d;}
        .notice { margin:1em 0;}
        .tg-form { margin:2em 0 1em 0; padding:1em; background:#f9fcfe; border:1px solid #e0e8f3; border-radius:8px; max-width:480px;}
        .tg-form-row { display:flex; gap:1em; }
        .tg-form .form-group { flex:1; }
        .pagination { margin-top:20px; text-align:center; }
        .pagination a, .pagination span { display:inline-block; margin:0 5px; padding:6px 12px; border-radius:5px; text-decoration:none; }
        .pagination .current { background:#1EA7FF; color:white; font-weight:600;}
        .pagination a { color:#1458a6; border:1px solid #eee; background:#fafbfd;}
        .edit-btn, .delete-btn { font-size:0.96em; padding:3px 10px; border:none; border-radius:6px; cursor:pointer;}
        .edit-btn { background:#4eddee; color:#12465c;}
        .delete-btn { background:#fc4646; color:#fff;}
    </style>
</head>
<body>
<div class="dashboard-container">
    <?php include 'sidebar.php'; ?>
    <main class="dashboard-main">
        <section>
            <h1>Tour Guides</h1>
            <?php if ($success): ?>
                <div class="notice success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            <?php if ($errors): ?>
                <div class="notice error">
                    <?php foreach ($errors as $e): ?>
                        <?php echo htmlspecialchars($e); ?><br>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <!-- Add/Edit Form -->
            <form class="tg-form" method="post" autocomplete="off">
                <input type="hidden" name="guide_id" value="<?php echo htmlspecialchars($guide_id); ?>">
                <div class="form-group">
                    <label class="form-label" for="guide_name">Full Name <span style="color:#b8231d">*</span></label>
                    <input class="form-input" type="text" name="name" id="guide_name" maxlength="100" required value="<?php echo htmlspecialchars($name); ?>">
                </div>
                <div class="tg-form-row">
                    <div class="form-group">
                        <label class="form-label" for="guide_email">Email <span style="color:#b8231d">*</span></label>
                        <input class="form-input" type="email" name="email" id="guide_email" maxlength="100" required value="<?php echo htmlspecialchars($email); ?>">
                    </div>
                    <div class="form-group">
                        <label class="form-label" for="guide_phone">Phone <span style="color:#b8231d">*</span></label>
                        <input class="form-input" type="text" name="phone" id="guide_phone" maxlength="30" required value="<?php echo htmlspecialchars($phone); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label class="form-label" for="guide_status">Status</label>
                    <select class="form-select" id="guide_status" name="status">
                        <option value="active"<?php if($status==='active')echo' selected';?>>Active</option>
                        <option value="inactive"<?php if($status==='inactive')echo' selected';?>>Inactive</option>
                    </select>
                </div>
                <button type="submit" name="guide_action" value="<?php echo $guide_id ? 'update':'add'; ?>" class="btn-main">
                    <?php echo $guide_id ? 'Update' : 'Add'; ?> Guide
                </button>
                <?php if($guide_id): ?>
                <a href="tour-guides.php" style="margin-left:24px; color:#666; text-decoration:underline;">Cancel Edit</a>
                <?php endif;?>
            </form>

            <!-- List of Tour Guides -->
            <div class="table-responsive">
                <table class="tg-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($tour_guides)): ?>
                        <tr><td colspan="6" style="text-align:center; color:#666;">No tour guides added yet.</td></tr>
                    <?php else: foreach ($tour_guides as $idx => $g): ?>
                        <tr>
                            <td><?php echo $offset+$idx+1; ?></td>
                            <td><?php echo htmlspecialchars($g['name']); ?></td>
                            <td><a href="mailto:<?php echo htmlspecialchars($g['email']); ?>"><?php echo htmlspecialchars($g['email']); ?></a></td>
                            <td><?php echo htmlspecialchars($g['phone']); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo htmlspecialchars($g['status']); ?>">
                                    <?php echo ucfirst($g['status']); ?>
                                </span>
                            </td>
                            <td>
                                <a href="tour-guides.php?edit=<?php echo (int)$g['id']; ?>" class="edit-btn">Edit</a>
                                <form method="post" style="display:inline" onsubmit="return confirm('Delete this tour guide?');">
                                    <input type="hidden" name="delete_guide_id" value="<?php echo (int)$g['id']; ?>">
                                    <button type="submit" class="delete-btn">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=<?php echo $page-1; ?>">&larr; Prev</a>
                    <?php endif; ?>
                    <?php for ($i=1; $i<=$total_pages; $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="current"><?php echo $i; ?></span>
                        <?php elseif ($i==1 || $i==$total_pages || abs($i-$page)<=2): ?>
                            <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        <?php elseif ($i == $page-3 || $i == $page+3): ?>
                            ...
                        <?php endif; ?>
                    <?php endfor; ?>
                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?php echo $page+1; ?>">Next &rarr;</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

        </section>
    </main>
</div>
</body>
</html>
