<?php /* Converted from src/components/HeroSection.tsx */ ?>
<link rel="stylesheet" href="../css/global.css" />
<link rel="stylesheet" href="../css/navbar.css" />
<link rel="stylesheet" href="../css/footer.css" />
<link rel="stylesheet" href="../css/home.css" />
<section class="hero" id="home">
        <div class="hero-background">
            <div class="hero-shape hero-shape-1"></div>
            <div class="hero-shape hero-shape-2"></div>
            <div class="hero-shape hero-shape-3"></div>
            <div class="floating-icon floating-icon-1">✈️</div>
            <div class="floating-icon floating-icon-2">🧭</div>
            <div class="floating-icon floating-icon-3">🌍</div>
            <div class="floating-icon floating-icon-4">📍</div>
            <div class="floating-icon floating-icon-5">⭐</div>
        </div>
        <div class="hero-content">
            <div class="hero-badge">
                <span class="badge-icon">🧭</span>
                <span class="badge-text">Your Adventure Starts Here</span>
                <span class="badge-dot"></span>
            </div>
            <h1 class="hero-title">
                <span class="title-line">Discover Your Next</span>
                <span class="title-gradient">Epic Adventure</span>
            </h1>
            <p class="hero-description">
                Generate personalized travel itineraries based on your preferences, budget, and interests.
            </p>
            <div class="hero-actions">
                <button class="btn btn-primary btn-large" id="start-journey-btn">
                    <span class="btn-icon">✈️</span>
                    Start Your Journey
                    <span class="btn-arrow">→</span>
                </button>
                <button class="btn btn-outline btn-large" id="explore-features-btn">
                    <span class="btn-icon">📍</span>
                    Explore Features
                </button>
            </div>
            <div class="trust-indicators">
                <div class="trust-item"><span class="trust-icon">⭐</span><span class="trust-text">4.9/5 Rating</span></div>
                <div class="trust-item"><span class="trust-icon">👥</span><span class="trust-text">50K+ Travelers</span></div>
                <div class="trust-item"><span class="trust-icon">🌍</span><span class="trust-text">190+ Countries</span></div>
            </div>
        </div>
    </section>

