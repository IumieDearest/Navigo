<?php /* Converted from src/components/Features.tsx */ ?>
<link rel="stylesheet" href="../css/global.css" />
<link rel="stylesheet" href="../css/navbar.css" />
<link rel="stylesheet" href="../css/footer.css" />
<link rel="stylesheet" href="../css/features.css" />
<section class="features-section" id="features">
        <div class="container">
            <div class="section-header">
                <h2>Why Choose NaviGo?</h2>
                <p>We\'re not just another booking platform. We\'re your intelligent travel companion that grows with you.</p>
            </div>

            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">🤖</div>
                    <h3>AI-Powered Planning</h3>
                    <p>Our intelligent system learns your preferences and creates personalized itineraries that match your travel style.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🔒</div>
                    <h3>Secure Data Storage</h3>
                    <p>All your travel information is encrypted and securely stored, accessible only to you across all your devices.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">👥</div>
                    <h3>Group Collaboration</h3>
                    <p>Plan trips with friends, family, or colleagues. Share itineraries, vote on activities, and coordinate seamlessly.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">📱</div>
                    <h3>Progressive Web App</h3>
                    <p>Access your travel plans anywhere with our mobile-optimized app that works online and offline.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🗓️</div>
                    <h3>Unified Dashboard</h3>
                    <p>All your trips, bookings, and travel documents in one synchronized dashboard across every device.</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">📈</div>
                    <h3>Business Savings</h3>
                    <p>Enterprise features including bulk discounts, expense tracking, and HR integrations to reduce travel costs.</p>
                </div>
            </div>
        </div>
    </section>

