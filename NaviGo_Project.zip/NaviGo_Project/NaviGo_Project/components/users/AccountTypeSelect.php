<?php /* Renamed from AccountTypeSelection */ ?>
<link rel="stylesheet" href="../../css/global.css" />
<link rel="stylesheet" href="../../css/user.css" />
<section class="account-type-selection" id="account-type-selection">
    <div class="container">
        <h2>Choose Account Type</h2>
        <p>Static placeholder converted from the TSX component.</p>
    </div>
</section>

