<?php /* Converted from src/components/BottomNavigation.tsx (placeholder) */ ?>
<link rel="stylesheet" href="../../css/global.css" />
<link rel="stylesheet" href="../../css/user.css" />
<nav class="bottom-navigation" id="bottom-navigation">
    <ul class="bottom-nav-list">
        <li><a href="#home">Home</a></li>
        <li><a href="#trips">Trips</a></li>
        <li><a href="#profile">Profile</a></li>
    </ul>
    </nav>

