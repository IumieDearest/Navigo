<?php /* Moved from components/AccountSettings.php */ ?>
<link rel="stylesheet" href="../../css/global.css" />
<link rel="stylesheet" href="../../css/user.css" />
<section class="account-settings" id="account-settings">
    <div class="container">
        <h2>Account Settings</h2>
        <p>This is a static placeholder converted from the TSX component.</p>
    </div>
</section>

