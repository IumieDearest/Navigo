<?php /* Moved from components/BillingPlans.php */ ?>
<link rel="stylesheet" href="../../css/global.css" />
<link rel="stylesheet" href="../../css/navbar.css" />
<link rel="stylesheet" href="../../css/footer.css" />
<link rel="stylesheet" href="../../css/pricing.css" />
<section class="pricing" id="pricing">
    <div class="container">
        <h2 class="section-title">Choose Your Plan</h2>
        <div class="pricing-grid">
            <div class="price-card">
                <h3>Starter</h3>
                <p class="price">$0<span>/mo</span></p>
                <ul class="features">
                    <li>Basic trip planning</li>
                    <li>Community support</li>
                    <li>Mobile access</li>
                </ul>
                <button class="btn btn-primary">Get Started</button>
            </div>
            <div class="price-card featured">
                <h3>Pro</h3>
                <p class="price">$9<span>/mo</span></p>
                <ul class="features">
                    <li>AI trip generation</li>
                    <li>Collaboration tools</li>
                    <li>Priority support</li>
                </ul>
                <button class="btn btn-primary">Try Pro</button>
            </div>
            <div class="price-card">
                <h3>Business</h3>
                <p class="price">$29<span>/mo</span></p>
                <ul class="features">
                    <li>Expense tracking</li>
                    <li>HR integrations</li>
                    <li>Custom policies</li>
                </ul>
                <button class="btn btn-primary">Contact Sales</button>
            </div>
        </div>
    </div>
</section>

