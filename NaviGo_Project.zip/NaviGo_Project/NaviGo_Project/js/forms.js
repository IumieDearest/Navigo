// ===== FORMS JAVASCRIPT =====
// Form validation and interactions

// ===== FORM VALIDATION CLASS =====
class FormValidator {
    constructor(form) {
        this.form = form;
        this.fields = form.querySelectorAll('input, textarea, select');
        this.submitButton = form.querySelector('button[type="submit"]');
        this.isValid = false;
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.setupRealTimeValidation();
        this.setupFormStyling();
    }
    
    setupEventListeners() {
        // Form submission
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
        
        // Field validation on blur
        this.fields.forEach(field => {
            field.addEventListener('blur', () => this.validateField(field));
            field.addEventListener('input', () => this.clearFieldError(field));
        });
        
        // Real-time validation for specific fields
        const emailField = this.form.querySelector('input[type="email"]');
        if (emailField) {
            emailField.addEventListener('input', () => this.validateEmail(emailField));
        }
        
        const phoneField = this.form.querySelector('input[type="tel"]');
        if (phoneField) {
            phoneField.addEventListener('input', () => this.formatPhone(phoneField));
        }
    }
    
    setupRealTimeValidation() {
        // Add real-time validation indicators
        this.fields.forEach(field => {
            const wrapper = document.createElement('div');
            wrapper.className = 'field-wrapper';
            field.parentNode.insertBefore(wrapper, field);
            wrapper.appendChild(field);
            
            // Add validation icon
            const icon = document.createElement('span');
            icon.className = 'validation-icon';
            wrapper.appendChild(icon);
        });
    }
    
    setupFormStyling() {
        // Add form styles if not already present
        if (document.querySelector('#form-styles')) {
            return;
        }
        
        const style = document.createElement('style');
        style.id = 'form-styles';
        style.textContent = `
            .field-wrapper {
                position: relative;
                display: flex;
                align-items: center;
            }
            
            .validation-icon {
                position: absolute;
                right: 12px;
                top: 50%;
                transform: translateY(-50%);
                width: 20px;
                height: 20px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 12px;
                font-weight: bold;
                opacity: 0;
                transition: all 0.3s ease;
            }
            
            .validation-icon.valid {
                background: #10b981;
                color: white;
                opacity: 1;
            }
            
            .validation-icon.invalid {
                background: #ef4444;
                color: white;
                opacity: 1;
            }
            
            .field-error {
                color: #ef4444;
                font-size: 12px;
                margin-top: 4px;
                display: none;
            }
            
            .field-error.show {
                display: block;
            }
            
            .form-group.error input,
            .form-group.error textarea {
                border-color: #ef4444;
                box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
            }
            
            .form-group.success input,
            .form-group.success textarea {
                border-color: #10b981;
                box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.1);
            }
            
            .form-loading {
                opacity: 0.6;
                pointer-events: none;
            }
            
            .form-loading .submit-button {
                position: relative;
            }
            
            .form-loading .submit-button::after {
                content: '';
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 20px;
                height: 20px;
                border: 2px solid transparent;
                border-top: 2px solid currentColor;
                border-radius: 50%;
                animation: spin 1s linear infinite;
            }
            
            @keyframes spin {
                0% { transform: translate(-50%, -50%) rotate(0deg); }
                100% { transform: translate(-50%, -50%) rotate(360deg); }
            }
        `;
        
        document.head.appendChild(style);
    }
    
    handleSubmit(event) {
        event.preventDefault();
        
        // Validate all fields
        this.validateAllFields();
        
        if (this.isValid) {
            this.submitForm();
        } else {
            this.showFormError('Please correct the errors below and try again.');
        }
    }
    
    validateAllFields() {
        this.isValid = true;
        
        this.fields.forEach(field => {
            if (!this.validateField(field)) {
                this.isValid = false;
            }
        });
    }
    
    validateField(field) {
        const value = field.value.trim();
        const fieldName = field.name || field.id;
        const fieldType = field.type;
        const isRequired = field.hasAttribute('required');
        
        // Clear previous errors
        this.clearFieldError(field);
        
        // Required field validation
        if (isRequired && !value) {
            this.showFieldError(field, `${this.getFieldLabel(field)} is required.`);
            return false;
        }
        
        // Skip validation if field is empty and not required
        if (!value && !isRequired) {
            this.showFieldSuccess(field);
            return true;
        }
        
        // Type-specific validation
        switch (fieldType) {
            case 'email':
                return this.validateEmail(field);
            case 'tel':
                return this.validatePhone(field);
            case 'url':
                return this.validateURL(field);
            case 'number':
                return this.validateNumber(field);
            default:
                return this.validateText(field);
        }
    }
    
    validateEmail(field) {
        const value = field.value.trim();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        
        if (value && !emailRegex.test(value)) {
            this.showFieldError(field, 'Please enter a valid email address.');
            return false;
        }
        
        this.showFieldSuccess(field);
        return true;
    }
    
    validatePhone(field) {
        const value = field.value.trim();
        const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
        
        if (value && !phoneRegex.test(value.replace(/[\s\-\(\)]/g, ''))) {
            this.showFieldError(field, 'Please enter a valid phone number.');
            return false;
        }
        
        this.showFieldSuccess(field);
        return true;
    }
    
    validateURL(field) {
        const value = field.value.trim();
        const urlRegex = /^https?:\/\/.+\..+/;
        
        if (value && !urlRegex.test(value)) {
            this.showFieldError(field, 'Please enter a valid URL.');
            return false;
        }
        
        this.showFieldSuccess(field);
        return true;
    }
    
    validateNumber(field) {
        const value = field.value.trim();
        const min = field.getAttribute('min');
        const max = field.getAttribute('max');
        
        if (value && isNaN(value)) {
            this.showFieldError(field, 'Please enter a valid number.');
            return false;
        }
        
        if (value && min && parseFloat(value) < parseFloat(min)) {
            this.showFieldError(field, `Value must be at least ${min}.`);
            return false;
        }
        
        if (value && max && parseFloat(value) > parseFloat(max)) {
            this.showFieldError(field, `Value must be no more than ${max}.`);
            return false;
        }
        
        this.showFieldSuccess(field);
        return true;
    }
    
    validateText(field) {
        const value = field.value.trim();
        const minLength = field.getAttribute('minlength');
        const maxLength = field.getAttribute('maxlength');
        
        if (minLength && value.length < parseInt(minLength)) {
            this.showFieldError(field, `Must be at least ${minLength} characters long.`);
            return false;
        }
        
        if (maxLength && value.length > parseInt(maxLength)) {
            this.showFieldError(field, `Must be no more than ${maxLength} characters long.`);
            return false;
        }
        
        this.showFieldSuccess(field);
        return true;
    }
    
    showFieldError(field, message) {
        const formGroup = field.closest('.form-group');
        const wrapper = field.closest('.field-wrapper');
        const icon = wrapper.querySelector('.validation-icon');
        
        // Add error class
        formGroup.classList.add('error');
        formGroup.classList.remove('success');
        
        // Update icon
        if (icon) {
            icon.textContent = '✕';
            icon.className = 'validation-icon invalid';
        }
        
        // Show error message
        this.showErrorMessage(formGroup, message);
    }
    
    showFieldSuccess(field) {
        const formGroup = field.closest('.form-group');
        const wrapper = field.closest('.field-wrapper');
        const icon = wrapper.querySelector('.validation-icon');
        
        // Add success class
        formGroup.classList.add('success');
        formGroup.classList.remove('error');
        
        // Update icon
        if (icon) {
            icon.textContent = '✓';
            icon.className = 'validation-icon valid';
        }
        
        // Clear error message
        this.clearErrorMessage(formGroup);
    }
    
    clearFieldError(field) {
        const formGroup = field.closest('.form-group');
        const wrapper = field.closest('.field-wrapper');
        const icon = wrapper.querySelector('.validation-icon');
        
        // Remove classes
        formGroup.classList.remove('error', 'success');
        
        // Clear icon
        if (icon) {
            icon.className = 'validation-icon';
        }
        
        // Clear error message
        this.clearErrorMessage(formGroup);
    }
    
    showErrorMessage(formGroup, message) {
        // Remove existing error message
        this.clearErrorMessage(formGroup);
        
        // Create error message element
        const errorElement = document.createElement('div');
        errorElement.className = 'field-error show';
        errorElement.textContent = message;
        
        // Add to form group
        formGroup.appendChild(errorElement);
    }
    
    clearErrorMessage(formGroup) {
        const existingError = formGroup.querySelector('.field-error');
        if (existingError) {
            existingError.remove();
        }
    }
    
    showFormError(message) {
        // Remove existing form error
        this.clearFormError();
        
        // Create form error element
        const errorElement = document.createElement('div');
        errorElement.className = 'form-error';
        errorElement.style.cssText = `
            background: #fef2f2;
            border: 1px solid #fecaca;
            color: #dc2626;
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 16px;
            font-size: 14px;
        `;
        errorElement.textContent = message;
        
        // Insert at the beginning of the form
        this.form.insertBefore(errorElement, this.form.firstChild);
        
        // Scroll to error
        errorElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    
    clearFormError() {
        const existingError = this.form.querySelector('.form-error');
        if (existingError) {
            existingError.remove();
        }
    }
    
    async submitForm() {
        // Show loading state
        this.setLoadingState(true);
        
        try {
            // Get form data
            const formData = new FormData(this.form);
            const data = Object.fromEntries(formData);
            
            // Simulate API call
            await this.simulateAPICall(data);
            
            // Show success message
            this.showFormSuccess('Form submitted successfully!');
            
            // Reset form
            this.form.reset();
            this.clearAllFieldStates();
            
        } catch (error) {
            // Show error message
            this.showFormError('An error occurred. Please try again.');
        } finally {
            // Hide loading state
            this.setLoadingState(false);
        }
    }
    
    async simulateAPICall(data) {
        // Simulate network delay
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                // Simulate random success/failure
                if (Math.random() > 0.1) { // 90% success rate
                    resolve(data);
                } else {
                    reject(new Error('Network error'));
                }
            }, 2000);
        });
    }
    
    showFormSuccess(message) {
        // Remove existing messages
        this.clearFormError();
        
        // Create success element
        const successElement = document.createElement('div');
        successElement.className = 'form-success';
        successElement.style.cssText = `
            background: #f0fdf4;
            border: 1px solid #bbf7d0;
            color: #166534;
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 16px;
            font-size: 14px;
        `;
        successElement.textContent = message;
        
        // Insert at the beginning of the form
        this.form.insertBefore(successElement, this.form.firstChild);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            if (successElement.parentNode) {
                successElement.remove();
            }
        }, 5000);
    }
    
    setLoadingState(loading) {
        if (loading) {
            this.form.classList.add('form-loading');
            if (this.submitButton) {
                this.submitButton.disabled = true;
                this.submitButton.classList.add('submit-button');
            }
        } else {
            this.form.classList.remove('form-loading');
            if (this.submitButton) {
                this.submitButton.disabled = false;
                this.submitButton.classList.remove('submit-button');
            }
        }
    }
    
    clearAllFieldStates() {
        this.fields.forEach(field => {
            this.clearFieldError(field);
        });
    }
    
    getFieldLabel(field) {
        const label = this.form.querySelector(`label[for="${field.id}"]`);
        return label ? label.textContent : field.name || field.id;
    }
    
    formatPhone(field) {
        let value = field.value.replace(/\D/g, '');
        
        if (value.length >= 6) {
            value = value.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
        } else if (value.length >= 3) {
            value = value.replace(/(\d{3})(\d{0,3})/, '($1) $2');
        }
        
        field.value = value;
    }
}

// ===== CONTACT FORM SPECIFIC FUNCTIONALITY =====
class ContactFormManager {
    constructor() {
        this.contactForm = document.getElementById('contact-form');
        this.validator = null;
        
        this.init();
    }
    
    init() {
        if (this.contactForm) {
            this.validator = new FormValidator(this.contactForm);
            this.setupContactSpecificFeatures();
        }
    }
    
    setupContactSpecificFeatures() {
        // Add character counter for message field
        const messageField = this.contactForm.querySelector('textarea[name="message"]');
        if (messageField) {
            this.addCharacterCounter(messageField);
        }
        
        // Add auto-save functionality
        this.setupAutoSave();
    }
    
    addCharacterCounter(textarea) {
        const maxLength = textarea.getAttribute('maxlength') || 500;
        const counter = document.createElement('div');
        counter.className = 'character-counter';
        counter.style.cssText = `
            text-align: right;
            font-size: 12px;
            color: var(--text-tertiary);
            margin-top: 4px;
        `;
        
        textarea.parentNode.appendChild(counter);
        
        const updateCounter = () => {
            const remaining = maxLength - textarea.value.length;
            counter.textContent = `${textarea.value.length}/${maxLength} characters`;
            counter.style.color = remaining < 50 ? '#ef4444' : 'var(--text-tertiary)';
        };
        
        textarea.addEventListener('input', updateCounter);
        updateCounter();
    }
    
    setupAutoSave() {
        const fields = this.contactForm.querySelectorAll('input, textarea');
        const storageKey = 'navigo-contact-form-draft';
        
        // Load saved data
        this.loadDraft();
        
        // Save on input
        fields.forEach(field => {
            field.addEventListener('input', () => {
                this.saveDraft();
            });
        });
        
        // Clear draft on successful submit
        this.contactForm.addEventListener('submit', () => {
            setTimeout(() => {
                localStorage.removeItem(storageKey);
            }, 1000);
        });
    }
    
    saveDraft() {
        const formData = new FormData(this.contactForm);
        const data = Object.fromEntries(formData);
        localStorage.setItem('navigo-contact-form-draft', JSON.stringify(data));
    }
    
    loadDraft() {
        const saved = localStorage.getItem('navigo-contact-form-draft');
        if (saved) {
            try {
                const data = JSON.parse(saved);
                Object.keys(data).forEach(key => {
                    const field = this.contactForm.querySelector(`[name="${key}"]`);
                    if (field && data[key]) {
                        field.value = data[key];
                    }
                });
            } catch (error) {
                console.error('Error loading form draft:', error);
            }
        }
    }
}

// ===== INITIALIZE FORMS =====
document.addEventListener('DOMContentLoaded', function() {
    // Initialize contact form
    new ContactFormManager();
    
    // Initialize other forms
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        if (!form.id || form.id !== 'contact-form') {
            new FormValidator(form);
        }
    });
});

// ===== EXPORT FOR TESTING =====
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { FormValidator, ContactFormManager };
}
