<footer class="site-footer">
    <div class="footer-inner">
        <p>© 2025 NaviGo Adventure Travels. All rights reserved.</p>
        <div class="footer-links">
            <a href="#">Privacy Policy</a>
            <a href="#">Terms of Service</a>
            <a href="#">Cookie Policy</a>
        </div>
    </div>
</footer>

