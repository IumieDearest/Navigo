<?php include './navbar.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="NaviGo - Your intelligent travel companion. AI-powered travel planning, group collaboration, and seamless booking experiences.">
    <meta name="keywords" content="travel, planning, AI, booking, itinerary, group travel, NaviGo">
    <meta name="author" content="NaviGo Adventure Travels">
    <title>NaviGo - Discover Your Next Epic Adventure</title>
    <link rel="icon" type="image/png" href="./assets/images/navigo-logo.png">
    <link rel="stylesheet" href="./css/global.css">
    <link rel="stylesheet" href="./css/navbar.css">
    <link rel="stylesheet" href="./css/welcome.css">
</head>
<body>
    <body class="welcome">
        <div class="w-container">
            <div class="w-logo">NAVIGO</div>
            <div class="w-tagline">Ready for Adventure?</div>
            <div class="w-heading">Welcome to NaviGo</div>
            <p class="w-desc">Your journey begins here. Choose your travel companion and unlock a world of intelligent planning, seamless experiences, and unforgettable adventures.</p>

            <div class="w-grid">
                <div class="w-card">
                    <div class="w-top">
                        <span class="w-badge">10 TRAVEL PASS</span>
                        <span class="w-type">INDIVIDUAL</span>
                    </div>
                    <div class="w-title">Personal Account</div>
                    <ul class="w-list">
                        <li><span class="w-dot"></span>AI-powered recommendations</li>
                        <li><span class="w-dot"></span>Secure itinerary storage</li>
                        <li><span class="w-dot"></span>Group collaboration</li>
                        <li><span class="w-dot"></span>Cost optimization</li>
                        <li><span class="w-dot"></span>Cross-platform sync</li>
                    </ul>
                    <div class="w-actions">
                        <a class="w-btn" href="./individual.html">Start Your Journey →</a>
                        <span class="w-note">Free plan available</span>
                    </div>
                </div>

                <div class="w-card">
                    <div class="w-top">
                        <span class="w-badge">PARTNER ACCESS</span>
                        <span class="w-type">ENTERPRISE</span>
                    </div>
                    <div class="w-title">Business Partner</div>
                    <ul class="w-list">
                        <li><span class="w-dot"></span>Booking & inventory management</li>
                        <li><span class="w-dot"></span>Advanced analytics dashboard</li>
                        <li><span class="w-dot"></span>System integrations</li>
                        <li><span class="w-dot"></span>Bulk discount controls</li>
                        <li><span class="w-dot"></span>Enterprise security</li>
                    </ul>
                    <div class="w-actions">
                        <a class="w-btn" href="./enterprise.html">Join Our Network →</a>
                        <span class="w-note">Custom enterprise pricing</span>
                    </div>
                </div>
            </div>

            <p class="w-footer-link">Already have an account? <a href="./individual.html">Sign In to Your Journey</a></p>
            <p class="w-quote">“The world is a book, and those who do not travel read only one page.” — Saint Augustine</p>
        </div>
        <script src="./js/navbar.js"></script>
    </body>
</body>
</html>

