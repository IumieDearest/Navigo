<nav class="navbar" id="navbar">
    <div class="nav-container">
        <div class="nav-logo">
            <img src="./assets/images/navigo-logo.png" alt="NaviGo Logo" class="logo-img">
            <span class="logo-text">NaviGo</span>
        </div>
        <div class="nav-menu" id="nav-menu">
            <a href="#home" class="nav-link active">Home</a>
            <a href="#features" class="nav-link">Features</a>
            <a href="#pricing" class="nav-link">Pricing</a>
            <a href="#contact" class="nav-link">Contact</a>
        </div>
        <div class="nav-actions">
            <button class="btn btn-outline" id="login-btn">Login</button>
            <button class="btn btn-primary" id="signup-btn">Get Started</button>
            <button class="theme-toggle" id="theme-toggle" aria-label="Toggle dark mode">
                <span class="theme-icon">🌙</span>
            </button>
        </div>
        <button class="mobile-menu-toggle" id="mobile-menu-toggle" aria-label="Toggle mobile menu">
            <span class="hamburger-line"></span>
            <span class="hamburger-line"></span>
            <span class="hamburger-line"></span>
        </button>
    </div>
</nav>

