<?php
// Business Travel Management Component
$companyStats = [
    'totalEmployees' => 150,
    'activeTravel' => 12,
    'monthlySpend' => 45600,
    'savings' => 8200,
    'avgTripCost' => 1250,
    'pendingApprovals' => 5
];

$travelPolicies = [
    [
        'category' => 'Flight Booking',
        'policy' => 'Economy class for domestic, Business for international >8hrs',
        'compliance' => 95,
        'status' => 'active'
    ],
    [
        'category' => 'Accommodation',
        'policy' => '4-star hotels, max $200/night domestic, $300/night international',
        'compliance' => 87,
        'status' => 'active'
    ],
    [
        'category' => 'Meal Allowance',
        'policy' => '$75/day domestic, $100/day international',
        'compliance' => 92,
        'status' => 'active'
    ],
    [
        'category' => 'Approval Process',
        'policy' => 'Manager approval required for trips >$2000',
        'compliance' => 100,
        'status' => 'active'
    ]
];

$recentBookings = [
    [
        'employee' => 'Sarah Johnson',
        'department' => 'Sales',
        'destination' => 'New York, NY',
        'dates' => 'Mar 15-18, 2024',
        'purpose' => 'Client Meeting',
        'cost' => 1850,
        'status' => 'approved',
        'bookingRef' => 'BK-001234'
    ],
    [
        'employee' => 'Mike Chen',
        'department' => 'Engineering',
        'destination' => 'San Francisco, CA',
        'dates' => 'Mar 20-25, 2024',
        'purpose' => 'Conference',
        'cost' => 2200,
        'status' => 'pending',
        'bookingRef' => 'BK-001235'
    ],
    [
        'employee' => 'Emma Wilson',
        'department' => 'Marketing',
        'destination' => 'London, UK',
        'dates' => 'Apr 5-12, 2024',
        'purpose' => 'Trade Show',
        'cost' => 3400,
        'status' => 'approved',
        'bookingRef' => 'BK-001236'
    ]
];

$departments = [
    ['name' => 'Sales', 'employees' => 45, 'trips' => 28, 'spend' => 18500, 'budget' => 20000],
    ['name' => 'Engineering', 'employees' => 65, 'trips' => 15, 'spend' => 12200, 'budget' => 15000],
    ['name' => 'Marketing', 'employees' => 25, 'trips' => 22, 'spend' => 11800, 'budget' => 12000],
    ['name' => 'Operations', 'employees' => 15, 'trips' => 8, 'spend' => 3100, 'budget' => 5000]
];

function getStatusColor($status) {
    switch ($status) {
        case 'approved': return 'default';
        case 'pending': return 'secondary';
        case 'rejected': return 'destructive';
        default: return 'outline';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Business Travel Management - NaviGo</title>
    <link rel="stylesheet" href="../css/global.css">
    <link rel="stylesheet" href="../css/navbar.css">
    <link rel="stylesheet" href="../css/footer.css">
    <link rel="stylesheet" href="../css/business.css">
</head>
<body>
    <?php include '../navbar.php'; ?>
    
    <main class="business-container">
        <div class="space-y-6">
            <!-- Header -->
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                    <h2 class="text-2xl font-bold">Business Travel Management</h2>
                    <p class="text-gray-600">Centralized corporate travel dashboard and policy management</p>
                </div>
                <div class="flex gap-2">
                    <button class="btn btn-outline">
                        <span class="icon">⚙️</span>
                        Settings
                    </button>
                    <button class="btn btn-primary">
                        <span class="icon">➕</span>
                        New Travel Request
                    </button>
                </div>
            </div>

            <!-- Period Selector -->
            <div class="flex justify-between items-center">
                <h3 class="text-lg font-semibold">Travel Overview</h3>
                <select class="period-selector">
                    <option value="current-month">Current Month</option>
                    <option value="last-month">Last Month</option>
                    <option value="current-quarter">Current Quarter</option>
                    <option value="current-year">Current Year</option>
                </select>
            </div>

            <!-- Key Metrics -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Total Employees</h3>
                        <span class="icon">👥</span>
                    </div>
                    <div class="card-content">
                        <div class="metric-value"><?php echo $companyStats['totalEmployees']; ?></div>
                        <p class="metric-description">
                            <?php echo $companyStats['activeTravel']; ?> currently traveling
                        </p>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Monthly Spend</h3>
                        <span class="icon">💰</span>
                    </div>
                    <div class="card-content">
                        <div class="metric-value">$<?php echo number_format($companyStats['monthlySpend']); ?></div>
                        <p class="metric-description">-12% from last month</p>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Savings</h3>
                        <span class="icon">📉</span>
                    </div>
                    <div class="card-content">
                        <div class="metric-value text-green-600">$<?php echo number_format($companyStats['savings']); ?></div>
                        <p class="metric-description">15% cost reduction</p>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Pending Approvals</h3>
                        <span class="icon">📅</span>
                    </div>
                    <div class="card-content">
                        <div class="metric-value"><?php echo $companyStats['pendingApprovals']; ?></div>
                        <p class="metric-description">Require your attention</p>
                    </div>
                </div>
            </div>

            <!-- Tabs -->
            <div class="tabs-container">
                <div class="tabs-list">
                    <button class="tab-trigger active" data-tab="overview">Overview</button>
                    <button class="tab-trigger" data-tab="bookings">Bookings</button>
                    <button class="tab-trigger" data-tab="departments">Departments</button>
                    <button class="tab-trigger" data-tab="policies">Policies</button>
                    <button class="tab-trigger" data-tab="reports">Reports</button>
                </div>

                <!-- Overview Tab -->
                <div class="tab-content active" id="overview">
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <!-- Travel Spend by Department -->
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Travel Spend by Department</h3>
                            </div>
                            <div class="card-content">
                                <div class="space-y-4">
                                    <?php foreach ($departments as $dept): ?>
                                    <div class="department-item">
                                        <div class="flex justify-between text-sm">
                                            <span class="font-medium"><?php echo $dept['name']; ?></span>
                                            <span>$<?php echo number_format($dept['spend']); ?> / $<?php echo number_format($dept['budget']); ?></span>
                                        </div>
                                        <div class="progress-bar">
                                            <div class="progress-fill" style="width: <?php echo ($dept['spend'] / $dept['budget']) * 100; ?>%"></div>
                                        </div>
                                        <div class="flex justify-between text-xs text-gray-500">
                                            <span><?php echo $dept['employees']; ?> employees</span>
                                            <span><?php echo $dept['trips']; ?> trips this month</span>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Recent Activity -->
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Recent Activity</h3>
                            </div>
                            <div class="card-content">
                                <div class="space-y-4">
                                    <div class="activity-item">
                                        <div class="activity-icon bg-blue-500">📅</div>
                                        <div class="activity-content">
                                            <p class="activity-title">New booking request</p>
                                            <p class="activity-description">Mike Chen - San Francisco conference</p>
                                        </div>
                                        <span class="activity-time">2 hrs ago</span>
                                    </div>
                                    
                                    <div class="activity-item">
                                        <div class="activity-icon bg-green-500">💰</div>
                                        <div class="activity-content">
                                            <p class="activity-title">Travel policy savings</p>
                                            <p class="activity-description">$320 saved on London flights</p>
                                        </div>
                                        <span class="activity-time">5 hrs ago</span>
                                    </div>
                                    
                                    <div class="activity-item">
                                        <div class="activity-icon bg-orange-500">🛡️</div>
                                        <div class="activity-content">
                                            <p class="activity-title">Policy compliance alert</p>
                                            <p class="activity-description">Hotel booking exceeded limit</p>
                                        </div>
                                        <span class="activity-time">1 day ago</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Quick Actions</h3>
                        </div>
                        <div class="card-content">
                            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                                <button class="quick-action-btn">
                                    <span class="icon">➕</span>
                                    <span>New Travel Request</span>
                                </button>
                                <button class="quick-action-btn">
                                    <span class="icon">📊</span>
                                    <span>Generate Report</span>
                                </button>
                                <button class="quick-action-btn">
                                    <span class="icon">⚙️</span>
                                    <span>Manage Policies</span>
                                </button>
                                <button class="quick-action-btn">
                                    <span class="icon">💳</span>
                                    <span>Expense Review</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Bookings Tab -->
                <div class="tab-content" id="bookings">
                    <div class="flex justify-between items-center">
                        <h3 class="text-lg font-semibold">Travel Bookings</h3>
                        <div class="flex gap-2">
                            <button class="btn btn-outline">
                                <span class="icon">📄</span>
                                Export
                            </button>
                            <button class="btn btn-primary">
                                <span class="icon">➕</span>
                                New Booking
                            </button>
                        </div>
                    </div>

                    <div class="card">
                        <div class="table-container">
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Employee</th>
                                        <th>Department</th>
                                        <th>Destination</th>
                                        <th>Dates</th>
                                        <th>Purpose</th>
                                        <th>Cost</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recentBookings as $booking): ?>
                                    <tr>
                                        <td class="font-medium"><?php echo $booking['employee']; ?></td>
                                        <td><?php echo $booking['department']; ?></td>
                                        <td><?php echo $booking['destination']; ?></td>
                                        <td><?php echo $booking['dates']; ?></td>
                                        <td><?php echo $booking['purpose']; ?></td>
                                        <td>$<?php echo number_format($booking['cost']); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo getStatusColor($booking['status']); ?>">
                                                <?php echo $booking['status']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <button class="btn btn-sm btn-outline">View</button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Departments Tab -->
                <div class="tab-content" id="departments">
                    <div class="flex justify-between items-center">
                        <h3 class="text-lg font-semibold">Department Overview</h3>
                        <button class="btn btn-outline">
                            <span class="icon">📊</span>
                            Department Report
                        </button>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <?php foreach ($departments as $dept): ?>
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title flex items-center justify-between">
                                    <?php echo $dept['name']; ?>
                                    <span class="badge badge-outline"><?php echo $dept['employees']; ?> employees</span>
                                </h3>
                            </div>
                            <div class="card-content space-y-4">
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <p class="text-sm text-gray-500">This Month</p>
                                        <p class="text-xl font-bold"><?php echo $dept['trips']; ?> trips</p>
                                    </div>
                                    <div>
                                        <p class="text-sm text-gray-500">Total Spend</p>
                                        <p class="text-xl font-bold">$<?php echo number_format($dept['spend']); ?></p>
                                    </div>
                                </div>
                                
                                <div>
                                    <div class="flex justify-between text-sm mb-2">
                                        <span>Budget Usage</span>
                                        <span><?php echo round(($dept['spend'] / $dept['budget']) * 100); ?>%</span>
                                    </div>
                                    <div class="progress-bar">
                                        <div class="progress-fill" style="width: <?php echo ($dept['spend'] / $dept['budget']) * 100; ?>%"></div>
                                    </div>
                                    <p class="text-xs text-gray-500 mt-1">
                                        $<?php echo number_format($dept['budget'] - $dept['spend']); ?> remaining
                                    </p>
                                </div>

                                <button class="btn btn-sm btn-primary w-full">View Details</button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Policies Tab -->
                <div class="tab-content" id="policies">
                    <div class="flex justify-between items-center">
                        <h3 class="text-lg font-semibold">Travel Policies</h3>
                        <button class="btn btn-primary">
                            <span class="icon">➕</span>
                            Add Policy
                        </button>
                    </div>

                    <div class="space-y-4">
                        <?php foreach ($travelPolicies as $index => $policy): ?>
                        <div class="card">
                            <div class="card-content">
                                <div class="flex items-start justify-between mb-4">
                                    <div class="flex-1">
                                        <h4 class="font-semibold mb-2"><?php echo $policy['category']; ?></h4>
                                        <p class="text-gray-600 text-sm"><?php echo $policy['policy']; ?></p>
                                    </div>
                                    <span class="badge badge-<?php echo $policy['status'] === 'active' ? 'default' : 'secondary'; ?>">
                                        <?php echo $policy['status']; ?>
                                    </span>
                                </div>
                                
                                <div class="flex items-center justify-between">
                                    <div class="flex-1">
                                        <div class="flex justify-between text-sm mb-1">
                                            <span>Compliance Rate</span>
                                            <span><?php echo $policy['compliance']; ?>%</span>
                                        </div>
                                        <div class="progress-bar">
                                            <div class="progress-fill" style="width: <?php echo $policy['compliance']; ?>%"></div>
                                        </div>
                                    </div>
                                    <div class="ml-4 flex space-x-2">
                                        <button class="btn btn-sm btn-outline">Edit</button>
                                        <button class="btn btn-sm btn-outline">View Details</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Reports Tab -->
                <div class="tab-content" id="reports">
                    <div class="flex justify-between items-center">
                        <h3 class="text-lg font-semibold">Travel Reports</h3>
                        <button class="btn btn-primary">
                            <span class="icon">📊</span>
                            Generate Custom Report
                        </button>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <h4 class="font-semibold">Monthly Summary</h4>
                                <span class="icon">📄</span>
                            </div>
                            <p class="text-sm text-gray-600 mb-4">
                                Comprehensive monthly travel spending and activity report
                            </p>
                            <button class="btn btn-sm btn-primary w-full">Download Report</button>
                        </div>

                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <h4 class="font-semibold">Department Analysis</h4>
                                <span class="icon">📊</span>
                            </div>
                            <p class="text-sm text-gray-600 mb-4">
                                Detailed breakdown of travel expenses by department
                            </p>
                            <button class="btn btn-sm btn-primary w-full">View Analysis</button>
                        </div>

                        <div class="card">
                            <div class="flex items-center justify-between mb-4">
                                <h4 class="font-semibold">Policy Compliance</h4>
                                <span class="icon">🛡️</span>
                            </div>
                            <p class="text-sm text-gray-600 mb-4">
                                Track adherence to corporate travel policies
                            </p>
                            <button class="btn btn-sm btn-primary w-full">View Compliance</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include '../footer.php'; ?>
    
    <script src="../js/main.js"></script>
    <script src="../js/business.js"></script>
</body>
</html>
