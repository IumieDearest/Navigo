// ===== BUSINESS COMPONENT JAVASCRIPT =====
// Tab functionality and interactive features for Business component

document.addEventListener('DOMContentLoaded', function() {
    initializeBusinessComponent();
});

function initializeBusinessComponent() {
    setupTabs();
    setupPeriodSelector();
    setupQuickActions();
    setupTableInteractions();
    setupProgressBars();
}

// ===== TAB FUNCTIONALITY =====
function setupTabs() {
    const tabTriggers = document.querySelectorAll('.tab-trigger');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabTriggers.forEach(trigger => {
        trigger.addEventListener('click', () => {
            const targetTab = trigger.getAttribute('data-tab');
            
            // Remove active class from all triggers and contents
            tabTriggers.forEach(t => t.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked trigger and corresponding content
            trigger.classList.add('active');
            const targetContent = document.getElementById(targetTab);
            if (targetContent) {
                targetContent.classList.add('active');
            }
            
            // Trigger animations for the new content
            animateTabContent(targetContent);
        });
    });
}

function animateTabContent(content) {
    if (!content) return;
    
    // Add fade-in animation
    content.style.opacity = '0';
    content.style.transform = 'translateY(20px)';
    
    requestAnimationFrame(() => {
        content.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
        content.style.opacity = '1';
        content.style.transform = 'translateY(0)';
    });
}

// ===== PERIOD SELECTOR =====
function setupPeriodSelector() {
    const periodSelector = document.querySelector('.period-selector');
    
    if (periodSelector) {
        periodSelector.addEventListener('change', (e) => {
            const selectedPeriod = e.target.value;
            updateMetricsForPeriod(selectedPeriod);
            showNotification(`Updated view for ${getPeriodDisplayName(selectedPeriod)}`, 'info');
        });
    }
}

function getPeriodDisplayName(period) {
    const periodNames = {
        'current-month': 'Current Month',
        'last-month': 'Last Month',
        'current-quarter': 'Current Quarter',
        'current-year': 'Current Year'
    };
    return periodNames[period] || period;
}

function updateMetricsForPeriod(period) {
    // Simulate data update based on selected period
    const metrics = document.querySelectorAll('.metric-value');
    
    metrics.forEach(metric => {
        // Add loading animation
        metric.style.opacity = '0.5';
        
        setTimeout(() => {
            // Simulate data change
            const currentValue = metric.textContent;
            metric.style.opacity = '1';
            
            // Add a subtle animation to show data has updated
            metric.style.transform = 'scale(1.05)';
            setTimeout(() => {
                metric.style.transform = 'scale(1)';
            }, 200);
        }, 500);
    });
}

// ===== QUICK ACTIONS =====
function setupQuickActions() {
    const quickActionBtns = document.querySelectorAll('.quick-action-btn');
    
    quickActionBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            const actionText = btn.querySelector('span:last-child').textContent;
            handleQuickAction(actionText);
            
            // Add click animation
            btn.style.transform = 'scale(0.95)';
            setTimeout(() => {
                btn.style.transform = 'scale(1)';
            }, 150);
        });
    });
}

function handleQuickAction(action) {
    switch (action) {
        case 'New Travel Request':
            showNotification('Opening new travel request form...', 'info');
            // In a real app, this would open a modal or navigate to a form
            setTimeout(() => {
                showNotification('Travel request form opened', 'success');
            }, 1000);
            break;
            
        case 'Generate Report':
            showNotification('Generating report...', 'info');
            // Simulate report generation
            setTimeout(() => {
                showNotification('Report generated successfully!', 'success');
            }, 2000);
            break;
            
        case 'Manage Policies':
            showNotification('Opening policy management...', 'info');
            // Switch to policies tab
            const policiesTab = document.querySelector('[data-tab="policies"]');
            if (policiesTab) {
                policiesTab.click();
            }
            break;
            
        case 'Expense Review':
            showNotification('Loading expense review...', 'info');
            // In a real app, this would open expense review interface
            setTimeout(() => {
                showNotification('Expense review loaded', 'success');
            }, 1000);
            break;
            
        default:
            showNotification(`Action: ${action}`, 'info');
    }
}

// ===== TABLE INTERACTIONS =====
function setupTableInteractions() {
    const tableRows = document.querySelectorAll('.data-table tbody tr');
    
    tableRows.forEach(row => {
        row.addEventListener('click', (e) => {
            // Don't trigger if clicking on a button
            if (e.target.tagName === 'BUTTON') return;
            
            // Add row selection effect
            tableRows.forEach(r => r.classList.remove('selected'));
            row.classList.add('selected');
            
            // Show booking details (simulated)
            const employeeName = row.cells[0].textContent;
            showNotification(`Viewing details for ${employeeName}`, 'info');
        });
    });
    
    // Add hover effects
    tableRows.forEach(row => {
        row.addEventListener('mouseenter', () => {
            row.style.backgroundColor = 'var(--bg-secondary)';
        });
        
        row.addEventListener('mouseleave', () => {
            if (!row.classList.contains('selected')) {
                row.style.backgroundColor = '';
            }
        });
    });
}

// ===== PROGRESS BARS =====
function setupProgressBars() {
    const progressBars = document.querySelectorAll('.progress-fill');
    
    // Animate progress bars on page load
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateProgressBar(entry.target);
            }
        });
    }, { threshold: 0.5 });
    
    progressBars.forEach(bar => {
        observer.observe(bar);
    });
}

function animateProgressBar(progressBar) {
    const targetWidth = progressBar.style.width;
    progressBar.style.width = '0%';
    
    setTimeout(() => {
        progressBar.style.transition = 'width 1s ease-out';
        progressBar.style.width = targetWidth;
    }, 100);
}

// ===== DEPARTMENT CARDS =====
function setupDepartmentCards() {
    const departmentCards = document.querySelectorAll('.card');
    
    departmentCards.forEach(card => {
        const viewDetailsBtn = card.querySelector('.btn-primary');
        
        if (viewDetailsBtn) {
            viewDetailsBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                const departmentName = card.querySelector('.card-title').textContent.trim();
                showNotification(`Loading details for ${departmentName} department...`, 'info');
            });
        }
    });
}

// ===== POLICY MANAGEMENT =====
function setupPolicyManagement() {
    const policyEditBtns = document.querySelectorAll('.btn-outline');
    
    policyEditBtns.forEach(btn => {
        if (btn.textContent.includes('Edit')) {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const policyCard = btn.closest('.card');
                const policyName = policyCard.querySelector('h4').textContent;
                showNotification(`Editing policy: ${policyName}`, 'info');
            });
        }
    });
}

// ===== NOTIFICATION SYSTEM =====
function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.business-notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `business-notification business-notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-icon">${getNotificationIcon(type)}</span>
            <span class="notification-message">${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">×</button>
        </div>
    `;
    
    // Add styles
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 10000;
        background: ${getNotificationColor(type)};
        color: white;
        padding: 16px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        transform: translateX(100%);
        transition: transform 0.3s ease;
        max-width: 400px;
        font-size: 14px;
    `;
    
    // Add to DOM
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (notification.parentElement) {
                    notification.remove();
                }
            }, 300);
        }
    }, 3000);
}

function getNotificationIcon(type) {
    const icons = {
        success: '✓',
        error: '✕',
        warning: '⚠',
        info: 'ℹ'
    };
    return icons[type] || icons.info;
}

function getNotificationColor(type) {
    const colors = {
        success: '#10b981',
        error: '#ef4444',
        warning: '#f59e0b',
        info: '#3b82f6'
    };
    return colors[type] || colors.info;
}

// ===== KEYBOARD NAVIGATION =====
function setupKeyboardNavigation() {
    document.addEventListener('keydown', (e) => {
        // Tab navigation for tabs
        if (e.key === 'Tab' && e.target.classList.contains('tab-trigger')) {
            const tabTriggers = Array.from(document.querySelectorAll('.tab-trigger'));
            const currentIndex = tabTriggers.indexOf(e.target);
            
            if (e.shiftKey) {
                // Shift + Tab - go to previous tab
                if (currentIndex > 0) {
                    e.preventDefault();
                    tabTriggers[currentIndex - 1].focus();
                }
            } else {
                // Tab - go to next tab
                if (currentIndex < tabTriggers.length - 1) {
                    e.preventDefault();
                    tabTriggers[currentIndex + 1].focus();
                }
            }
        }
        
        // Enter key to activate tabs
        if (e.key === 'Enter' && e.target.classList.contains('tab-trigger')) {
            e.target.click();
        }
    });
}

// ===== RESPONSIVE ADJUSTMENTS =====
function setupResponsiveFeatures() {
    const handleResize = () => {
        const isMobile = window.innerWidth < 768;
        const tables = document.querySelectorAll('.data-table');
        
        tables.forEach(table => {
            if (isMobile) {
                table.classList.add('mobile-table');
            } else {
                table.classList.remove('mobile-table');
            }
        });
    };
    
    window.addEventListener('resize', handleResize);
    handleResize(); // Initial call
}

// ===== INITIALIZE ALL FEATURES =====
function initializeBusinessComponent() {
    setupTabs();
    setupPeriodSelector();
    setupQuickActions();
    setupTableInteractions();
    setupProgressBars();
    setupDepartmentCards();
    setupPolicyManagement();
    setupKeyboardNavigation();
    setupResponsiveFeatures();
    
    // Show welcome message
    setTimeout(() => {
        showNotification('Business dashboard loaded successfully', 'success');
    }, 500);
}

// ===== EXPORT FOR TESTING =====
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        initializeBusinessComponent,
        showNotification,
        handleQuickAction
    };
}
