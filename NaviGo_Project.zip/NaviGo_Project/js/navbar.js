// ===== NAVBAR JAVASCRIPT =====
// Mobile navigation and navbar interactions

// ===== NAVBAR FUNCTIONALITY =====
class NavbarManager {
    constructor() {
        this.navbar = document.getElementById('navbar');
        this.mobileMenuToggle = document.getElementById('mobile-menu-toggle');
        this.navMenu = document.getElementById('nav-menu');
        this.navLinks = document.querySelectorAll('.nav-link');
        this.isMenuOpen = false;
        this.lastScrollY = window.scrollY;
        this.isScrolling = false;
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.setupScrollEffects();
        this.setupMobileMenu();
        this.setupKeyboardNavigation();
    }
    
    setupEventListeners() {
        // Mobile menu toggle
        if (this.mobileMenuToggle) {
            this.mobileMenuToggle.addEventListener('click', () => this.toggleMobileMenu());
        }
        
        // Navigation links
        this.navLinks.forEach(link => {
            link.addEventListener('click', (e) => this.handleNavClick(e));
        });
        
        // Close menu when clicking outside
        document.addEventListener('click', (e) => this.handleOutsideClick(e));
        
        // Window resize
        window.addEventListener('resize', () => this.handleResize());
        
        // Scroll events
        window.addEventListener('scroll', () => this.handleScroll());
    }
    
    setupScrollEffects() {
        // Navbar scroll effect with throttling
        this.throttledScrollHandler = this.throttle(() => {
            const currentScrollY = window.scrollY;
            
            // Add/remove scrolled class
            if (currentScrollY > 100) {
                this.navbar.classList.add('scrolled');
            } else {
                this.navbar.classList.remove('scrolled');
            }
            
            // Hide/show navbar on scroll direction
            if (currentScrollY > this.lastScrollY && currentScrollY > 200) {
                this.navbar.style.transform = 'translateY(-100%)';
            } else {
                this.navbar.style.transform = 'translateY(0)';
            }
            
            this.lastScrollY = currentScrollY;
        }, 10);
    }
    
    setupMobileMenu() {
        // Create mobile menu overlay
        this.createMobileMenuOverlay();
        
        // Setup mobile menu styles
        this.setupMobileMenuStyles();
    }
    
    createMobileMenuOverlay() {
        // Check if overlay already exists
        if (document.querySelector('.mobile-menu-overlay')) {
            return;
        }
        
        const overlay = document.createElement('div');
        overlay.className = 'mobile-menu-overlay';
        overlay.addEventListener('click', () => this.closeMobileMenu());
        document.body.appendChild(overlay);
        
        this.overlay = overlay;
    }
    
    setupMobileMenuStyles() {
        // Add mobile menu styles if not already present
        if (document.querySelector('#mobile-menu-styles')) {
            return;
        }
        
        const style = document.createElement('style');
        style.id = 'mobile-menu-styles';
        style.textContent = `
            .mobile-menu-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                opacity: 0;
                visibility: hidden;
                transition: all 0.3s ease;
                z-index: 999;
            }
            
            .mobile-menu-overlay.active {
                opacity: 1;
                visibility: visible;
            }
            
            .nav-menu {
                position: fixed;
                top: 0;
                right: -100%;
                width: 100%;
                max-width: 320px;
                height: 100vh;
                background: var(--bg-card);
                backdrop-filter: blur(20px);
                border-left: 1px solid var(--border-primary);
                padding: 80px 24px 24px;
                transition: right 0.3s ease;
                z-index: 1000;
                overflow-y: auto;
                display: flex;
                flex-direction: column;
                gap: 16px;
            }
            
            .nav-menu.active {
                right: 0;
            }
            
            .nav-menu .nav-link {
                display: flex;
                align-items: center;
                gap: 12px;
                padding: 12px 16px;
                color: var(--text-secondary);
                text-decoration: none;
                border-radius: 12px;
                transition: all 0.2s ease;
                font-weight: 500;
                font-size: 16px;
            }
            
            .nav-menu .nav-link:hover,
            .nav-menu .nav-link.active {
                color: var(--primary-sky);
                background: rgba(14, 165, 233, 0.1);
            }
            
            .mobile-menu-toggle {
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                width: 40px;
                height: 40px;
                border: none;
                background: transparent;
                cursor: pointer;
                padding: 0;
                gap: 4px;
            }
            
            .hamburger-line {
                width: 24px;
                height: 2px;
                background: var(--text-primary);
                border-radius: 9999px;
                transition: all 0.3s ease;
                transform-origin: center;
            }
            
            .mobile-menu-toggle.active .hamburger-line:nth-child(1) {
                transform: rotate(45deg) translate(6px, 6px);
            }
            
            .mobile-menu-toggle.active .hamburger-line:nth-child(2) {
                opacity: 0;
            }
            
            .mobile-menu-toggle.active .hamburger-line:nth-child(3) {
                transform: rotate(-45deg) translate(6px, -6px);
            }
            
            @media (min-width: 1024px) {
                .mobile-menu-toggle {
                    display: none;
                }
                
                .nav-menu {
                    position: static;
                    width: auto;
                    height: auto;
                    background: transparent;
                    backdrop-filter: none;
                    border: none;
                    padding: 0;
                    display: flex;
                    flex-direction: row;
                    align-items: center;
                    gap: 24px;
                    overflow: visible;
                }
                
                .nav-menu .nav-link {
                    padding: 8px 16px;
                    font-size: 14px;
                }
            }
        `;
        
        document.head.appendChild(style);
    }
    
    toggleMobileMenu() {
        this.isMenuOpen = !this.isMenuOpen;
        
        // Update toggle button
        this.mobileMenuToggle.classList.toggle('active', this.isMenuOpen);
        
        // Update menu
        this.navMenu.classList.toggle('active', this.isMenuOpen);
        
        // Update overlay
        if (this.overlay) {
            this.overlay.classList.toggle('active', this.isMenuOpen);
        }
        
        // Prevent body scroll
        document.body.style.overflow = this.isMenuOpen ? 'hidden' : '';
        
        // Update aria attributes
        this.mobileMenuToggle.setAttribute('aria-expanded', this.isMenuOpen);
        this.navMenu.setAttribute('aria-hidden', !this.isMenuOpen);
    }
    
    closeMobileMenu() {
        if (this.isMenuOpen) {
            this.toggleMobileMenu();
        }
    }
    
    handleNavClick(event) {
        event.preventDefault();
        
        const href = event.currentTarget.getAttribute('href');
        if (href && href.startsWith('#')) {
            const targetId = href.substring(1);
            this.scrollToSection(targetId);
            
            // Close mobile menu
            this.closeMobileMenu();
            
            // Update active nav link
            this.updateActiveNavLink(event.currentTarget);
        }
    }
    
    updateActiveNavLink(activeLink) {
        this.navLinks.forEach(link => {
            link.classList.remove('active');
        });
        activeLink.classList.add('active');
    }
    
    scrollToSection(sectionId) {
        const section = document.getElementById(sectionId);
        if (section) {
            const offsetTop = section.offsetTop - 80; // Account for fixed navbar
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    }
    
    handleOutsideClick(event) {
        if (this.isMenuOpen && 
            !this.navMenu.contains(event.target) && 
            !this.mobileMenuToggle.contains(event.target)) {
            this.closeMobileMenu();
        }
    }
    
    handleResize() {
        // Close mobile menu on desktop
        if (window.innerWidth > 1023 && this.isMenuOpen) {
            this.closeMobileMenu();
        }
    }
    
    handleScroll() {
        this.throttledScrollHandler();
        this.updateActiveNavOnScroll();
    }
    
    updateActiveNavOnScroll() {
        const sections = document.querySelectorAll('section[id]');
        const scrollPos = window.scrollY + 100;
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');
            
            if (scrollPos >= sectionTop && scrollPos < sectionTop + sectionHeight) {
                this.navLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === `#${sectionId}`) {
                        link.classList.add('active');
                    }
                });
            }
        });
    }
    
    setupKeyboardNavigation() {
        document.addEventListener('keydown', (e) => {
            // Close menu with Escape key
            if (e.key === 'Escape' && this.isMenuOpen) {
                this.closeMobileMenu();
            }
            
            // Focus management for mobile menu
            if (this.isMenuOpen && e.key === 'Tab') {
                this.handleTabNavigation(e);
            }
        });
    }
    
    handleTabNavigation(event) {
        const focusableElements = this.navMenu.querySelectorAll(
            'a[href], button:not([disabled]), input:not([disabled]), textarea:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])'
        );
        
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];
        
        if (event.shiftKey) {
            if (document.activeElement === firstElement) {
                event.preventDefault();
                lastElement.focus();
            }
        } else {
            if (document.activeElement === lastElement) {
                event.preventDefault();
                firstElement.focus();
            }
        }
    }
    
    // Utility function for throttling
    throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }
    
    // Public methods for external use
    openMobileMenu() {
        if (!this.isMenuOpen) {
            this.toggleMobileMenu();
        }
    }
    
    closeMobileMenu() {
        if (this.isMenuOpen) {
            this.toggleMobileMenu();
        }
    }
    
    isMobileMenuOpen() {
        return this.isMenuOpen;
    }
}

// ===== INITIALIZE NAVBAR =====
let navbarManager;

document.addEventListener('DOMContentLoaded', function() {
    navbarManager = new NavbarManager();
});

// ===== EXPORT FOR TESTING =====
if (typeof module !== 'undefined' && module.exports) {
    module.exports = NavbarManager;
}
