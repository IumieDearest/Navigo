<?php
session_start();
require_once 'config/database.php';
require_once 'includes/auth.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: /dashboard.php');
    exit;
}

$page_title = 'Login - NaviGo';
$errors = [];
$success_message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember_me = isset($_POST['remember_me']);
    
    // Validate input
    if (empty($email)) {
        $errors[] = 'Email is required';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address';
    }
    
    if (empty($password)) {
        $errors[] = 'Password is required';
    }
    
    // Check rate limiting
    if (!checkLoginRateLimit($email)) {
        $errors[] = 'Too many login attempts. Please try again in 15 minutes.';
    }
    
    // If no validation errors, attempt login
    if (empty($errors)) {
        try {
            $stmt = $pdo->prepare("
                SELECT * FROM users 
                WHERE email = ? AND is_active = 1 AND email_verified = 1
            ");
            $stmt->execute([$email]);
            $user = $stmt->fetch();
            
            if ($user && verifyPassword($password, $user['password'])) {
                // Successful login
                logLoginAttempt($email, true);
                loginUser($user);
                
                // Handle remember me
                if ($remember_me) {
                    $token = generateSecureToken();
                    $expires = date('Y-m-d H:i:s', time() + (30 * 24 * 60 * 60)); // 30 days
                    
                    // Store remember token in database
                    $stmt = $pdo->prepare("
                        INSERT INTO remember_tokens (user_id, token, expires_at, created_at) 
                        VALUES (?, ?, ?, NOW())
                    ");
                    $stmt->execute([$user['id'], hash('sha256', $token), $expires]);
                    
                    // Set cookie
                    setcookie('remember_token', $token, time() + (30 * 24 * 60 * 60), '/', '', true, true);
                }
                
                // Redirect to intended page or dashboard
                $redirect = $_GET['redirect'] ?? '/dashboard.php';
                header('Location: ' . $redirect);
                exit;
            } else {
                // Failed login
                logLoginAttempt($email, false);
                $errors[] = 'Invalid email or password';
            }
        } catch (PDOException $e) {
            error_log("Login error: " . $e->getMessage());
            $errors[] = 'An error occurred during login. Please try again.';
        }
    }
}

// Handle password reset request
if (isset($_GET['reset']) && $_GET['reset'] === 'success') {
    $success_message = 'Password reset instructions have been sent to your email.';
}
?>

<!DOCTYPE html>
<html lang="en" class="<?php echo isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark' ? 'dark' : ''; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="/assets/css/globals.css">
</head>
<body class="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">

<div class="navigo-login-container min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
    <div class="navigo-login-wrapper w-full max-w-6xl grid lg:grid-cols-2 gap-8 items-center">
        
        <!-- Left Side - Branding and Features -->
        <div class="navigo-branding-section space-y-8 text-center lg:text-left">
            <div class="navigo-logo-container flex justify-center lg:justify-start">
                <div class="navigo-logo-wrapper flex items-center space-x-2">
                    <div class="navigo-logo w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                        <svg class="w-6 h-6 text-white" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                        </svg>
                    </div>
                    <span class="navigo-logo-text text-2xl font-bold text-gray-900">NaviGo</span>
                </div>
            </div>
            
            <div class="navigo-welcome-content space-y-4">
                <h1 class="navigo-welcome-title text-4xl lg:text-5xl font-bold text-gray-900">
                    Welcome Back
                </h1>
                <p class="navigo-welcome-subtitle text-xl text-gray-600 max-w-lg">
                    Sign in to access your personalized travel dashboard and continue planning amazing trips.
                </p>
            </div>

            <div class="navigo-features-grid grid sm:grid-cols-2 gap-6 max-w-lg mx-auto lg:mx-0">
                <div class="navigo-feature-item flex items-start space-x-3">
                    <div class="navigo-feature-icon flex-shrink-0 w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                        <svg class="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/>
                        </svg>
                    </div>
                    <div class="navigo-feature-content text-left">
                        <h3 class="navigo-feature-title font-medium text-gray-900">AI-Powered Planning</h3>
                        <p class="navigo-feature-description text-sm text-gray-600">Smart recommendations</p>
                    </div>
                </div>

                <div class="navigo-feature-item flex items-start space-x-3">
                    <div class="navigo-feature-icon flex-shrink-0 w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                        <svg class="w-4 h-4 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                        </svg>
                    </div>
                    <div class="navigo-feature-content text-left">
                        <h3 class="navigo-feature-title font-medium text-gray-900">Secure & Synced</h3>
                        <p class="navigo-feature-description text-sm text-gray-600">All devices connected</p>
                    </div>
                </div>

                <div class="navigo-feature-item flex items-start space-x-3">
                    <div class="navigo-feature-icon flex-shrink-0 w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                        <svg class="w-4 h-4 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"/>
                        </svg>
                    </div>
                    <div class="navigo-feature-content text-left">
                        <h3 class="navigo-feature-title font-medium text-gray-900">Team Collaboration</h3>
                        <p class="navigo-feature-description text-sm text-gray-600">Group planning tools</p>
                    </div>
                </div>

                <div class="navigo-feature-item flex items-start space-x-3">
                    <div class="navigo-feature-icon flex-shrink-0 w-8 h-8 bg-orange-100 rounded-lg flex items-center justify-center">
                        <svg class="w-4 h-4 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"/>
                        </svg>
                    </div>
                    <div class="navigo-feature-content text-left">
                        <h3 class="navigo-feature-title font-medium text-gray-900">Cost Optimization</h3>
                        <p class="navigo-feature-description text-sm text-gray-600">Maximum savings</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Right Side - Login Form -->
        <div class="navigo-form-section flex justify-center">
            <div class="navigo-login-card w-full max-w-md bg-white rounded-lg shadow-lg border border-gray-200 p-8">
                <div class="navigo-form-header text-center mb-8">
                    <h2 class="navigo-form-title text-2xl font-bold text-gray-900 mb-2">Sign In</h2>
                    <p class="navigo-form-subtitle text-gray-600">
                        Access your NaviGo account
                    </p>
                </div>

                <?php if (!empty($errors)): ?>
                    <div class="navigo-error-messages mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                        <div class="flex">
                            <svg class="w-5 h-5 text-red-400 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                            <div>
                                <?php foreach ($errors as $error): ?>
                                    <p class="text-sm text-red-700"><?php echo htmlspecialchars($error); ?></p>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ($success_message): ?>
                    <div class="navigo-success-message mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                        <div class="flex">
                            <svg class="w-5 h-5 text-green-400 mr-2 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                            <p class="text-sm text-green-700"><?php echo htmlspecialchars($success_message); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

                <form class="navigo-login-form space-y-6" method="POST">
                    <div class="navigo-form-group">
                        <label for="email" class="navigo-form-label block text-sm font-medium text-gray-700 mb-2">
                            Email Address
                        </label>
                        <input type="email" 
                               id="email" 
                               name="email" 
                               class="navigo-input w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                               placeholder="Enter your email"
                               value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                               required>
                    </div>

                    <div class="navigo-form-group">
                        <label for="password" class="navigo-form-label block text-sm font-medium text-gray-700 mb-2">
                            Password
                        </label>
                        <div class="relative">
                            <input type="password" 
                                   id="password" 
                                   name="password" 
                                   class="navigo-input w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                                   placeholder="Enter your password"
                                   required>
                            <button type="button" 
                                    class="navigo-password-toggle absolute inset-y-0 right-0 pr-3 flex items-center"
                                    onclick="togglePassword()">
                                <svg class="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                                </svg>
                            </button>
                        </div>
                    </div>

                    <div class="navigo-form-options flex items-center justify-between">
                        <div class="navigo-remember-me flex items-center">
                            <input type="checkbox" 
                                   id="remember_me" 
                                   name="remember_me" 
                                   class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                                   <?php echo isset($_POST['remember_me']) ? 'checked' : ''; ?>>
                            <label for="remember_me" class="ml-2 block text-sm text-gray-700">
                                Remember me
                            </label>
                        </div>
                        <a href="/forgot-password.php" class="navigo-forgot-link text-sm text-blue-600 hover:text-blue-700">
                            Forgot password?
                        </a>
                    </div>

                    <button type="submit" 
                            class="navigo-submit-btn w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors font-medium">
                        Sign In
                    </button>
                </form>

                <div class="navigo-divider mt-6">
                    <div class="relative">
                        <div class="absolute inset-0 flex items-center">
                            <div class="w-full border-t border-gray-300"></div>
                        </div>
                        <div class="relative flex justify-center text-sm">
                            <span class="px-2 bg-white text-gray-500">Or continue with</span>
                        </div>
                    </div>
                </div>

                <div class="navigo-social-login mt-6 grid grid-cols-2 gap-3">
                    <button type="button" class="navigo-social-btn flex justify-center items-center px-4 py-2 border border-gray-300 rounded-lg bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <svg class="w-4 h-4 mr-2" viewBox="0 0 24 24">
                            <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                            <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                            <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                            <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                        </svg>
                        Google
                    </button>
                    <button type="button" class="navigo-social-btn flex justify-center items-center px-4 py-2 border border-gray-300 rounded-lg bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.024-.105-.949-.199-2.403.041-3.439.219-.937 1.219-5.160 1.219-5.160s-.312-.219-.312-.937c0-.877.508-1.531 1.141-1.531.539 0 .799.406.799.891 0 .542-.219 1.219-.508 1.875-.406 1.312-.52 2.141-.52 2.141s1.094 1.094 2.688 1.094c3.229 0 5.688-3.365 5.688-7.948 0-3.312-2.312-5.792-6.052-5.792-4.309 0-6.859 3.186-6.859 6.739 0 1.218.406 2.076 1.072 2.776.208.25.235.406.156.656-.082.219-.269.969-.344 1.187-.094.282-.375.375-.656.219C4.594 16.311 3.812 14.23 3.812 11.987c0-4.522 4.037-8.965 11.286-8.965 5.901 0 9.791 4.229 9.791 8.751 0 5.969-3.312 10.531-8.125 10.531-1.619 0-3.125-.875-3.656-1.969 0 0-.813 3.156-.969 3.844-.281 1.125-1.016 2.531-1.594 3.5.031 0 1.187.281 1.844.281 6.624 0 11.99-5.367 11.99-11.987C24.007 5.367 18.641.001 12.017.001z"/>
                        </svg>
                        Microsoft
                    </button>
                </div>

                <div class="navigo-signup-link text-center mt-6">
                    <p class="text-sm text-gray-600">
                        Don't have an account? 
                        <a href="/register.php" class="text-blue-600 hover:text-blue-700 font-medium">
                            Sign up for free
                        </a>
                    </p>
                </div>

                <div class="navigo-legal-links text-center mt-4">
                    <p class="text-xs text-gray-500">
                        By signing in, you agree to our 
                        <a href="/terms.php" class="text-blue-600 hover:text-blue-700">Terms of Service</a> 
                        and 
                        <a href="/privacy.php" class="text-blue-600 hover:text-blue-700">Privacy Policy</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function togglePassword() {
    const passwordField = document.getElementById('password');
    const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
    passwordField.setAttribute('type', type);
}

// Auto-focus on first empty field
document.addEventListener('DOMContentLoaded', function() {
    const emailField = document.getElementById('email');
    const passwordField = document.getElementById('password');
    
    if (!emailField.value) {
        emailField.focus();
    } else if (!passwordField.value) {
        passwordField.focus();
    }
});
</script>

</body>
</html>