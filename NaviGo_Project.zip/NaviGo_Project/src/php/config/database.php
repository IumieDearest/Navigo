<?php
/**
 * Database Configuration
 * NaviGo Travel Management Platform
 */

// Database configuration
define('DB_HOST', $_ENV['DB_HOST'] ?? 'localhost');
define('DB_NAME', $_ENV['DB_NAME'] ?? 'navigo_db');
define('DB_USER', $_ENV['DB_USER'] ?? 'navigo_user');
define('DB_PASS', $_ENV['DB_PASS'] ?? 'your_secure_password');
define('DB_CHARSET', 'utf8mb4');

// PDO Options
$pdo_options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET
];

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET,
        DB_USER,
        DB_PASS,
        $pdo_options
    );
} catch (PDOException $e) {
    error_log("Database connection failed: " . $e->getMessage());
    die("Database connection failed. Please check your configuration.");
}

/**
 * Get current user data
 */
function getCurrentUser() {
    global $pdo;
    
    if (!isset($_SESSION['user_id'])) {
        return null;
    }
    
    try {
        $stmt = $pdo->prepare("
            SELECT u.*, p.avatar, p.timezone, p.currency_preference 
            FROM users u 
            LEFT JOIN user_profiles p ON u.id = p.user_id 
            WHERE u.id = ? AND u.is_active = 1
        ");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetch();
    } catch (PDOException $e) {
        error_log("Error fetching user data: " . $e->getMessage());
        return null;
    }
}

/**
 * Get user's recent trips
 */
function getUserRecentTrips($user_id, $limit = 5) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            SELECT 
                t.*,
                d.name as destination,
                d.image_url as destination_image,
                d.country
            FROM trips t
            LEFT JOIN destinations d ON t.destination_id = d.id
            WHERE t.user_id = ? AND t.is_active = 1
            ORDER BY t.created_at DESC
            LIMIT ?
        ");
        $stmt->execute([$user_id, $limit]);
        return $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log("Error fetching recent trips: " . $e->getMessage());
        return [];
    }
}

/**
 * Get user trip statistics
 */
function getUserTripStats($user_id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            SELECT 
                COUNT(*) as total_trips,
                COALESCE(SUM(money_saved), 0) as money_saved,
                COUNT(DISTINCT d.country) as countries_visited,
                COALESCE(SUM(planning_hours), 0) as hours_planned
            FROM trips t
            LEFT JOIN destinations d ON t.destination_id = d.id
            WHERE t.user_id = ? AND t.is_active = 1
        ");
        $stmt->execute([$user_id]);
        return $stmt->fetch();
    } catch (PDOException $e) {
        error_log("Error fetching trip stats: " . $e->getMessage());
        return [
            'total_trips' => 0,
            'money_saved' => 0,
            'countries_visited' => 0,
            'hours_planned' => 0
        ];
    }
}

/**
 * Execute a prepared statement with error handling
 */
function executeQuery($query, $params = []) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        return $stmt;
    } catch (PDOException $e) {
        error_log("Database query error: " . $e->getMessage());
        throw $e;
    }
}

/**
 * Get a single record
 */
function fetchOne($query, $params = []) {
    $stmt = executeQuery($query, $params);
    return $stmt->fetch();
}

/**
 * Get multiple records
 */
function fetchAll($query, $params = []) {
    $stmt = executeQuery($query, $params);
    return $stmt->fetchAll();
}

/**
 * Insert a record and return the last insert ID
 */
function insertRecord($table, $data) {
    global $pdo;
    
    $columns = implode(',', array_keys($data));
    $placeholders = ':' . implode(', :', array_keys($data));
    
    $query = "INSERT INTO {$table} ({$columns}) VALUES ({$placeholders})";
    
    try {
        $stmt = $pdo->prepare($query);
        $stmt->execute($data);
        return $pdo->lastInsertId();
    } catch (PDOException $e) {
        error_log("Insert error: " . $e->getMessage());
        throw $e;
    }
}

/**
 * Update a record
 */
function updateRecord($table, $data, $where, $whereParams = []) {
    global $pdo;
    
    $setClause = [];
    foreach ($data as $key => $value) {
        $setClause[] = "{$key} = :{$key}";
    }
    $setClause = implode(', ', $setClause);
    
    $query = "UPDATE {$table} SET {$setClause} WHERE {$where}";
    $params = array_merge($data, $whereParams);
    
    try {
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        return $stmt->rowCount();
    } catch (PDOException $e) {
        error_log("Update error: " . $e->getMessage());
        throw $e;
    }
}

/**
 * Delete a record (soft delete by default)
 */
function deleteRecord($table, $where, $whereParams = [], $soft = true) {
    global $pdo;
    
    if ($soft) {
        $query = "UPDATE {$table} SET is_active = 0, deleted_at = NOW() WHERE {$where}";
    } else {
        $query = "DELETE FROM {$table} WHERE {$where}";
    }
    
    try {
        $stmt = $pdo->prepare($query);
        $stmt->execute($whereParams);
        return $stmt->rowCount();
    } catch (PDOException $e) {
        error_log("Delete error: " . $e->getMessage());
        throw $e;
    }
}
?>