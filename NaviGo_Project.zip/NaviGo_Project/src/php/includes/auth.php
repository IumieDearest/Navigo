<?php
/**
 * Authentication Helper Functions
 * NaviGo Travel Management Platform
 */

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Require authentication for protected pages
 */
function requireAuth() {
    if (!isLoggedIn()) {
        header('Location: /login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
        exit;
    }
}

/**
 * Check if user has specific role
 */
function hasRole($role) {
    if (!isLoggedIn()) {
        return false;
    }
    
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === $role;
}

/**
 * Check if user has any of the specified roles
 */
function hasAnyRole($roles) {
    if (!isLoggedIn()) {
        return false;
    }
    
    return isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], $roles);
}

/**
 * Login user and create session
 */
function loginUser($user) {
    // Regenerate session ID for security
    session_regenerate_id(true);
    
    // Set session variables
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_role'] = $user['role'];
    $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];
    $_SESSION['login_time'] = time();
    $_SESSION['last_activity'] = time();
    
    // Log the login
    logUserActivity($user['id'], 'login', 'User logged in successfully');
    
    return true;
}

/**
 * Logout user and destroy session
 */
function logoutUser() {
    if (isLoggedIn()) {
        // Log the logout
        logUserActivity($_SESSION['user_id'], 'logout', 'User logged out');
        
        // Clear all session variables
        $_SESSION = array();
        
        // Destroy the session cookie
        if (ini_get("session.use_cookies")) {
            $params = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $params["path"], $params["domain"],
                $params["secure"], $params["httponly"]
            );
        }
        
        // Destroy the session
        session_destroy();
    }
}

/**
 * Check session timeout
 */
function checkSessionTimeout($timeout = 3600) { // 1 hour default
    if (isLoggedIn()) {
        if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timeout)) {
            logoutUser();
            return false;
        }
        $_SESSION['last_activity'] = time();
    }
    return true;
}

/**
 * Validate password strength
 */
function validatePassword($password) {
    $errors = [];
    
    if (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters long";
    }
    
    if (!preg_match('/[A-Z]/', $password)) {
        $errors[] = "Password must contain at least one uppercase letter";
    }
    
    if (!preg_match('/[a-z]/', $password)) {
        $errors[] = "Password must contain at least one lowercase letter";
    }
    
    if (!preg_match('/[0-9]/', $password)) {
        $errors[] = "Password must contain at least one number";
    }
    
    if (!preg_match('/[^A-Za-z0-9]/', $password)) {
        $errors[] = "Password must contain at least one special character";
    }
    
    return empty($errors) ? true : $errors;
}

/**
 * Hash password securely
 */
function hashPassword($password) {
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Verify password against hash
 */
function verifyPassword($password, $hash) {
    return password_verify($password, $hash);
}

/**
 * Generate secure random token
 */
function generateSecureToken($length = 32) {
    return bin2hex(random_bytes($length));
}

/**
 * Generate password reset token
 */
function generatePasswordResetToken($user_id) {
    global $pdo;
    
    $token = generateSecureToken();
    $expires_at = date('Y-m-d H:i:s', time() + 3600); // 1 hour
    
    try {
        // Invalidate any existing tokens
        $stmt = $pdo->prepare("UPDATE password_resets SET is_used = 1 WHERE user_id = ? AND is_used = 0");
        $stmt->execute([$user_id]);
        
        // Insert new token
        $stmt = $pdo->prepare("
            INSERT INTO password_resets (user_id, token, expires_at, created_at) 
            VALUES (?, ?, ?, NOW())
        ");
        $stmt->execute([$user_id, $token, $expires_at]);
        
        return $token;
    } catch (PDOException $e) {
        error_log("Error generating password reset token: " . $e->getMessage());
        return false;
    }
}

/**
 * Validate password reset token
 */
function validatePasswordResetToken($token) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            SELECT pr.*, u.email 
            FROM password_resets pr 
            JOIN users u ON pr.user_id = u.id 
            WHERE pr.token = ? AND pr.is_used = 0 AND pr.expires_at > NOW()
        ");
        $stmt->execute([$token]);
        return $stmt->fetch();
    } catch (PDOException $e) {
        error_log("Error validating password reset token: " . $e->getMessage());
        return false;
    }
}

/**
 * Use password reset token
 */
function usePasswordResetToken($token) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("UPDATE password_resets SET is_used = 1, used_at = NOW() WHERE token = ?");
        return $stmt->execute([$token]);
    } catch (PDOException $e) {
        error_log("Error using password reset token: " . $e->getMessage());
        return false;
    }
}

/**
 * Log user activity
 */
function logUserActivity($user_id, $action, $description = '', $ip_address = null) {
    global $pdo;
    
    if ($ip_address === null) {
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    }
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO user_activity_logs (user_id, action, description, ip_address, user_agent, created_at) 
            VALUES (?, ?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $user_id,
            $action,
            $description,
            $ip_address,
            $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
        ]);
    } catch (PDOException $e) {
        error_log("Error logging user activity: " . $e->getMessage());
    }
}

/**
 * Rate limiting for login attempts
 */
function checkLoginRateLimit($email, $max_attempts = 5, $window = 900) { // 15 minutes
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as attempts 
            FROM login_attempts 
            WHERE email = ? AND created_at > DATE_SUB(NOW(), INTERVAL ? SECOND)
        ");
        $stmt->execute([$email, $window]);
        $result = $stmt->fetch();
        
        return $result['attempts'] < $max_attempts;
    } catch (PDOException $e) {
        error_log("Error checking login rate limit: " . $e->getMessage());
        return true; // Allow if we can't check
    }
}

/**
 * Log login attempt
 */
function logLoginAttempt($email, $success = false, $ip_address = null) {
    global $pdo;
    
    if ($ip_address === null) {
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    }
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO login_attempts (email, success, ip_address, user_agent, created_at) 
            VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt->execute([
            $email,
            $success ? 1 : 0,
            $ip_address,
            $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
        ]);
    } catch (PDOException $e) {
        error_log("Error logging login attempt: " . $e->getMessage());
    }
}

/**
 * Clean up old login attempts and password reset tokens
 */
function cleanupAuthData() {
    global $pdo;
    
    try {
        // Clean up old login attempts (older than 24 hours)
        $pdo->exec("DELETE FROM login_attempts WHERE created_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)");
        
        // Clean up old password reset tokens (older than 24 hours)
        $pdo->exec("DELETE FROM password_resets WHERE created_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)");
    } catch (PDOException $e) {
        error_log("Error cleaning up auth data: " . $e->getMessage());
    }
}

/**
 * Get user permissions
 */
function getUserPermissions($user_id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            SELECT p.name, p.description 
            FROM permissions p
            JOIN role_permissions rp ON p.id = rp.permission_id
            JOIN user_roles ur ON rp.role_id = ur.role_id
            WHERE ur.user_id = ? AND ur.is_active = 1
        ");
        $stmt->execute([$user_id]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (PDOException $e) {
        error_log("Error fetching user permissions: " . $e->getMessage());
        return [];
    }
}

/**
 * Check if user has specific permission
 */
function hasPermission($permission) {
    if (!isLoggedIn()) {
        return false;
    }
    
    if (!isset($_SESSION['user_permissions'])) {
        $_SESSION['user_permissions'] = getUserPermissions($_SESSION['user_id']);
    }
    
    return in_array($permission, $_SESSION['user_permissions']);
}
?>