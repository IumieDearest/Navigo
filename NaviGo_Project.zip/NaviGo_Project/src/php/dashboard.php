<?php
session_start();
require_once 'config/database.php';
require_once 'includes/auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    header('Location: /login.php');
    exit;
}

$user_data = getCurrentUser();
$page_title = 'Dashboard - NaviGo';

// Get user's recent trips
$recent_trips = getUserRecentTrips($user_data['id'], 5);
$trip_stats = getUserTripStats($user_data['id']);
?>

<?php include 'includes/header.php'; ?>

<main class="navigo-main-content">
    <div class="navigo-dashboard-container max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        <!-- Welcome Section -->
        <div class="navigo-welcome-section mb-8">
            <div class="navigo-welcome-content bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6">
                <h1 class="navigo-welcome-title text-2xl font-bold text-gray-900 mb-2">
                    Welcome back, <?php echo htmlspecialchars($user_data['first_name']); ?>!
                </h1>
                <p class="navigo-welcome-subtitle text-gray-600">
                    Ready to plan your next adventure? Let's get started.
                </p>
                <div class="navigo-welcome-actions mt-4">
                    <a href="/trip-creator.php" class="navigo-btn navigo-btn-primary inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                        </svg>
                        Create New Trip
                    </a>
                    <a href="/explore.php" class="navigo-btn navigo-btn-secondary ml-3 inline-flex items-center px-4 py-2 bg-white text-gray-700 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                        Explore Destinations
                    </a>
                </div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="navigo-stats-section mb-8">
            <div class="navigo-stats-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                
                <div class="navigo-stat-card bg-white rounded-lg border border-gray-200 p-6">
                    <div class="navigo-stat-content flex items-center">
                        <div class="navigo-stat-icon flex-shrink-0 w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                            <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064"/>
                            </svg>
                        </div>
                        <div class="navigo-stat-info ml-4">
                            <p class="navigo-stat-label text-sm text-gray-600">Total Trips</p>
                            <p class="navigo-stat-value text-2xl font-bold text-gray-900"><?php echo $trip_stats['total_trips'] ?? 0; ?></p>
                        </div>
                    </div>
                </div>

                <div class="navigo-stat-card bg-white rounded-lg border border-gray-200 p-6">
                    <div class="navigo-stat-content flex items-center">
                        <div class="navigo-stat-icon flex-shrink-0 w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                            <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1"/>
                            </svg>
                        </div>
                        <div class="navigo-stat-info ml-4">
                            <p class="navigo-stat-label text-sm text-gray-600">Money Saved</p>
                            <p class="navigo-stat-value text-2xl font-bold text-gray-900">$<?php echo number_format($trip_stats['money_saved'] ?? 0); ?></p>
                        </div>
                    </div>
                </div>

                <div class="navigo-stat-card bg-white rounded-lg border border-gray-200 p-6">
                    <div class="navigo-stat-content flex items-center">
                        <div class="navigo-stat-icon flex-shrink-0 w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                            <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/>
                            </svg>
                        </div>
                        <div class="navigo-stat-info ml-4">
                            <p class="navigo-stat-label text-sm text-gray-600">Countries Visited</p>
                            <p class="navigo-stat-value text-2xl font-bold text-gray-900"><?php echo $trip_stats['countries_visited'] ?? 0; ?></p>
                        </div>
                    </div>
                </div>

                <div class="navigo-stat-card bg-white rounded-lg border border-gray-200 p-6">
                    <div class="navigo-stat-content flex items-center">
                        <div class="navigo-stat-icon flex-shrink-0 w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                            <svg class="w-5 h-5 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                            </svg>
                        </div>
                        <div class="navigo-stat-info ml-4">
                            <p class="navigo-stat-label text-sm text-gray-600">Hours Planned</p>
                            <p class="navigo-stat-value text-2xl font-bold text-gray-900"><?php echo $trip_stats['hours_planned'] ?? 0; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Dashboard Content -->
        <div class="navigo-dashboard-content grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            <!-- Recent Trips -->
            <div class="navigo-recent-trips lg:col-span-2">
                <div class="navigo-section-card bg-white rounded-lg border border-gray-200 p-6">
                    <div class="navigo-section-header flex items-center justify-between mb-6">
                        <h2 class="navigo-section-title text-lg font-medium text-gray-900">Recent Trips</h2>
                        <a href="/my-trips.php" class="navigo-section-link text-sm text-blue-600 hover:text-blue-700">
                            View all trips
                        </a>
                    </div>
                    
                    <div class="navigo-trips-list space-y-4">
                        <?php if (empty($recent_trips)): ?>
                            <div class="navigo-empty-state text-center py-8">
                                <svg class="navigo-empty-icon w-12 h-12 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064"/>
                                </svg>
                                <h3 class="navigo-empty-title text-sm font-medium text-gray-900 mb-1">No trips yet</h3>
                                <p class="navigo-empty-description text-sm text-gray-500">Start planning your first adventure!</p>
                                <a href="/trip-creator.php" class="navigo-empty-action mt-4 inline-flex items-center px-4 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700">
                                    Create Your First Trip
                                </a>
                            </div>
                        <?php else: ?>
                            <?php foreach ($recent_trips as $trip): ?>
                                <div class="navigo-trip-item flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                                    <div class="navigo-trip-info flex items-center space-x-4">
                                        <img src="<?php echo htmlspecialchars($trip['destination_image'] ?? '/assets/images/default-destination.jpg'); ?>" 
                                             alt="<?php echo htmlspecialchars($trip['destination']); ?>"
                                             class="navigo-trip-image w-12 h-12 rounded-lg object-cover">
                                        <div class="navigo-trip-details">
                                            <h3 class="navigo-trip-title font-medium text-gray-900"><?php echo htmlspecialchars($trip['title']); ?></h3>
                                            <p class="navigo-trip-destination text-sm text-gray-500"><?php echo htmlspecialchars($trip['destination']); ?></p>
                                            <p class="navigo-trip-dates text-xs text-gray-400">
                                                <?php echo date('M j', strtotime($trip['start_date'])); ?> - <?php echo date('M j, Y', strtotime($trip['end_date'])); ?>
                                            </p>
                                        </div>
                                    </div>
                                    <div class="navigo-trip-actions flex items-center space-x-2">
                                        <span class="navigo-trip-status inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                            <?php echo $trip['status'] === 'completed' ? 'bg-green-100 text-green-800' : 
                                                     ($trip['status'] === 'active' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'); ?>">
                                            <?php echo ucfirst($trip['status']); ?>
                                        </span>
                                        <a href="/trip-details.php?id=<?php echo $trip['id']; ?>" class="navigo-trip-view text-blue-600 hover:text-blue-700">
                                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="navigo-dashboard-sidebar space-y-6">
                
                <!-- Quick Actions -->
                <div class="navigo-quick-actions bg-white rounded-lg border border-gray-200 p-6">
                    <h3 class="navigo-section-title font-medium text-gray-900 mb-4">Quick Actions</h3>
                    <div class="navigo-actions-list space-y-3">
                        <a href="/trip-creator.php" class="navigo-action-item flex items-center p-3 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
                            <svg class="w-5 h-5 text-blue-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
                            </svg>
                            <span class="text-sm font-medium text-blue-900">Plan New Trip</span>
                        </a>
                        <a href="/explore.php" class="navigo-action-item flex items-center p-3 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
                            <svg class="w-5 h-5 text-green-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
                            </svg>
                            <span class="text-sm font-medium text-green-900">Explore</span>
                        </a>
                        <a href="/business.php" class="navigo-action-item flex items-center p-3 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors">
                            <svg class="w-5 h-5 text-purple-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/>
                            </svg>
                            <span class="text-sm font-medium text-purple-900">Business Portal</span>
                        </a>
                    </div>
                </div>

                <!-- Travel Tips -->
                <div class="navigo-travel-tips bg-white rounded-lg border border-gray-200 p-6">
                    <h3 class="navigo-section-title font-medium text-gray-900 mb-4">Travel Tips</h3>
                    <div class="navigo-tips-list space-y-4">
                        <div class="navigo-tip-item">
                            <h4 class="navigo-tip-title text-sm font-medium text-gray-900 mb-1">Best Time to Book</h4>
                            <p class="navigo-tip-content text-xs text-gray-600">Book flights 6-8 weeks in advance for the best deals on domestic travel.</p>
                        </div>
                        <div class="navigo-tip-item">
                            <h4 class="navigo-tip-title text-sm font-medium text-gray-900 mb-1">Pack Smart</h4>
                            <p class="navigo-tip-content text-xs text-gray-600">Roll your clothes instead of folding to save 30% more space in your luggage.</p>
                        </div>
                        <div class="navigo-tip-item">
                            <h4 class="navigo-tip-title text-sm font-medium text-gray-900 mb-1">Stay Connected</h4>
                            <p class="navigo-tip-content text-xs text-gray-600">Download offline maps and translation apps before traveling internationally.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>