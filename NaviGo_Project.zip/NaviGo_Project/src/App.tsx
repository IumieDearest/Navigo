import { useState } from "react";
import { Header } from "./components/Header";
import { SimpleHeader } from "./components/SimpleHeader";
import { HeroSection } from "./components/HeroSection";
import { TripCreator } from "./components/TripCreator";
import { Features } from "./components/Features";
import { SubscriptionPlans } from "./components/SubscriptionPlans";
import { Footer } from "./components/Footer";
import { Dashboard } from "./components/Dashboard";
import { SimpleDashboard } from "./components/SimpleDashboard";
import { Welcome } from "./components/Welcome";
import { Profile } from "./components/Profile";
import { AccountSettings } from "./components/AccountSettings";
import { BillingPlans } from "./components/BillingPlans";
import { HelpSupport } from "./components/HelpSupport";
import { MyTrips } from "./components/MyTrips";
import { Explore } from "./components/Explore";

import { History } from "./components/History";
import { LandingHero } from "./components/LandingHero";
import { PlanTrip } from "./components/PlanTrip";
import { Notifications } from "./components/Notifications";
import { Subscription } from "./components/Subscription";
import { AccountTypeSelection } from "./components/AccountTypeSelection";
import { PartnerWelcome } from "./components/PartnerWelcome";
import { PartnerApp } from "./components/PartnerApp";
import { DarkModeProvider } from "./components/DarkModeContext";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { Button } from "./components/ui/button";
import { BottomNavigation } from "./components/BottomNavigation";

export default function App() {
  const [currentView, setCurrentView] = useState<'account-selection' | 'consumer-welcome' | 'partner-welcome' | 'consumer-app' | 'partner-app'>('account-selection');
  const [consumerView, setConsumerView] = useState<'landing' | 'dashboard' | 'simple' | 'profile' | 'account-settings' | 'billing' | 'help-support' | 'my-trips' | 'explore' | 'history' | 'plan-trip' | 'subscription' | 'notifications'>('landing');
  const [partnerBusinessType, setPartnerBusinessType] = useState<string>('');

  const handleConsumerLogin = () => {
    setCurrentView('consumer-app');
    setConsumerView('landing');
  };

  const handlePartnerLogin = (businessType?: string) => {
    setCurrentView('partner-app');
    if (businessType) {
      setPartnerBusinessType(businessType);
    }
  };

  const handleSelectConsumer = () => {
    setCurrentView('consumer-welcome');
  };

  const handleSelectPartner = () => {
    setCurrentView('partner-welcome');
  };

  const handleBackToSelection = () => {
    setCurrentView('account-selection');
  };

  const handleConsumerNavigation = (view: 'landing' | 'dashboard' | 'simple' | 'profile' | 'account-settings' | 'billing' | 'help-support' | 'my-trips' | 'explore' | 'history' | 'plan-trip' | 'subscription' | 'notifications') => {
    setConsumerView(view);
  };

  const handleBack = () => {
    setConsumerView('dashboard');
  };

  const handleSignOut = () => {
    setCurrentView('account-selection');
    setConsumerView('landing'); // Reset consumer view to default
    setPartnerBusinessType(''); // Reset partner business type
  };

  return (
    <DarkModeProvider>
      <ErrorBoundary>
        {/* Account Type Selection */}
        {currentView === 'account-selection' && (
          <AccountTypeSelection 
            onSelectConsumer={handleSelectConsumer}
            onSelectPartner={handleSelectPartner}
          />
        )}

        {/* Consumer Welcome */}
        {currentView === 'consumer-welcome' && (
          <Welcome onLogin={handleConsumerLogin} onBack={handleBackToSelection} />
        )}

        {/* Partner Welcome */}
        {currentView === 'partner-welcome' && (
          <PartnerWelcome onLogin={handlePartnerLogin} onBack={handleBackToSelection} />
        )}

        {/* Consumer App */}
        {currentView === 'consumer-app' && (
          <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-violet-50 dark:from-slate-900 dark:via-slate-950 dark:to-violet-950">
            {consumerView === 'simple' && (
              <ErrorBoundary fallback={<div className="h-16 bg-white border-b border-gray-200 flex items-center justify-center">Loading header...</div>}>
                <SimpleHeader />
              </ErrorBoundary>
            )}
            {consumerView !== 'simple' && (
              <ErrorBoundary fallback={<div className="h-16 bg-white border-b border-gray-200 flex items-center justify-center">Loading header...</div>}>
                <Header onNavigate={handleConsumerNavigation} onSignOut={handleSignOut} currentView={consumerView} />
              </ErrorBoundary>
            )}
            
            {/* View Toggle - Consumer App - Only show for landing and dashboard on desktop */}
            {(consumerView === 'landing' || consumerView === 'dashboard') && (
              <div className="hidden md:block sticky top-16 z-40 bg-white/80 dark:bg-gray-950/80 backdrop-blur-md border-b border-sky-200/30 dark:border-gray-800 py-3">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-center">
                  <div className="flex space-x-2 bg-white/70 dark:bg-gray-800/70 backdrop-blur-sm p-1 rounded-xl border border-sky-200/30 dark:border-gray-700 shadow-lg">
                    <Button
                      variant={consumerView === 'landing' ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => setConsumerView('landing')}
                      className={`px-6 py-2 rounded-lg transition-all duration-200 ${
                        consumerView === 'landing' 
                          ? 'bg-gradient-to-r from-sky-500 to-teal-500 text-white shadow-md' 
                          : 'hover:bg-sky-50 dark:hover:bg-sky-950/30'
                      }`}
                    >
                      Landing Page
                    </Button>
                    <Button
                      variant={consumerView === 'dashboard' ? 'default' : 'ghost'}
                      size="sm"
                      onClick={() => setConsumerView('dashboard')}
                      className={`px-6 py-2 rounded-lg transition-all duration-200 ${
                        consumerView === 'dashboard' 
                          ? 'bg-gradient-to-r from-sky-500 to-teal-500 text-white shadow-md' 
                          : 'hover:bg-sky-50 dark:hover:bg-sky-950/30'
                      }`}
                    >
                      Dashboard
                    </Button>
                  </div>
                </div>
              </div>
            )}

            <main className="pb-20 md:pb-0">
              <ErrorBoundary>
                {consumerView === 'landing' ? (
                  <>
                    <LandingHero />
                    <TripCreator />
                    <Features />
                    <SubscriptionPlans />
                  </>
                ) : consumerView === 'simple' ? (
                  <SimpleDashboard />
                ) : consumerView === 'profile' ? (
                  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                    <Profile />
                  </div>
                ) : consumerView === 'account-settings' ? (
                  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                    <AccountSettings onBack={handleBack} />
                  </div>
                ) : consumerView === 'billing' ? (
                  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                    <BillingPlans onBack={handleBack} />
                  </div>
                ) : consumerView === 'help-support' ? (
                  <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                    <HelpSupport onBack={handleBack} />
                  </div>
                ) : consumerView === 'my-trips' ? (
                  <MyTrips />
                ) : consumerView === 'explore' ? (
                  <Explore />
                ) : consumerView === 'history' ? (
                  <History />
                ) : consumerView === 'plan-trip' ? (
                  <PlanTrip onBack={handleBack} />
                ) : consumerView === 'subscription' ? (
                  <Subscription currentPlan="premium" />
                ) : consumerView === 'notifications' ? (
                  <Notifications onBack={handleBack} />
                ) : (
                  <Dashboard onNavigate={handleConsumerNavigation} />
                )}
              </ErrorBoundary>
            </main>
            
            {consumerView === 'landing' && (
              <ErrorBoundary fallback={<div className="bg-gray-50 p-8 text-center">Footer loading...</div>}>
                <Footer />
              </ErrorBoundary>
            )}
            
            {/* Bottom Navigation for Mobile */}
            <BottomNavigation 
              currentView={consumerView} 
              onNavigate={handleConsumerNavigation} 
            />
          </div>
        )}

        {/* Partner App */}
        {currentView === 'partner-app' && (
          <PartnerApp onSignOut={handleSignOut} businessType={partnerBusinessType} />
        )}
      </ErrorBoundary>
    </DarkModeProvider>
  );
}