import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Separator } from "./ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { NaviGoLogo } from "./NaviGoLogo";
import { MapPin, Shield, Users, Zap, Moon, Sun, ArrowLeft, Plane, Compass, Globe, Luggage, Camera, Heart } from "lucide-react";
import { useDarkMode } from "./DarkModeContext";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface WelcomeProps {
  onLogin: () => void;
  onBack?: () => void;
}

export function Welcome({ onLogin, onBack }: WelcomeProps) {
  const [isLoading, setIsLoading] = useState(false);
  const { isDark, toggleDark } = useDarkMode();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      onLogin();
    }, 1000);
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Abstract Background */}
      <div className="absolute inset-0 z-0">
        {/* Primary gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-sky-50 via-white to-teal-50 dark:from-slate-900 dark:via-slate-950 dark:to-teal-950" />
        
        {/* Abstract patterns */}
        <div className="absolute inset-0 travel-pattern-2" />
        
        {/* Organic shapes */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-sky-400/10 to-teal-400/10 rounded-full blur-3xl transform translate-x-32 -translate-y-32" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-gradient-to-tr from-violet-400/10 to-pink-400/10 rounded-full blur-3xl transform -translate-x-32 translate-y-32" />
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-gradient-to-br from-orange-400/5 to-yellow-400/5 rounded-full blur-3xl transform -translate-x-32 -translate-y-32" />
      </div>

      {/* Subtle geometric elements */}
      <div className="absolute inset-0 z-10 pointer-events-none overflow-hidden">
        <div className="absolute top-20 left-20 w-12 h-12 opacity-10">
          <Plane className="w-full h-full text-sky-600 dark:text-sky-400" />
        </div>
        <div className="absolute top-1/4 right-24 w-10 h-10 opacity-10">
          <Compass className="w-full h-full text-teal-600 dark:text-teal-400" />
        </div>
        <div className="absolute bottom-1/3 left-16 w-8 h-8 opacity-10">
          <Globe className="w-full h-full text-violet-600 dark:text-violet-400" />
        </div>
        <div className="absolute top-1/2 right-12 w-10 h-10 opacity-10">
          <Camera className="w-full h-full text-orange-600 dark:text-orange-400" />
        </div>
        <div className="absolute bottom-24 right-1/4 w-8 h-8 opacity-10">
          <Heart className="w-full h-full text-pink-600 dark:text-pink-400" />
        </div>
      </div>

      {/* Back Button */}
      {onBack && (
        <div className="fixed top-6 left-6 z-50">
          <Button
            variant="outline"
            size="icon"
            onClick={onBack}
            className="glass-card hover:bg-white/80 dark:hover:bg-black/80 shadow-lg border-gray-200/50 dark:border-gray-700/50"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Dark Mode Toggle */}
      <div className="fixed top-6 right-6 z-50">
        <Button
          variant="outline"
          size="icon"
          onClick={toggleDark}
          className="glass-card hover:bg-white/80 dark:hover:bg-black/80 shadow-lg border-gray-200/50 dark:border-gray-700/50"
        >
          {isDark ? (
            <Sun className="h-4 w-4 text-amber-500" />
          ) : (
            <Moon className="h-4 w-4 text-slate-600" />
          )}
        </Button>
      </div>

      {/* Main Content */}
      <div className="relative z-20 min-h-screen flex items-center justify-center p-4">

        <div className="w-full max-w-6xl grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Side - Branding and Features */}
          <div className="space-y-10 text-center lg:text-left">
            <div className="flex justify-center lg:justify-start">
              <NaviGoLogo variant="circular" size={120} />
            </div>
            
            <div className="space-y-6">
              <h1 className="text-4xl lg:text-6xl font-bold bg-gradient-to-r from-sky-600 via-teal-600 to-violet-600 dark:from-sky-400 dark:via-teal-400 dark:to-violet-400 bg-clip-text text-transparent leading-tight">
                Your Journey Starts Here
              </h1>
              <h2 className="text-2xl lg:text-3xl font-semibold text-gray-800 dark:text-gray-100">
                Welcome to NaviGo
              </h2>
              <p className="text-lg lg:text-xl text-gray-600 dark:text-gray-300 max-w-lg leading-relaxed">
                Your intelligent travel companion for seamless trip planning, 
                cost optimization, and collaborative group adventures that create lasting memories.
              </p>
            </div>

            <div className="grid sm:grid-cols-2 gap-6 max-w-lg mx-auto lg:mx-0">
              <div className="flex items-start space-x-4 glass-card rounded-xl p-4">
                <div className="flex-shrink-0 w-10 h-10 bg-gradient-to-br from-sky-400/20 to-sky-500/20 rounded-xl flex items-center justify-center">
                  <Zap className="w-5 h-5 text-sky-600 dark:text-sky-400" />
                </div>
                <div className="text-left">
                  <h3 className="font-semibold text-gray-800 dark:text-white">AI-Powered Planning</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Smart recommendations tailored for you</p>
                </div>
              </div>

              <div className="flex items-start space-x-4 glass-card rounded-xl p-4">
                <div className="flex-shrink-0 w-10 h-10 bg-gradient-to-br from-teal-400/20 to-teal-500/20 rounded-xl flex items-center justify-center">
                  <Shield className="w-5 h-5 text-teal-600 dark:text-teal-400" />
                </div>
                <div className="text-left">
                  <h3 className="font-semibold text-gray-800 dark:text-white">Secure & Synced</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300">All your adventures in one place</p>
                </div>
              </div>

              <div className="flex items-start space-x-4 glass-card rounded-xl p-4">
                <div className="flex-shrink-0 w-10 h-10 bg-gradient-to-br from-violet-400/20 to-violet-500/20 rounded-xl flex items-center justify-center">
                  <Users className="w-5 h-5 text-violet-600 dark:text-violet-400" />
                </div>
                <div className="text-left">
                  <h3 className="font-semibold text-gray-800 dark:text-white">Group Adventures</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Collaborate and explore together</p>
                </div>
              </div>

              <div className="flex items-start space-x-4 glass-card rounded-xl p-4">
                <div className="flex-shrink-0 w-10 h-10 bg-gradient-to-br from-orange-400/20 to-orange-500/20 rounded-xl flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-orange-600 dark:text-orange-400" />
                </div>
                <div className="text-left">
                  <h3 className="font-semibold text-gray-800 dark:text-white">Smart Savings</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-300">Optimize costs on every journey</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Side - Login Form */}
          <div className="flex justify-center">
            {/* Modern Login Form */}
            <div className="w-full max-w-md relative">
              {/* Modern Card Container */}
              <div className="glass-card rounded-2xl p-6 shadow-2xl">
                {/* Header */}
                <div className="text-center mb-6">
                  <div className="flex items-center justify-center space-x-2 mb-3">
                    <div className="w-8 h-8 bg-gradient-to-br from-sky-500 to-teal-500 rounded-lg flex items-center justify-center">
                      <Luggage className="w-4 h-4 text-white" />
                    </div>
                    <span className="bg-gradient-to-r from-sky-600 to-teal-600 bg-clip-text text-transparent font-semibold text-sm uppercase tracking-wide">NaviGo Access</span>
                  </div>
                  <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-1">Your Travel Portal</h2>
                  <p className="text-gray-600 dark:text-gray-300 text-sm">Access your personalized journey hub</p>
                </div>

                {/* Form Content */}
                <Card className="border-0 bg-transparent shadow-none">
                  <CardHeader className="space-y-1 text-center pb-4">
                    <CardTitle className="text-xl text-gray-800 dark:text-white">Access Your Journey</CardTitle>
                    <CardDescription>
                      Sign in to continue your travel story
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Tabs defaultValue="login" className="w-full">
                      <TabsList className="grid w-full grid-cols-2 mb-6 bg-gray-100 dark:bg-gray-800">
                        <TabsTrigger value="login" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-sky-500 data-[state=active]:to-teal-500 data-[state=active]:text-white">Sign In</TabsTrigger>
                        <TabsTrigger value="signup" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-sky-500 data-[state=active]:to-teal-500 data-[state=active]:text-white">New Journey</TabsTrigger>
                      </TabsList>

                      <TabsContent value="login" className="space-y-4">
                        <form onSubmit={handleSubmit} className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="email" className="flex items-center space-x-2">
                              <MapPin className="w-4 h-4 text-gray-500" />
                              <span>Email Address</span>
                            </Label>
                            <Input 
                              id="email" 
                              type="email" 
                              placeholder="traveler@example.com"
                              className="rounded-xl border-gray-200 dark:border-gray-700 focus:border-sky-500 focus:ring-sky-500"
                              required
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="password" className="flex items-center space-x-2">
                              <Shield className="w-4 h-4 text-gray-500" />
                              <span>Password</span>
                            </Label>
                            <Input 
                              id="password" 
                              type="password" 
                              placeholder="Your secure password"
                              className="rounded-xl border-gray-200 dark:border-gray-700 focus:border-sky-500 focus:ring-sky-500"
                              required
                            />
                          </div>
                          <Button 
                            type="submit" 
                            className="w-full bg-gradient-to-r from-sky-500 to-teal-500 hover:from-sky-600 hover:to-teal-600 text-white rounded-xl py-3 font-semibold shadow-lg transform hover:scale-105 transition-all duration-200" 
                            disabled={isLoading}
                          >
                            {isLoading ? (
                              <div className="flex items-center space-x-2">
                                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                <span>Boarding...</span>
                              </div>
                            ) : (
                              <div className="flex items-center space-x-2">
                                <Plane className="w-4 h-4" />
                                <span>Begin Journey</span>
                              </div>
                            )}
                          </Button>
                        </form>
                        
                        <div className="text-center">
                          <Button variant="link" className="text-sm text-sky-600 dark:text-sky-400 hover:text-sky-700 dark:hover:text-sky-300">
                            Lost your travel pass?
                          </Button>
                        </div>
                      </TabsContent>

                      <TabsContent value="signup" className="space-y-4">
                        <form onSubmit={handleSubmit} className="space-y-4">
                          <div className="grid grid-cols-2 gap-3">
                            <div className="space-y-2">
                              <Label htmlFor="firstName">First Name</Label>
                              <Input 
                                id="firstName" 
                                placeholder="Explorer"
                                className="rounded-xl border-gray-200 dark:border-gray-700 focus:border-teal-500 focus:ring-teal-500"
                                required
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="lastName">Last Name</Label>
                              <Input 
                                id="lastName" 
                                placeholder="Adventurer"
                                className="rounded-xl border-gray-200 dark:border-gray-700 focus:border-teal-500 focus:ring-teal-500"
                                required
                              />
                            </div>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="signupEmail" className="flex items-center space-x-2">
                              <Globe className="w-4 h-4 text-gray-500" />
                              <span>Email Address</span>
                            </Label>
                            <Input 
                              id="signupEmail" 
                              type="email" 
                              placeholder="explorer@wanderlust.com"
                              className="rounded-xl border-gray-200 dark:border-gray-700 focus:border-teal-500 focus:ring-teal-500"
                              required
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="signupPassword" className="flex items-center space-x-2">
                              <Shield className="w-4 h-4 text-gray-500" />
                              <span>Secure Password</span>
                            </Label>
                            <Input 
                              id="signupPassword" 
                              type="password" 
                              placeholder="Create your travel key"
                              className="rounded-xl border-gray-200 dark:border-gray-700 focus:border-teal-500 focus:ring-teal-500"
                              required
                            />
                          </div>
                          <Button 
                            type="submit" 
                            className="w-full bg-gradient-to-r from-teal-500 to-sky-500 hover:from-teal-600 hover:to-sky-600 text-white rounded-xl py-3 font-semibold shadow-lg transform hover:scale-105 transition-all duration-200" 
                            disabled={isLoading}
                          >
                            {isLoading ? (
                              <div className="flex items-center space-x-2">
                                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                <span>Creating passport...</span>
                              </div>
                            ) : (
                              <div className="flex items-center space-x-2">
                                <Compass className="w-4 h-4" />
                                <span>Start Adventure</span>
                              </div>
                            )}
                          </Button>
                        </form>
                      </TabsContent>
                    </Tabs>

                    <div className="mt-6">
                      <div className="relative">
                        <div className="absolute inset-0 flex items-center">
                          <Separator className="bg-gray-200 dark:bg-gray-700" />
                        </div>
                        <div className="relative flex justify-center text-xs uppercase">
                          <span className="bg-white dark:bg-gray-900 px-3 text-gray-500 dark:text-gray-400">
                            Quick Access
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-3 mt-4">
                        <Button 
                          variant="outline" 
                          onClick={onLogin}
                          className="rounded-xl border-gray-200 dark:border-gray-700 hover:bg-gradient-to-r hover:from-red-50 hover:to-orange-50 dark:hover:from-red-950 dark:hover:to-orange-950 hover:border-red-300 dark:hover:border-red-700 transition-all duration-200"
                        >
                          <svg className="w-4 h-4 mr-2" viewBox="0 0 24 24">
                            <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                            <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                            <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                            <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                          </svg>
                          Google
                        </Button>
                        <Button 
                          variant="outline" 
                          onClick={onLogin}
                          className="rounded-xl border-gray-200 dark:border-gray-700 hover:bg-gradient-to-r hover:from-blue-50 hover:to-sky-50 dark:hover:from-blue-950 dark:hover:to-sky-950 hover:border-blue-300 dark:hover:border-blue-700 transition-all duration-200"
                        >
                          <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12.017 0C5.396 0 .029 5.367.029 11.987c0 5.079 3.158 9.417 7.618 11.024-.105-.949-.199-2.403.041-3.439.219-.937 1.219-5.160 1.219-5.160s-.312-.219-.312-.937c0-.877.508-1.531 1.141-1.531.539 0 .799.406.799.891 0 .542-.219 1.219-.508 1.875-.406 1.312-.52 2.141-.52 2.141s1.094 1.094 2.688 1.094c3.229 0 5.688-3.365 5.688-7.948 0-3.312-2.312-5.792-6.052-5.792-4.309 0-6.859 3.186-6.859 6.739 0 1.218.406 2.076 1.072 2.776.208.25.235.406.156.656-.082.219-.269.969-.344 1.187-.094.282-.375.375-.656.219C4.594 16.311 3.812 14.23 3.812 11.987c0-4.522 4.037-8.965 11.286-8.965 5.901 0 9.791 4.229 9.791 8.751 0 5.969-3.312 10.531-8.125 10.531-1.619 0-3.125-.875-3.656-1.969 0 0-.813 3.156-.969 3.844-.281 1.125-1.016 2.531-1.594 3.5.031 0 1.187.281 1.844.281 6.624 0 11.99-5.367 11.99-11.987C24.007 5.367 18.641.001 12.017.001z"/>
                          </svg>
                          Microsoft
                        </Button>
                      </div>
                    </div>

                    <p className="text-xs text-center text-gray-500 dark:text-gray-400 mt-6">
                      By continuing your journey, you agree to our{" "}
                      <Button variant="link" className="p-0 h-auto text-xs text-sky-600 dark:text-sky-400 hover:text-sky-700 dark:hover:text-sky-300">
                        Terms of Service
                      </Button>{" "}
                      and{" "}
                      <Button variant="link" className="p-0 h-auto text-xs text-sky-600 dark:text-sky-400 hover:text-sky-700 dark:hover:text-sky-300">
                        Privacy Policy
                      </Button>
                    </p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}