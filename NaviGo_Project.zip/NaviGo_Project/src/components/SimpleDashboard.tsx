import { useState } from "react";
import { Calendar, MapPin, Users, Clock, DollarSign, TrendingUp, Plane } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ErrorBoundary } from "./ErrorBoundary";

export function SimpleDashboard() {
  const [activeTab, setActiveTab] = useState("overview");

  const upcomingTrips = [
    {
      id: 1,
      destination: "Tokyo, Japan",
      dates: "Mar 15-22, 2024",
      status: "Confirmed",
      budget: "$2,800",
      spent: "$1,200",
      progress: 43,
      image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400",
      travelers: 2,
      bookings: ["Flight", "Hotel", "Rail Pass"]
    },
    {
      id: 2,
      destination: "Paris, France",
      dates: "May 10-17, 2024",
      status: "Planning",
      budget: "$3,200",
      spent: "$0",
      progress: 15,
      image: "https://images.unsplash.com/photo-1502602898536-47ad22581b52?w=400",
      travelers: 1,
      bookings: ["Hotel"]
    }
  ];

  return (
    <ErrorBoundary>
      <section className="py-8 bg-gray-50 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Travel Dashboard</h1>
            <p className="text-gray-600">Manage your trips, bookings, and travel preferences in one place</p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-3 lg:w-fit">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="trips">My Trips</TabsTrigger>
              <TabsTrigger value="profile">Profile</TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <ErrorBoundary fallback={<div className="text-center p-8">Loading stats...</div>}>
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Total Trips</CardTitle>
                      <Plane className="w-4 h-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">23</div>
                      <p className="text-xs text-muted-foreground">+2 from last month</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">This Year Spent</CardTitle>
                      <DollarSign className="w-4 h-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">$12,450</div>
                      <p className="text-xs text-muted-foreground">+15% from last year</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Countries Visited</CardTitle>
                      <MapPin className="w-4 h-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">12</div>
                      <p className="text-xs text-muted-foreground">3 new this year</p>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">Savings</CardTitle>
                      <TrendingUp className="w-4 h-4 text-muted-foreground" />
                    </CardHeader>
                    <CardContent>
                      <div className="text-2xl font-bold">$2,100</div>
                      <p className="text-xs text-muted-foreground">Through bulk discounts</p>
                    </CardContent>
                  </Card>
                </div>
              </ErrorBoundary>

              {/* Upcoming Trips */}
              <ErrorBoundary fallback={<div className="text-center p-8">Loading trips...</div>}>
                <Card>
                  <CardHeader>
                    <CardTitle>Upcoming Trips</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {upcomingTrips.map((trip) => (
                        <ErrorBoundary key={trip.id} fallback={<div className="p-4 bg-gray-100 rounded-lg text-center">Loading trip...</div>}>
                          <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                            <ImageWithFallback
                              src={trip.image}
                              alt={trip.destination}
                              className="w-16 h-16 rounded-lg object-cover"
                            />
                            <div className="flex-1">
                              <div className="flex items-center justify-between mb-2">
                                <h3 className="font-semibold">{trip.destination}</h3>
                                <Badge variant={trip.status === "Confirmed" ? "default" : "secondary"}>
                                  {trip.status}
                                </Badge>
                              </div>
                              <p className="text-sm text-gray-600 mb-2">{trip.dates}</p>
                              <div className="flex items-center space-x-4 text-sm text-gray-500">
                                <span className="flex items-center gap-1">
                                  <Users className="w-4 h-4" />
                                  {trip.travelers} traveler{trip.travelers > 1 ? 's' : ''}
                                </span>
                                <span>Budget: {trip.budget}</span>
                                <span>Spent: {trip.spent}</span>
                              </div>
                              <div className="mt-2">
                                <div className="flex justify-between text-sm mb-1">
                                  <span>Trip Planning Progress</span>
                                  <span>{trip.progress}%</span>
                                </div>
                                <Progress value={trip.progress} className="h-2" />
                              </div>
                            </div>
                            <div className="flex flex-col space-y-2">
                              <Button size="sm">View Details</Button>
                            </div>
                          </div>
                        </ErrorBoundary>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </ErrorBoundary>
            </TabsContent>

            {/* Simple Trips Tab */}
            <TabsContent value="trips" className="space-y-6">
              <ErrorBoundary fallback={<div className="text-center p-8">Loading trips section...</div>}>
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-bold">My Trips</h2>
                  <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white">
                    Create New Trip
                  </Button>
                </div>
                <div className="grid gap-6">
                  {upcomingTrips.map((trip) => (
                    <ErrorBoundary key={trip.id} fallback={<div className="p-6 border rounded-lg text-center">Loading trip card...</div>}>
                      <Card>
                        <CardContent className="p-6">
                          <div className="flex items-start space-x-4">
                            <ImageWithFallback
                              src={trip.image}
                              alt={trip.destination}
                              className="w-24 h-24 rounded-lg object-cover"
                            />
                            <div className="flex-1">
                              <div className="flex items-center justify-between mb-2">
                                <h3 className="text-xl font-semibold">{trip.destination}</h3>
                                <Badge variant={trip.status === "Confirmed" ? "default" : "secondary"}>
                                  {trip.status}
                                </Badge>
                              </div>
                              <p className="text-gray-600 mb-4">{trip.dates}</p>
                              <div className="flex space-x-2">
                                <Button size="sm">View Itinerary</Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    </ErrorBoundary>
                  ))}
                </div>
              </ErrorBoundary>
            </TabsContent>

            {/* Simple Profile Tab */}
            <TabsContent value="profile" className="space-y-6">
              <ErrorBoundary fallback={<div className="text-center p-8">Loading profile...</div>}>
                <Card>
                  <CardHeader>
                    <CardTitle>Profile Information</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center space-x-4">
                      <div className="w-16 h-16 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-full flex items-center justify-center">
                        <span className="text-white font-medium text-lg">AR</span>
                      </div>
                      <div>
                        <h3 className="text-xl font-semibold">Anna Mae Regis</h3>
                        <p className="text-gray-600">aregis_ccs@uspf.edu.ph</p>
                        <Badge className="bg-orange-100 text-orange-800 mt-1">Premium Member</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </ErrorBoundary>
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </ErrorBoundary>
  );
}