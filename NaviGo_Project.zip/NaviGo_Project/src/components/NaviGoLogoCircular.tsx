import naviGoImage from 'figma:asset/79bd977b3889c1a721eb86afad67ab5e9ff98efe.png';

interface NaviGoLogoCircularProps {
  className?: string;
  size?: number;
}

export function NaviGoLogoCircular({ className = "", size = 120 }: NaviGoLogoCircularProps) {
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <div 
        className="relative rounded-full bg-white shadow-lg overflow-hidden"
        style={{ 
          width: size, 
          height: size,
          filter: 'drop-shadow(0 0 20px rgba(59, 130, 246, 0.3))'
        }}
      >
        <img 
          src={naviGoImage} 
          alt="NaviGo - Astria Travels" 
          className="w-full h-full object-contain p-2"
        />
      </div>
    </div>
  );
}