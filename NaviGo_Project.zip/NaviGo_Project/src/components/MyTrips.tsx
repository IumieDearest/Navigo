import { useState } from "react";
import { Calendar, MapPin, Users, Clock, DollarSign, Plane, Hotel, Car, Camera, Share2, Download, Plus, Filter, Search, MoreHorizontal, Edit, Trash2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function MyTrips() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  const trips = [
    {
      id: 1,
      destination: "Tokyo, Japan",
      dates: "Mar 15-22, 2024",
      status: "Confirmed",
      budget: 2800,
      spent: 1200,
      progress: 85,
      image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400",
      travelers: 2,
      duration: "8 days",
      bookings: {
        flights: 2,
        hotels: 3,
        activities: 5,
        transport: 2
      },
      highlights: ["Cherry Blossom Season", "Traditional Temples", "Modern Architecture"],
      type: "leisure"
    },
    {
      id: 2,
      destination: "Paris, France",
      dates: "May 10-17, 2024",
      status: "Planning",
      budget: 3200,
      spent: 450,
      progress: 35,
      image: "https://images.unsplash.com/photo-1502602898536-47ad22581b52?w=400",
      travelers: 1,
      duration: "7 days",
      bookings: {
        flights: 1,
        hotels: 1,
        activities: 2,
        transport: 0
      },
      highlights: ["Art Museums", "Fine Dining", "Historic Architecture"],
      type: "leisure"
    },
    {
      id: 3,
      destination: "New York, USA",
      dates: "Jun 5-8, 2024",
      status: "Business",
      budget: 1800,
      spent: 1800,
      progress: 100,
      image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=400",
      travelers: 1,
      duration: "4 days",
      bookings: {
        flights: 2,
        hotels: 1,
        activities: 1,
        transport: 3
      },
      highlights: ["Business Conference", "Networking Events", "Central Park"],
      type: "business"
    },
    {
      id: 4,
      destination: "Bali, Indonesia",
      dates: "Aug 20-30, 2024",
      status: "Wishlist",
      budget: 2200,
      spent: 0,
      progress: 5,
      image: "https://images.unsplash.com/photo-1537953773345-d172ccf13cf1?w=400",
      travelers: 2,
      duration: "10 days",
      bookings: {
        flights: 0,
        hotels: 0,
        activities: 0,
        transport: 0
      },
      highlights: ["Beach Relaxation", "Cultural Experiences", "Spa Retreats"],
      type: "leisure"
    }
  ];

  const filteredTrips = trips.filter(trip => {
    const matchesSearch = trip.destination.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         trip.highlights.some(h => h.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesFilter = filterStatus === "all" || trip.status.toLowerCase() === filterStatus.toLowerCase();
    return matchesSearch && matchesFilter;
  });

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "confirmed": return "default";
      case "planning": return "secondary";
      case "business": return "default";
      case "wishlist": return "outline";
      default: return "secondary";
    }
  };

  const TripCard = ({ trip }: { trip: typeof trips[0] }) => (
    <Card className="overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1 backdrop-blur-md bg-white/80 dark:bg-gray-900/80 border border-white/30 shadow-lg">
      <div className="relative">
        <ImageWithFallback
          src={trip.image}
          alt={trip.destination}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-4 right-4">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="sm" variant="secondary" className="bg-white/80 backdrop-blur-sm">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem>
                <Edit className="w-4 h-4 mr-2" />
                Edit Trip
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Share2 className="w-4 h-4 mr-2" />
                Share Trip
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Download className="w-4 h-4 mr-2" />
                Export Itinerary
              </DropdownMenuItem>
              <DropdownMenuItem className="text-red-600">
                <Trash2 className="w-4 h-4 mr-2" />
                Delete Trip
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        <Badge 
          variant={getStatusColor(trip.status)}
          className="absolute bottom-4 left-4"
        >
          {trip.status}
        </Badge>
      </div>
      
      <CardContent className="p-6">
        <div className="mb-4">
          <h3 className="text-xl font-semibold mb-2">{trip.destination}</h3>
          <div className="flex items-center text-gray-600 space-x-4 text-sm">
            <span className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              {trip.dates}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              {trip.duration}
            </span>
            <span className="flex items-center gap-1">
              <Users className="w-4 h-4" />
              {trip.travelers}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <p className="text-sm text-gray-500">Budget</p>
            <p className="font-semibold">${trip.budget.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Spent</p>
            <p className="font-semibold">${trip.spent.toLocaleString()}</p>
          </div>
        </div>

        <div className="mb-4">
          <div className="flex justify-between text-sm mb-2">
            <span>Planning Progress</span>
            <span>{trip.progress}%</span>
          </div>
          <Progress value={trip.progress} className="h-2" />
        </div>

        <div className="grid grid-cols-4 gap-2 mb-4">
          <div className="text-center">
            <Plane className="w-5 h-5 mx-auto mb-1 text-blue-500" />
            <span className="text-xs font-medium">{trip.bookings.flights}</span>
            <p className="text-xs text-gray-500">Flights</p>
          </div>
          <div className="text-center">
            <Hotel className="w-5 h-5 mx-auto mb-1 text-green-500" />
            <span className="text-xs font-medium">{trip.bookings.hotels}</span>
            <p className="text-xs text-gray-500">Hotels</p>
          </div>
          <div className="text-center">
            <Camera className="w-5 h-5 mx-auto mb-1 text-orange-500" />
            <span className="text-xs font-medium">{trip.bookings.activities}</span>
            <p className="text-xs text-gray-500">Activities</p>
          </div>
          <div className="text-center">
            <Car className="w-5 h-5 mx-auto mb-1 text-purple-500" />
            <span className="text-xs font-medium">{trip.bookings.transport}</span>
            <p className="text-xs text-gray-500">Transport</p>
          </div>
        </div>

        <div className="mb-4">
          <p className="text-sm text-gray-500 mb-2">Highlights</p>
          <div className="flex flex-wrap gap-1">
            {trip.highlights.map((highlight, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                {highlight}
              </Badge>
            ))}
          </div>
        </div>

        <div className="flex space-x-2">
          <Button size="sm" className="flex-1">
            View Details
          </Button>
          <Button size="sm" variant="outline">
            <Share2 className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Modern Abstract Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-teal-25 to-purple-50 dark:from-gray-900 dark:via-blue-950 dark:to-purple-950"></div>
      
      {/* Abstract Travel Shapes */}
      <div className="absolute top-10 left-10 w-96 h-96 bg-gradient-to-br from-blue-200/20 to-teal-200/20 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute top-1/3 right-20 w-64 h-64 bg-gradient-to-bl from-purple-200/15 to-blue-200/15 rounded-full blur-2xl animate-pulse delay-1000"></div>
      <div className="absolute bottom-20 left-1/4 w-80 h-80 bg-gradient-to-tr from-teal-200/10 to-cyan-200/10 rounded-full blur-3xl animate-pulse delay-2000"></div>
      
      {/* Curved Navigation Lines */}
      <svg className="absolute inset-0 w-full h-full opacity-30 dark:opacity-20" preserveAspectRatio="none" viewBox="0 0 1200 800">
        <defs>
          <linearGradient id="pathGradient1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.1"/>
            <stop offset="50%" stopColor="#3b82f6" stopOpacity="0.05"/>
            <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.1"/>
          </linearGradient>
          <linearGradient id="pathGradient2" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#14b8a6" stopOpacity="0.08"/>
            <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.12"/>
          </linearGradient>
        </defs>
        
        {/* Curved exploration paths */}
        <path d="M0,200 Q300,100 600,150 T1200,100" 
              stroke="url(#pathGradient1)" 
              strokeWidth="2" 
              fill="none"
              className="animate-pulse"/>
        <path d="M0,400 Q400,300 800,350 T1200,300" 
              stroke="url(#pathGradient2)" 
              strokeWidth="1.5" 
              fill="none"
              className="animate-pulse delay-500"/>
        <path d="M0,600 Q200,500 500,550 Q800,600 1200,500" 
              stroke="url(#pathGradient1)" 
              strokeWidth="1" 
              fill="none"
              className="animate-pulse delay-1000"/>
      </svg>
      
      {/* Floating Navigation Dots */}
      <div className="absolute top-1/4 left-1/3 w-3 h-3 bg-blue-400/40 rounded-full animate-bounce"></div>
      <div className="absolute top-2/3 right-1/4 w-2 h-2 bg-teal-400/40 rounded-full animate-bounce delay-300"></div>
      <div className="absolute bottom-1/3 left-1/2 w-2.5 h-2.5 bg-purple-400/40 rounded-full animate-bounce delay-700"></div>
      <div className="absolute top-1/2 right-1/3 w-2 h-2 bg-cyan-400/40 rounded-full animate-bounce delay-1000"></div>
      
      {/* Content Container */}
      <div className="relative z-10 p-6 space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 backdrop-blur-sm bg-white/60 dark:bg-gray-900/60 rounded-2xl p-6 border border-white/20 shadow-lg">
          <div>
            <h2 className="text-2xl font-bold bg-gradient-to-r from-blue-700 to-teal-600 dark:from-blue-400 dark:to-teal-400 bg-clip-text text-transparent">My Trips</h2>
            <p className="text-gray-600 dark:text-gray-300">Your smart travel companion for managing and tracking all adventures</p>
          </div>
          <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white shadow-lg backdrop-blur-sm">
            <Plus className="w-4 h-4 mr-2" />
            Create New Trip
          </Button>
        </div>

        {/* Filters and Search */}
        <div className="flex flex-col sm:flex-row gap-4 backdrop-blur-sm bg-white/40 dark:bg-gray-900/40 rounded-xl p-4 border border-white/20">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Search trips, destinations, or highlights..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/30"
            />
          </div>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-full sm:w-48 bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/30">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Trips</SelectItem>
              <SelectItem value="confirmed">Confirmed</SelectItem>
              <SelectItem value="planning">Planning</SelectItem>
              <SelectItem value="business">Business</SelectItem>
              <SelectItem value="wishlist">Wishlist</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" className="bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/30">
            <Filter className="w-4 h-4 mr-2" />
            More Filters
          </Button>
        </div>

        {/* Trip Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="backdrop-blur-md bg-white/70 dark:bg-gray-900/70 border border-white/20 shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Total Trips</p>
                  <p className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">{trips.length}</p>
                </div>
                <Plane className="w-8 h-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>
          <Card className="backdrop-blur-md bg-white/70 dark:bg-gray-900/70 border border-white/20 shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Total Budget</p>
                  <p className="text-2xl font-bold bg-gradient-to-r from-green-600 to-teal-600 bg-clip-text text-transparent">${trips.reduce((sum, trip) => sum + trip.budget, 0).toLocaleString()}</p>
                </div>
                <DollarSign className="w-8 h-8 text-green-500" />
              </div>
            </CardContent>
          </Card>
          <Card className="backdrop-blur-md bg-white/70 dark:bg-gray-900/70 border border-white/20 shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Countries</p>
                  <p className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">{new Set(trips.map(trip => trip.destination.split(',')[1]?.trim())).size}</p>
                </div>
                <MapPin className="w-8 h-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>
          <Card className="backdrop-blur-md bg-white/70 dark:bg-gray-900/70 border border-white/20 shadow-lg">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Avg Progress</p>
                  <p className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">{Math.round(trips.reduce((sum, trip) => sum + trip.progress, 0) / trips.length)}%</p>
                </div>
                <Clock className="w-8 h-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Trips Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTrips.map((trip) => (
            <TripCard key={trip.id} trip={trip} />
          ))}
        </div>

        {filteredTrips.length === 0 && (
          <div className="text-center py-12 backdrop-blur-md bg-white/60 dark:bg-gray-900/60 rounded-2xl border border-white/20 shadow-lg">
            <Plane className="w-16 h-16 mx-auto text-gray-300 mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No trips found</h3>
            <p className="text-gray-500 dark:text-gray-400 mb-4">Try adjusting your search or filters</p>
            <Button className="bg-gradient-to-r from-blue-500 to-teal-500 hover:from-blue-600 hover:to-teal-600 text-white">Create Your First Trip</Button>
          </div>
        )}
      </div>
    </div>
  );
}