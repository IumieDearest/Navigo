import { Bell, User, Menu } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { NaviGoLogo } from "./NaviGoLogo";

export function SimpleHeader() {
  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <NaviGoLogo variant="square" size={40} />

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#" className="text-gray-700 hover:text-gray-900 transition-colors">
              Dashboard
            </a>
            <a href="#" className="text-gray-700 hover:text-gray-900 transition-colors">
              My Trips
            </a>
            <a href="#" className="text-gray-700 hover:text-gray-900 transition-colors">
              Explore
            </a>
            <a href="#" className="text-gray-700 hover:text-gray-900 transition-colors">
              Business
            </a>
            <a href="#" className="text-gray-700 hover:text-gray-900 transition-colors">
              History
            </a>
          </nav>

          {/* Right side actions */}
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Bell className="w-5 h-5 text-gray-600 cursor-pointer hover:text-gray-900" />
              <div className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></div>
            </div>

            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-full flex items-center justify-center">
                <User className="w-4 h-4 text-white" />
              </div>
              <div className="hidden sm:block">
                <div className="flex items-center space-x-2">
                  <span className="font-medium text-gray-900">Anna Mae Regis</span>
                  <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                    Premium
                  </Badge>
                </div>
                <div className="text-xs text-gray-500">Unlimited trips</div>
              </div>
            </div>

            {/* Mobile Menu Button */}
            <Button className="md:hidden" variant="ghost" size="sm">
              <Menu className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}