import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { NaviGoLogo } from "./NaviGoLogo";
import { Building2, User, ArrowRight, Moon, Sun, Plane, Compass, MapPin, Globe, Mountain, Luggage } from "lucide-react";
import { useDarkMode } from "./DarkModeContext";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface AccountTypeSelectionProps {
  onSelectConsumer: () => void;
  onSelectPartner: () => void;
}

export function AccountTypeSelection({ onSelectConsumer, onSelectPartner }: AccountTypeSelectionProps) {
  const { isDark, toggleDark } = useDarkMode();

  return (
    <div className="min-h-screen relative overflow-hidden flex items-center justify-center p-4">
      {/* Abstract Background */}
      <div className="absolute inset-0 z-0">
        {/* Primary gradient background */}
        <div className="absolute inset-0 bg-gradient-to-br from-sky-50 via-violet-50 to-teal-50 dark:from-slate-900 dark:via-violet-950 dark:to-slate-950" />
        
        {/* Abstract geometric shapes */}
        <div className="absolute inset-0 travel-pattern-1" />
        <div className="absolute inset-0 travel-pattern-2" />
        
        {/* Floating abstract shapes */}
        <div className="absolute inset-0 floating-shapes" />
        
        {/* Organic blobs */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-gradient-to-br from-sky-400/10 to-teal-400/10 rounded-full blur-3xl transform -translate-x-32 -translate-y-32" />
        <div className="absolute top-1/2 right-0 w-80 h-80 bg-gradient-to-br from-violet-400/10 to-pink-400/10 rounded-full blur-3xl transform translate-x-32" />
        <div className="absolute bottom-0 left-1/3 w-72 h-72 bg-gradient-to-br from-orange-400/10 to-yellow-400/10 rounded-full blur-3xl transform translate-y-32" />
      </div>

      {/* Subtle travel iconography */}
      <div className="absolute inset-0 z-10 pointer-events-none overflow-hidden">
        <div className="absolute top-20 left-20 w-16 h-16 opacity-5">
          <Plane className="w-full h-full text-sky-600 dark:text-sky-400" />
        </div>
        <div className="absolute top-1/3 right-20 w-12 h-12 opacity-5">
          <Compass className="w-full h-full text-violet-600 dark:text-violet-400" />
        </div>
        <div className="absolute bottom-32 left-16 w-10 h-10 opacity-5">
          <MapPin className="w-full h-full text-teal-600 dark:text-teal-400" />
        </div>
        <div className="absolute top-1/2 left-8 w-8 h-8 opacity-5">
          <Globe className="w-full h-full text-orange-600 dark:text-orange-400" />
        </div>
        <div className="absolute bottom-20 right-24 w-14 h-14 opacity-5">
          <Mountain className="w-full h-full text-purple-600 dark:text-purple-400" />
        </div>
      </div>

      {/* Dark Mode Toggle */}
      <div className="fixed top-6 right-6 z-50">
        <Button
          variant="outline"
          size="icon"
          onClick={toggleDark}
          className="bg-white/90 dark:bg-black/60 backdrop-blur-md border border-white/30 dark:border-gray-600 hover:bg-white dark:hover:bg-black/80 shadow-lg"
        >
          {isDark ? (
            <Sun className="h-4 w-4 text-amber-500" />
          ) : (
            <Moon className="h-4 w-4 text-slate-600" />
          )}
        </Button>
      </div>

      <div className="w-full max-w-5xl relative z-20">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex justify-center mb-8 transform hover:scale-105 transition-transform duration-300">
            <NaviGoLogo variant="circular" size={120} />
          </div>
          <div className="space-y-6">
            <h1 className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-sky-600 via-violet-600 to-teal-600 dark:from-sky-400 dark:via-violet-400 dark:to-teal-400 bg-clip-text text-transparent mb-6 leading-tight">
              Ready for Adventure?
            </h1>
            <h2 className="text-2xl md:text-3xl font-semibold text-gray-800 dark:text-gray-100 mb-4">
              Welcome to NaviGo
            </h2>
            <p className="text-lg md:text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto leading-relaxed">
              Your journey begins here. Choose your travel companion and unlock a world of intelligent planning, seamless experiences, and unforgettable adventures.
            </p>
          </div>
        </div>

        {/* Travel Pass Cards */}
        <div className="grid md:grid-cols-2 gap-10 max-w-5xl mx-auto">
          {/* Personal Traveler Pass */}
          <div 
            onClick={onSelectConsumer}
            className="relative group cursor-pointer transform hover:scale-105 transition-all duration-500 hover:rotate-1"
          >
            {/* Boarding Pass Design */}
            <div className="relative overflow-hidden bg-gradient-to-br from-sky-400 via-sky-500 to-teal-500 dark:from-sky-600 dark:via-sky-700 dark:to-teal-600 rounded-2xl shadow-2xl border border-sky-300/20 dark:border-sky-600/20">
              {/* Perforated Edge */}
              <div className="absolute right-0 top-0 bottom-0 w-8 bg-gradient-to-b from-white/10 via-white/5 to-white/10">
                <div className="flex flex-col justify-center items-center h-full space-y-2">
                  {Array.from({ length: 8 }).map((_, i) => (
                    <div key={i} className="w-1 h-1 bg-white/30 rounded-full" />
                  ))}
                </div>
              </div>
              
              {/* Background Pattern */}
              <div className="absolute inset-0 opacity-10">
                <div className="absolute top-4 left-4">
                  <Plane className="w-16 h-16 text-white transform rotate-45" />
                </div>
                <div className="absolute bottom-4 right-12">
                  <Compass className="w-12 h-12 text-white" />
                </div>
              </div>

              <div className="relative z-10 p-8">
                {/* Header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                      <Luggage className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="text-xs font-medium text-white/80 uppercase tracking-wide">Travel Pass</div>
                      <div className="text-sm font-bold text-white">Personal Explorer</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-white/70">Type</div>
                    <div className="text-sm font-bold text-white">INDIVIDUAL</div>
                  </div>
                </div>

                {/* Main Content */}
                <div className="space-y-6">
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-2">Personal Account</h3>
                    <p className="text-white/90 text-sm leading-relaxed">
                      Your personal gateway to intelligent travel planning and unforgettable adventures
                    </p>
                  </div>

                  {/* Features */}
                  <div className="space-y-3">
                    {[
                      "AI-powered recommendations",
                      "Secure itinerary storage",
                      "Group collaboration",
                      "Cost optimization",
                      "Cross-platform sync"
                    ].map((feature, index) => (
                      <div key={index} className="flex items-center text-white/90 text-sm">
                        <div className="w-1.5 h-1.5 bg-white/70 rounded-full mr-3 flex-shrink-0" />
                        {feature}
                      </div>
                    ))}
                  </div>

                  {/* CTA Button */}
                  <div className="pt-4">
                    <div className="bg-white/15 backdrop-blur-sm rounded-xl p-4 border border-white/20 group-hover:bg-white/25 transition-all duration-300">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-white font-semibold">Start Your Journey</div>
                          <div className="text-white/70 text-xs">Free plan available</div>
                        </div>
                        <ArrowRight className="w-5 h-5 text-white group-hover:translate-x-1 transition-transform" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Business Partner Pass */}
          <div 
            onClick={onSelectPartner}
            className="relative group cursor-pointer transform hover:scale-105 transition-all duration-500 hover:-rotate-1"
          >
            {/* VIP Pass Design */}
            <div className="relative overflow-hidden bg-gradient-to-br from-violet-500 via-purple-600 to-indigo-600 dark:from-violet-600 dark:via-purple-700 dark:to-indigo-700 rounded-2xl shadow-2xl border border-violet-300/20 dark:border-violet-600/20">
              {/* Perforated Edge */}
              <div className="absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-b from-white/10 via-white/5 to-white/10">
                <div className="flex flex-col justify-center items-center h-full space-y-2">
                  {Array.from({ length: 8 }).map((_, i) => (
                    <div key={i} className="w-1 h-1 bg-white/30 rounded-full" />
                  ))}
                </div>
              </div>
              
              {/* Background Pattern */}
              <div className="absolute inset-0 opacity-10">
                <div className="absolute top-4 right-4">
                  <Building2 className="w-16 h-16 text-white" />
                </div>
                <div className="absolute bottom-4 left-12">
                  <Globe className="w-12 h-12 text-white" />
                </div>
              </div>

              <div className="relative z-10 p-8 pl-12">
                {/* Header */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                      <Building2 className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <div className="text-xs font-medium text-white/80 uppercase tracking-wide">Partner Access</div>
                      <div className="text-sm font-bold text-white">Business Elite</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-white/70">Type</div>
                    <div className="text-sm font-bold text-white">ENTERPRISE</div>
                  </div>
                </div>

                {/* Main Content */}
                <div className="space-y-6">
                  <div>
                    <h3 className="text-2xl font-bold text-white mb-2">Business Partner</h3>
                    <p className="text-white/90 text-sm leading-relaxed">
                      Connect with travelers worldwide and grow your business through our premium network
                    </p>
                  </div>

                  {/* Features */}
                  <div className="space-y-3">
                    {[
                      "Booking & inventory management",
                      "Advanced analytics dashboard",
                      "System integrations",
                      "Bulk discount controls",
                      "Enterprise security"
                    ].map((feature, index) => (
                      <div key={index} className="flex items-center text-white/90 text-sm">
                        <div className="w-1.5 h-1.5 bg-white/70 rounded-full mr-3 flex-shrink-0" />
                        {feature}
                      </div>
                    ))}
                  </div>

                  {/* CTA Button */}
                  <div className="pt-4">
                    <div className="bg-white/15 backdrop-blur-sm rounded-xl p-4 border border-white/20 group-hover:bg-white/25 transition-all duration-300">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-white font-semibold">Join Our Network</div>
                          <div className="text-white/70 text-xs">Custom enterprise pricing</div>
                        </div>
                        <ArrowRight className="w-5 h-5 text-white group-hover:translate-x-1 transition-transform" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-16">
          <div className="glass-card rounded-2xl p-6 max-w-md mx-auto">
            <p className="text-gray-700 dark:text-gray-300 mb-4">
              Already have an account?
            </p>
            <Button 
              className="bg-gradient-to-r from-sky-500 to-teal-500 hover:from-sky-600 hover:to-teal-600 text-white border-0 shadow-lg transform hover:scale-105 transition-all duration-200"
              onClick={onSelectConsumer}
            >
              Sign In to Your Journey
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
          
          {/* Adventure Quote */}
          <div className="mt-8 max-w-lg mx-auto">
            <p className="text-gray-500 dark:text-gray-400 text-sm italic">
              "The world is a book, and those who do not travel read only one page."
            </p>
            <p className="text-gray-400 dark:text-gray-500 text-xs mt-1">
              — Saint Augustine
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}