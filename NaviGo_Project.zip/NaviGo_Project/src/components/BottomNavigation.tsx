import { Map, Luggage, Compass, Crown, MapPin, History } from "lucide-react";

interface BottomNavigationProps {
  currentView: string;
  onNavigate: (view: string) => void;
}

export function BottomNavigation({ currentView, onNavigate }: BottomNavigationProps) {
  const navItems = [
    { 
      name: "Dashboard", 
      view: "dashboard", 
      icon: Map,
      color: "from-sky-500 to-teal-500"
    },
    { 
      name: "Trips", 
      view: "my-trips", 
      icon: Luggage,
      color: "from-teal-500 to-emerald-500"
    },
    { 
      name: "Explore", 
      view: "explore", 
      icon: Compass,
      color: "from-violet-500 to-purple-500"
    },
    { 
      name: "History", 
      view: "history", 
      icon: History,
      color: "from-orange-500 to-red-500"
    },
    { 
      name: "Plan", 
      view: "plan-trip", 
      icon: MapPin,
      color: "from-emerald-500 to-teal-500"
    },
    { 
      name: "Plans", 
      view: "subscription", 
      icon: Crown,
      color: "from-purple-500 to-pink-500"
    },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-50 glass-card border-t border-gray-200/50 dark:border-slate-800/50 px-2 py-2 safe-area-pb">
      <nav className="flex items-center justify-around max-w-md mx-auto">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentView === item.view;
          
          return (
            <button
              key={item.name}
              onClick={() => onNavigate(item.view)}
              className={`flex flex-col items-center justify-center p-1 min-w-0 flex-1 rounded-xl transition-all duration-200 active:scale-95 hover:scale-105 ${
                isActive 
                  ? 'text-white' 
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300'
              }`}
            >
              <div className={`relative p-2 rounded-xl transition-all duration-200 ${
                isActive 
                  ? `bg-gradient-to-r ${item.color} shadow-lg scale-105` 
                  : 'hover:bg-gray-100 dark:hover:bg-gray-800/50 hover:scale-110'
              }`}>
                <Icon className="w-5 h-5" />
                {isActive && (
                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-white rounded-full shadow-sm"></div>
                )}
              </div>
              <span className={`text-xs font-medium mt-1 truncate max-w-full transition-colors duration-200 ${
                isActive 
                  ? 'text-gray-900 dark:text-white' 
                  : 'text-gray-500 dark:text-gray-400'
              }`}>
                {item.name}
              </span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}