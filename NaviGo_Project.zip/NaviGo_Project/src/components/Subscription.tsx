import { 
  Check, 
  Star, 
  Building, 
  Users, 
  MessageSquare, 
  Calendar, 
  Shield, 
  CreditCard, 
  Map, 
  Plane, 
  Globe, 
  HeadphonesIcon,
  Zap,
  Clock,
  Crown,
  Sparkles
} from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";

interface SubscriptionProps {
  currentPlan?: 'free' | 'traveler' | 'premium';
}

export function Subscription({ currentPlan = 'free' }: SubscriptionProps) {
  const plans = [
    {
      id: 'free',
      name: 'Free',
      price: '₱0',
      description: '/month',
      icon: Map,
      color: 'gray',
      features: [
        'Search destinations, flights & hotels',
        'Simple itineraries',
        'Limited travel guides',
        'Last 3 trips',
        '1 calendar'
      ],
      buttonText: 'Current Plan',
      buttonAction: 'current'
    },
    {
      id: 'traveler',
      name: 'Traveler',
      price: '₱250',
      description: '/month',
      icon: Plane,
      color: 'blue',
      features: [
        'AI recommendations',
        'Booking & cloud storage',
        'Multi-calendar',
        'Offline access',
        'Priority support'
      ],
      buttonText: 'Upgrade to Traveler',
      buttonAction: 'upgrade'
    },
    {
      id: 'premium',
      name: 'Premium',
      price: '₱499',
      description: '/month',
      icon: Crown,
      color: 'orange',
      popular: true,
      features: [
        'All Traveler features',
        '24/7 concierge service',
        'Group travel (up to 10)',
        'Integrated travel insurance',
        'Priority support'
      ],
      buttonText: 'Upgrade to Premium',
      buttonAction: 'upgrade'
    }
  ];

  const getButtonVariant = (plan: typeof plans[0]) => {
    if (plan.id === currentPlan) {
      return 'outline';
    }
    if (plan.popular) {
      return 'default';
    }
    return 'outline';
  };

  const getButtonClass = (plan: typeof plans[0]) => {
    if (plan.id === currentPlan) {
      return 'bg-green-50 border-green-200 text-green-700 hover:bg-green-100 dark:bg-green-950/50 dark:border-green-800 dark:text-green-400';
    }
    if (plan.popular) {
      return 'bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white shadow-lg';
    }
    switch (plan.color) {
      case 'blue':
        return 'bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white shadow-lg';
      case 'purple':
        return 'bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-600 hover:to-indigo-600 text-white shadow-lg';
      default:
        return 'bg-gradient-to-r from-gray-500 to-gray-600 hover:from-gray-600 hover:to-gray-700 text-white shadow-lg';
    }
  };

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Modern gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-950 dark:to-blue-950"></div>
      
      {/* Abstract travel shapes */}
      <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-br from-blue-200/30 to-purple-200/30 rounded-full blur-xl"></div>
      <div className="absolute bottom-20 right-10 w-40 h-40 bg-gradient-to-br from-orange-200/30 to-pink-200/30 rounded-full blur-xl"></div>
      <div className="absolute top-1/2 left-1/3 w-24 h-24 bg-gradient-to-br from-green-200/20 to-blue-200/20 rounded-full blur-lg"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm px-4 py-2 rounded-full border border-white/20 mb-6">
            <Crown className="w-4 h-4 text-orange-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Manage Your Plan</span>
          </div>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Subscription Plans
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            Choose the perfect plan for your travel adventures. Upgrade anytime to unlock more features.
          </p>
        </div>

        {/* Current Plan Badge */}
        {currentPlan && currentPlan !== 'free' && (
          <div className="flex justify-center mb-8">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-green-100 to-emerald-100 dark:from-green-950/50 dark:to-emerald-950/50 px-6 py-3 rounded-full border border-green-200/50 dark:border-green-800/50">
              <Sparkles className="w-5 h-5 text-green-600 dark:text-green-400" />
              <span className="font-semibold text-green-800 dark:text-green-300">
                Current Plan: {plans.find(p => p.id === currentPlan)?.name}
              </span>
            </div>
          </div>
        )}

        <div className="grid lg:grid-cols-3 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {plans.map((plan) => {
            const Icon = plan.icon;
            const isCurrentPlan = plan.id === currentPlan;
            
            return (
              <Card 
                key={plan.id}
                className={`relative backdrop-blur-md border shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 hover:scale-105 cursor-pointer group ${
                  plan.popular 
                    ? 'bg-gradient-to-br from-orange-50/80 to-pink-50/80 dark:from-orange-950/80 dark:to-pink-950/80 border-2 border-gradient-to-r from-orange-300 to-pink-300 scale-105' 
                    : isCurrentPlan
                    ? 'bg-gradient-to-br from-green-50/80 to-emerald-50/80 dark:from-green-950/80 dark:to-emerald-950/80 border-2 border-green-300 dark:border-green-700'
                    : 'bg-white/60 dark:bg-gray-900/60 border-white/20 hover:bg-white/80 dark:hover:bg-gray-900/80'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-gradient-to-r from-orange-500 to-pink-500 text-white px-6 py-2 rounded-full shadow-lg">
                      ⭐ Most Popular
                    </Badge>
                  </div>
                )}
                
                {isCurrentPlan && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white px-6 py-2 rounded-full shadow-lg">
                      ✓ Current Plan
                    </Badge>
                  </div>
                )}
                
                <CardHeader className={`text-center pb-6 ${plan.popular || isCurrentPlan ? 'pt-8' : ''}`}>
                  <div className={`mx-auto w-16 h-16 rounded-2xl flex items-center justify-center mb-4 shadow-lg ${
                    plan.color === 'blue' ? 'bg-gradient-to-br from-blue-100 to-blue-200 dark:from-blue-900/50 dark:to-blue-800/50' :
                    plan.color === 'orange' ? 'bg-gradient-to-br from-orange-100 to-pink-100 dark:from-orange-900/50 dark:to-pink-900/50' :
                    plan.color === 'purple' ? 'bg-gradient-to-br from-purple-100 to-indigo-100 dark:from-purple-900/50 dark:to-indigo-900/50' :
                    'bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-800'
                  }`}>
                    <Icon className={`w-8 h-8 ${
                      plan.color === 'blue' ? 'text-blue-600 dark:text-blue-400' :
                      plan.color === 'orange' ? 'text-orange-600 dark:text-orange-400' :
                      plan.color === 'purple' ? 'text-purple-600 dark:text-purple-400' :
                      'text-gray-600 dark:text-gray-400'
                    } ${plan.popular ? 'fill-current' : ''}`} />
                  </div>
                  <CardTitle className="text-xl mb-2">{plan.name}</CardTitle>
                  <div className="mb-4">
                    <span className={`text-4xl font-bold bg-gradient-to-br bg-clip-text text-transparent ${
                      plan.color === 'blue' ? 'from-blue-600 to-cyan-600' :
                      plan.color === 'orange' ? 'from-orange-600 to-pink-600' :
                      plan.color === 'purple' ? 'from-purple-600 to-indigo-600' :
                      'from-gray-600 to-gray-800 dark:from-gray-200 dark:to-gray-400'
                    }`}>
                      {plan.price}
                    </span>
                    <span className="text-gray-600 dark:text-gray-400 block text-sm">{plan.description}</span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className={`w-full rounded-xl shadow-lg font-semibold transition-all duration-200 hover:scale-105 active:scale-95 ${getButtonClass(plan)}`}
                    variant={getButtonVariant(plan)}
                    disabled={isCurrentPlan}
                  >
                    {isCurrentPlan ? 'Current Plan' : plan.buttonText}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Trust indicators and support */}
        <div className="mt-16 text-center">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 border border-white/20 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                Need help choosing the right plan?
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                Our travel experts are here to help you find the perfect plan for your adventures. 
                All plans include secure cloud storage, mobile sync, and 30-day money-back guarantee.
              </p>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">99.9%</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Uptime</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600 dark:text-green-400">24/7</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Support</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">30</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Day trial</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">50K+</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Happy travelers</div>
                </div>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 rounded-xl shadow-lg">
                  Contact Sales Team
                </Button>
                <Button variant="outline" className="px-8 py-3 rounded-xl">
                  Compare All Features
                </Button>
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-4">
                No setup fees • Cancel anytime • 30-day money-back guarantee
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}