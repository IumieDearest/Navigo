import { useState } from "react";
import { PartnerHeader } from "./PartnerHeader";
import { PartnerDashboardCleaned } from "./PartnerDashboardCleaned";
import { PartnerAccountManagement } from "./PartnerAccountManagement";
import { PartnerBilling } from "./PartnerBilling";
import { PartnerSettings } from "./PartnerSettings";
import { PartnerHelpSupport } from "./PartnerHelpSupport";
import { PartnerSubscriptionPlans } from "./PartnerSubscriptionPlans";
import { ErrorBoundary } from "./ErrorBoundary";

interface PartnerAppProps {
  onSignOut?: () => void;
  businessType?: string;
}

export function PartnerApp({ onSignOut, businessType = 'other' }: PartnerAppProps) {
  const [currentView, setCurrentView] = useState<'dashboard' | 'account-management' | 'billing' | 'settings' | 'help-support' | 'subscription'>('dashboard');

  const handleNavigation = (view: 'dashboard' | 'account-management' | 'billing' | 'settings' | 'help-support' | 'subscription') => {
    setCurrentView(view);
  };

  return (
    <div className="min-h-screen bg-white dark:bg-gray-950">
      <ErrorBoundary fallback={<div className="h-16 bg-white border-b border-gray-200 flex items-center justify-center">Loading header...</div>}>
        <PartnerHeader onNavigate={handleNavigation} onSignOut={onSignOut} />
      </ErrorBoundary>
      
      <main>
        <ErrorBoundary>
          {currentView === 'dashboard' && (
            <PartnerDashboardCleaned 
              partnerType={businessType} 
              partnerName="Skyline Airways" 
            />
          )}
          {currentView === 'account-management' && (
            <PartnerAccountManagement onBack={() => setCurrentView('dashboard')} />
          )}
          {currentView === 'billing' && (
            <PartnerBilling onBack={() => setCurrentView('dashboard')} />
          )}
          {currentView === 'settings' && (
            <PartnerSettings onBack={() => setCurrentView('dashboard')} />
          )}
          {currentView === 'help-support' && (
            <PartnerHelpSupport onBack={() => setCurrentView('dashboard')} />
          )}
          {currentView === 'subscription' && (
            <PartnerSubscriptionPlans onBack={() => setCurrentView('dashboard')} currentPlan="professional" />
          )}
        </ErrorBoundary>
      </main>
    </div>
  );
}