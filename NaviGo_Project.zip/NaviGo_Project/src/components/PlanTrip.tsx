import { useState } from "react";
import { Calendar, MapPin, Users, Plane, Hotel, Car, ArrowRight, Plus, X } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";

interface PlanTripProps {
  onBack?: () => void;
}

export function PlanTrip({ onBack }: PlanTripProps) {
  const [tripType, setTripType] = useState<"round-trip" | "one-way" | "multi-city">("round-trip");
  const [travelers, setTravelers] = useState(1);
  const [stops, setStops] = useState([
    { from: "", to: "", date: "" },
  ]);

  const addStop = () => {
    setStops([...stops, { from: "", to: "", date: "" }]);
  };

  const removeStop = (index: number) => {
    if (stops.length > 1) {
      setStops(stops.filter((_, i) => i !== index));
    }
  };

  const updateStop = (index: number, field: string, value: string) => {
    const updatedStops = stops.map((stop, i) => 
      i === index ? { ...stop, [field]: value } : stop
    );
    setStops(updatedStops);
  };

  const handleSearch = () => {
    // This would typically trigger the search functionality
    console.log("Searching trips...", { tripType, travelers, stops });
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Plan Your Trip</h1>
              <p className="text-gray-600 dark:text-gray-400 mt-2">Find the best flights, hotels, and activities for your journey</p>
            </div>
            {onBack && (
              <Button variant="outline" onClick={onBack}>
                Back to Dashboard
              </Button>
            )}
          </div>
        </div>

        {/* Trip Planning Form */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plane className="w-5 h-5" />
              Flight Search
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Trip Type */}
            <div className="flex gap-2">
              <Button 
                variant={tripType === "round-trip" ? "default" : "outline"}
                size="sm"
                onClick={() => setTripType("round-trip")}
              >
                Round Trip
              </Button>
              <Button 
                variant={tripType === "one-way" ? "default" : "outline"}
                size="sm"
                onClick={() => setTripType("one-way")}
              >
                One Way
              </Button>
              <Button 
                variant={tripType === "multi-city" ? "default" : "outline"}
                size="sm"
                onClick={() => setTripType("multi-city")}
              >
                Multi-City
              </Button>
            </div>

            {/* Flight Details */}
            <div className="space-y-4">
              {stops.map((stop, index) => (
                <div key={index} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-medium">
                      {tripType === "multi-city" ? `Flight ${index + 1}` : "Flight Details"}
                    </h3>
                    {tripType === "multi-city" && stops.length > 1 && (
                      <Button variant="ghost" size="sm" onClick={() => removeStop(index)}>
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor={`from-${index}`}>From</Label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                        <Input
                          id={`from-${index}`}
                          placeholder="Departure city"
                          className="pl-10"
                          value={stop.from}
                          onChange={(e) => updateStop(index, "from", e.target.value)}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor={`to-${index}`}>To</Label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                        <Input
                          id={`to-${index}`}
                          placeholder="Destination city"
                          className="pl-10"
                          value={stop.to}
                          onChange={(e) => updateStop(index, "to", e.target.value)}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor={`date-${index}`}>
                        {index === 0 ? "Departure" : tripType === "round-trip" && index === 1 ? "Return" : "Date"}
                      </Label>
                      <div className="relative">
                        <Calendar className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                        <Input
                          id={`date-${index}`}
                          type="date"
                          className="pl-10"
                          value={stop.date}
                          onChange={(e) => updateStop(index, "date", e.target.value)}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {/* Add return flight for round trip */}
              {tripType === "round-trip" && stops.length === 1 && (
                <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
                  <h3 className="font-medium mb-4">Return Flight</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label>From</Label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                        <Input placeholder="Return from" className="pl-10" />
                      </div>
                    </div>
                    <div>
                      <Label>To</Label>
                      <div className="relative">
                        <MapPin className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                        <Input placeholder="Return to" className="pl-10" />
                      </div>
                    </div>
                    <div>
                      <Label>Return Date</Label>
                      <div className="relative">
                        <Calendar className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                        <Input type="date" className="pl-10" />
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Add Flight Button for Multi-City */}
              {tripType === "multi-city" && (
                <Button variant="outline" onClick={addStop} className="w-full">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Another Flight
                </Button>
              )}
            </div>

            {/* Travelers */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="travelers">Travelers</Label>
                <div className="relative">
                  <Users className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                  <Select value={travelers.toString()} onValueChange={(value) => setTravelers(parseInt(value))}>
                    <SelectTrigger className="pl-10">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((num) => (
                        <SelectItem key={num} value={num.toString()}>
                          {num} {num === 1 ? "Traveler" : "Travelers"}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <Label htmlFor="class">Travel Class</Label>
                <Select defaultValue="economy">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="economy">Economy</SelectItem>
                    <SelectItem value="premium">Premium Economy</SelectItem>
                    <SelectItem value="business">Business</SelectItem>
                    <SelectItem value="first">First Class</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Search Button */}
            <Button onClick={handleSearch} className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700">
              <Plane className="w-4 h-4 mr-2" />
              Search Flights
            </Button>
          </CardContent>
        </Card>

        {/* Quick Options */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Hotel className="w-5 h-5" />
                Hotels & Accommodations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-400 mb-4">Find the perfect place to stay</p>
              <Button variant="outline" className="w-full">
                Search Hotels
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Car className="w-5 h-5" />
                Car Rentals
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 dark:text-gray-400 mb-4">Get around with ease</p>
              <Button variant="outline" className="w-full">
                Rent a Car
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Trip Suggestions */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Popular Destinations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {["New York", "Paris", "Tokyo", "London", "Dubai", "Sydney", "Barcelona", "Amsterdam"].map((city) => (
                <Badge key={city} variant="secondary" className="cursor-pointer hover:bg-gray-200 dark:hover:bg-gray-700 p-2 justify-center">
                  {city}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}