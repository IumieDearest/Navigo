import { useState } from "react";
import { Bell, History, Menu, User, X, Plane, Map, Building, HelpCircle, Compass, Settings, LogOut, CreditCard, Calendar, Moon, Sun, MapPin, Luggage, Crown } from "lucide-react";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { NaviGoLogo } from "./NaviGoLogo";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "./ui/sheet";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "./ui/dropdown-menu";
import { useDarkMode } from "./DarkModeContext";
import { NotificationBell } from "./Notifications";

interface HeaderProps {
  onNavigate?: (view: 'profile' | 'account-settings' | 'billing' | 'help-support' | 'welcome' | 'dashboard' | 'my-trips' | 'explore' | 'history' | 'plan-trip' | 'subscription' | 'notifications' | 'partner-dashboard') => void;
  onSignOut?: () => void;
  currentView?: string;
}

interface NavItemProps {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  isActive: boolean;
  onClick: () => void;
  color: 'sky' | 'teal' | 'violet' | 'orange' | 'emerald';
}

const NavItem = ({ icon: Icon, label, isActive, onClick, color }: NavItemProps) => {
  const colorClasses = {
    sky: isActive 
      ? 'text-sky-600 dark:text-sky-400 bg-sky-50/80 dark:bg-sky-950/50' 
      : 'text-gray-600 dark:text-gray-400 hover:text-sky-600 dark:hover:text-sky-400 hover:bg-sky-50/50 dark:hover:bg-sky-950/30',
    teal: isActive 
      ? 'text-teal-600 dark:text-teal-400 bg-teal-50/80 dark:bg-teal-950/50' 
      : 'text-gray-600 dark:text-gray-400 hover:text-teal-600 dark:hover:text-teal-400 hover:bg-teal-50/50 dark:hover:bg-teal-950/30',
    violet: isActive 
      ? 'text-violet-600 dark:text-violet-400 bg-violet-50/80 dark:bg-violet-950/50' 
      : 'text-gray-600 dark:text-gray-400 hover:text-violet-600 dark:hover:text-violet-400 hover:bg-violet-50/50 dark:hover:bg-violet-950/30',
    orange: isActive 
      ? 'text-orange-600 dark:text-orange-400 bg-orange-50/80 dark:bg-orange-950/50' 
      : 'text-gray-600 dark:text-gray-400 hover:text-orange-600 dark:hover:text-orange-400 hover:bg-orange-50/50 dark:hover:bg-orange-950/30',
    emerald: isActive 
      ? 'text-emerald-600 dark:text-emerald-400 bg-emerald-50/80 dark:bg-emerald-950/50' 
      : 'text-gray-600 dark:text-gray-400 hover:text-emerald-600 dark:hover:text-emerald-400 hover:bg-emerald-50/50 dark:hover:bg-emerald-950/30'
  };

  return (
    <button
      onClick={onClick}
      className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl transition-all duration-200 font-medium text-sm ${colorClasses[color]} backdrop-blur-sm hover:scale-105 active:scale-95`}
    >
      <Icon className="w-4 h-4" />
      <span className="hidden lg:inline">{label}</span>
    </button>
  );
};

export function Header({ onNavigate, onSignOut, currentView }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { isDark, toggleDark } = useDarkMode();

  const handleNavigation = (view: 'profile' | 'account-settings' | 'billing' | 'help-support' | 'welcome' | 'dashboard' | 'my-trips' | 'explore' | 'history' | 'plan-trip' | 'subscription' | 'notifications' | 'partner-dashboard') => {
    if (onNavigate) {
      onNavigate(view);
    }
  };

  const navigationItems = [
    { name: "Dashboard", view: "dashboard", icon: Map },
    { name: "My Trips", view: "my-trips", icon: Luggage },
    { name: "Explore", view: "explore", icon: Compass },
    { name: "History", view: "history", icon: History },
    { name: "Plan Trip", view: "plan-trip", icon: MapPin },
    { name: "Subscription", view: "subscription", icon: Crown },
  ];

  return (
    <header className="bg-white/70 dark:bg-slate-950/70 backdrop-blur-xl border-b border-gray-200/30 dark:border-slate-800/30 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Logo and Dashboard */}
          <div className="flex items-center space-x-4 min-w-0 flex-shrink-0">
            <div className="flex-shrink-0">
              <NaviGoLogo variant="square" size={32} className="sm:w-8 sm:h-8 lg:w-10 lg:h-10" />
            </div>
            <div className="hidden sm:block">
              <span className="text-lg font-semibold text-gray-900 dark:text-white">Dashboard</span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-2 flex-1 justify-center max-w-2xl">
            <NavItem 
              icon={Luggage}
              label="My Trips"
              isActive={currentView === 'my-trips'}
              onClick={() => handleNavigation('my-trips')}
              color="teal"
            />
            <NavItem 
              icon={Luggage}
              label="Trips"
              isActive={currentView === 'my-trips'}
              onClick={() => handleNavigation('my-trips')}
              color="teal"
            />
            <NavItem 
              icon={Compass}
              label="Explore"
              isActive={currentView === 'explore'}
              onClick={() => handleNavigation('explore')}
              color="violet"
            />
            <NavItem 
              icon={History}
              label="History"
              isActive={currentView === 'history'}
              onClick={() => handleNavigation('history')}
              color="orange"
            />
            <NavItem 
              icon={MapPin}
              label="Plan"
              isActive={currentView === 'plan-trip'}
              onClick={() => handleNavigation('plan-trip')}
              color="emerald"
            />
            <NavItem 
              icon={Crown}
              label="Plans"
              isActive={currentView === 'subscription'}
              onClick={() => handleNavigation('subscription')}
              color="orange"
            />
          </nav>

          {/* Right side actions */}
          <div className="flex items-center space-x-2 md:space-x-3 min-w-0 flex-shrink-0 px-2">
            {/* Dark Mode Toggle - Hidden on mobile */}
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={toggleDark}
              className="hidden md:flex w-10 h-10 rounded-xl backdrop-blur-sm hover:bg-gray-100/80 dark:hover:bg-gray-800/80 transition-all duration-200 hover:scale-105"
            >
              {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </Button>
            
            {/* Notifications */}
            <div className="relative">
              <NotificationBell />
            </div>

            {/* User Profile - Hidden on mobile */}
            <div className="flex items-center space-x-2 md:space-x-3">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="hidden md:flex items-center space-x-3 p-2 rounded-xl hover:bg-gray-100/80 dark:hover:bg-gray-800/80 backdrop-blur-sm transition-all duration-200 hover:scale-105">
                    <div className="w-9 h-9 bg-gradient-to-br from-sky-500 to-teal-500 rounded-xl flex items-center justify-center shadow-lg">
                      <User className="w-4 h-4 text-white" />
                    </div>
                    <div className="hidden lg:block text-left min-w-0">
                      <div className="font-medium text-gray-900 dark:text-white text-sm truncate">Anna Mae</div>
                      <div className="flex items-center gap-1 mt-0.5">
                        <Badge className="bg-gradient-to-r from-orange-500 to-amber-500 text-white border-0 text-xs px-2 py-0.5 rounded-full transition-all duration-200 hover:scale-105 hidden xl:flex">
                          Premium
                        </Badge>
                      </div>
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-64 bg-white/95 dark:bg-slate-950/95 backdrop-blur-xl border border-gray-200/50 dark:border-slate-800/50 shadow-xl rounded-xl" align="end">
                  <div className="p-4 border-b border-gray-100 dark:border-slate-800">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-sky-500 to-teal-500 rounded-xl flex items-center justify-center shadow-lg">
                        <User className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <div className="font-medium text-gray-900 dark:text-white">Anna Mae</div>
                        <div className="flex items-center gap-1 mt-1">
                          <Badge className="bg-gradient-to-r from-orange-500 to-amber-500 text-white border-0 text-xs px-2 py-0.5 rounded-full">
                            Premium
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <DropdownMenuItem onClick={() => handleNavigation('profile')} className="py-3 transition-all duration-200 hover:scale-105">
                    <User className="w-4 h-4 mr-3" />
                    View Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleNavigation('subscription')} className="py-3 transition-all duration-200 hover:scale-105">
                    <Crown className="w-4 h-4 mr-3" />
                    Plans & Billing
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleNavigation('account-settings')} className="py-3 transition-all duration-200 hover:scale-105">
                    <Settings className="w-4 h-4 mr-3" />
                    Account Settings
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleNavigation('help-support')} className="py-3 transition-all duration-200 hover:scale-105">
                    <HelpCircle className="w-4 h-4 mr-3" />
                    Help & Support
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="text-red-600 py-3 transition-all duration-200 hover:scale-105" onClick={onSignOut}>
                    <LogOut className="w-4 h-4 mr-3" />
                    End Journey
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {/* Mobile Profile & Menu */}
            <div className="md:hidden flex items-center space-x-2">
              {/* Mobile Profile Button */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="w-10 h-10 rounded-xl p-0">
                    <div className="w-8 h-8 bg-gradient-to-br from-sky-500 to-teal-500 rounded-xl flex items-center justify-center shadow-lg">
                      <User className="w-4 h-4 text-white" />
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-64 bg-white/95 dark:bg-slate-950/95 backdrop-blur-xl border border-gray-200/50 dark:border-slate-800/50 shadow-xl" align="end">
                  <div className="p-3 border-b border-gray-100 dark:border-slate-800">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-sky-500 to-teal-500 rounded-xl flex items-center justify-center">
                        <User className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <div className="font-medium text-gray-900 dark:text-white">Anna Mae</div>
                        <Badge className="bg-gradient-to-r from-orange-500 to-amber-500 text-white border-0 text-xs px-2 py-0.5 rounded-full mt-1">
                          Premium
                        </Badge>
                      </div>
                    </div>
                  </div>
                  
                  <DropdownMenuItem onClick={() => handleNavigation('profile')} className="py-3 transition-all duration-200 hover:scale-105">
                    <User className="w-4 h-4 mr-3" />
                    View Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleNavigation('subscription')} className="py-3 transition-all duration-200 hover:scale-105">
                    <Crown className="w-4 h-4 mr-3" />
                    Plans & Billing
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleNavigation('account-settings')} className="py-3 transition-all duration-200 hover:scale-105">
                    <Settings className="w-4 h-4 mr-3" />
                    Account Settings
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleNavigation('help-support')} className="py-3 transition-all duration-200 hover:scale-105">
                    <HelpCircle className="w-4 h-4 mr-3" />
                    Help & Support
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="text-red-600 py-3 transition-all duration-200 hover:scale-105" onClick={onSignOut}>
                    <LogOut className="w-4 h-4 mr-3" />
                    End Journey
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              
              {/* Mobile Menu */}
              <Sheet open={isMenuOpen} onOpenChange={setIsMenuOpen}>
                <SheetTrigger asChild>
                  <Button className="w-10 h-10 rounded-xl" variant="ghost" size="sm">
                    <Menu className="w-5 h-5" />
                  </Button>
                </SheetTrigger>
              <SheetContent side="right" className="w-80 bg-white/95 dark:bg-slate-950/95 backdrop-blur-xl border-l border-gray-200/50 dark:border-slate-800/50">
                <SheetHeader>
                  <SheetTitle className="flex items-center gap-3 p-4 bg-gradient-to-r from-sky-50 to-teal-50 dark:from-sky-950/50 dark:to-teal-950/50 rounded-2xl">
                    <div className="w-12 h-12 bg-gradient-to-br from-sky-500 to-teal-500 rounded-xl flex items-center justify-center shadow-lg">
                      <Compass className="w-6 h-6 text-white" />
                    </div>
                    <div className="text-left">
                      <div className="font-semibold text-gray-900 dark:text-white">Navigation</div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">Quick menu access</div>
                    </div>
                  </SheetTitle>
                </SheetHeader>
                
                <nav className="mt-8 space-y-2">
                  {[
                    { name: "Dashboard", view: "dashboard", icon: Map, color: "sky" },
                    { name: "My Trips", view: "my-trips", icon: Luggage, color: "teal" },
                    { name: "Explore", view: "explore", icon: Compass, color: "violet" },
                    { name: "History", view: "history", icon: History, color: "orange" },
                    { name: "Plan Trip", view: "plan-trip", icon: MapPin, color: "emerald" },
                    { name: "Subscription", view: "subscription", icon: Crown, color: "orange" },
                  ].map((item) => {
                    const Icon = item.icon;
                    const isActive = currentView === item.view;
                    return (
                      <button
                        key={item.name}
                        className={`flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-200 w-full text-left font-medium ${
                          isActive 
                            ? 'bg-gradient-to-r from-sky-50 to-teal-50 dark:from-sky-950/50 dark:to-teal-950/50 text-sky-600 dark:text-sky-400 border border-sky-200/50 dark:border-sky-700/50 shadow-sm' 
                            : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800/50 hover:text-gray-900 dark:hover:text-white'
                        }`}
                        onClick={() => {
                          handleNavigation(item.view as any);
                          setIsMenuOpen(false);
                        }}
                      >
                        <Icon className="w-5 h-5" />
                        {item.name}
                      </button>
                    );
                  })}
                </nav>

                <div className="mt-8 pt-6 border-t border-gray-200/50 dark:border-slate-800/50">
                  <Button 
                    className="w-full bg-gradient-to-r from-sky-500 to-teal-500 hover:from-sky-600 hover:to-teal-600 text-white shadow-lg rounded-xl py-3 mb-4 transition-all duration-200 hover:scale-105"
                    onClick={() => {
                      handleNavigation('plan-trip');
                      setIsMenuOpen(false);
                    }}
                  >
                    <MapPin className="w-4 h-4 mr-2" />
                    Begin New Adventure
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}