import { useState } from "react";
import { HelpCircle, MessageCircle, Mail, Phone, Book, Search, ChevronRight, ArrowLeft, ExternalLink, Clock, User, CheckCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Textarea } from "./ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "./ui/accordion";

interface HelpSupportProps {
  onBack: () => void;
}

export function HelpSupport({ onBack }: HelpSupportProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [supportTicket, setSupportTicket] = useState({
    subject: "",
    category: "",
    priority: "medium",
    description: ""
  });

  const quickActions = [
    { title: "Getting Started Guide", description: "Learn the basics of NaviGo", icon: Book, category: "guide" },
    { title: "Contact Support", description: "Get help from our team", icon: MessageCircle, category: "contact" },
    { title: "Report a Bug", description: "Found an issue? Let us know", icon: Mail, category: "bug" },
    { title: "Feature Request", description: "Suggest new features", icon: HelpCircle, category: "feature" }
  ];

  const faqItems = [
    {
      category: "Getting Started",
      questions: [
        {
          question: "How do I create my first trip?",
          answer: "To create your first trip, click the 'Plan Trip' button in the top navigation or go to the Dashboard and select 'Create New Trip'. Enter your destination, dates, and preferences, and our AI will generate a personalized itinerary for you."
        },
        {
          question: "What's included in each subscription plan?",
          answer: "Our Free plan includes 3 trips per month with basic features. The Traveler plan ($10/month) includes 15 trips with group collaboration. Premium ($25/month) offers unlimited trips, AI recommendations, and priority support. Enterprise provides custom solutions for organizations."
        },
        {
          question: "How do I invite others to my trip?",
          answer: "In your trip details, click the 'Share' button and enter email addresses of people you want to invite. They'll receive an invitation to collaborate on your trip planning, view the itinerary, and suggest changes."
        }
      ]
    },
    {
      category: "Account & Billing",
      questions: [
        {
          question: "How do I change my subscription plan?",
          answer: "Go to Billing & Plans in your account settings. You can upgrade or downgrade your plan at any time. Changes take effect immediately, and you'll be prorated for any differences."
        },
        {
          question: "Can I cancel my subscription anytime?",
          answer: "Yes, you can cancel your subscription at any time from the Billing & Plans section. Your access will continue until the end of your current billing period."
        },
        {
          question: "What payment methods do you accept?",
          answer: "We accept all major credit cards (Visa, Mastercard, American Express), PayPal, and bank transfers for enterprise accounts."
        }
      ]
    },
    {
      category: "Features & Usage",
      questions: [
        {
          question: "How accurate are the AI recommendations?",
          answer: "Our AI uses real-time data from multiple sources including weather, local events, and user reviews to provide highly accurate recommendations. The system learns from your preferences to improve suggestions over time."
        },
        {
          question: "Can I use NaviGo offline?",
          answer: "Yes, with Traveler and Premium plans, you can download your itineraries for offline access. This includes maps, contact information, and important details for your trip."
        },
        {
          question: "How do I export my trip itinerary?",
          answer: "In your trip details, click the 'Export' button to download your itinerary as a PDF or sync it with your calendar app. You can also share it via email or print it directly."
        }
      ]
    }
  ];

  const supportChannels = [
    {
      type: "Email Support",
      description: "Get help via email within 24 hours",
      contact: "support@navigo.com",
      hours: "24/7",
      responseTime: "Within 24 hours",
      icon: Mail
    },
    {
      type: "Live Chat",
      description: "Instant help during business hours",
      contact: "Chat now",
      hours: "Mon-Fri 9AM-6PM PST",
      responseTime: "Immediate",
      icon: MessageCircle
    },
    {
      type: "Phone Support",
      description: "Priority phone support for Premium users",
      contact: "+1 (555) 123-4567",
      hours: "Mon-Fri 9AM-6PM PST",
      responseTime: "Immediate",
      icon: Phone
    }
  ];

  const recentTickets = [
    {
      id: "TK-2024-001",
      subject: "Unable to export itinerary",
      status: "resolved",
      priority: "medium",
      created: "Dec 10, 2024",
      updated: "Dec 12, 2024"
    },
    {
      id: "TK-2024-002",
      subject: "Group collaboration not working",
      status: "in_progress",
      priority: "high",
      created: "Dec 8, 2024",
      updated: "Dec 14, 2024"
    },
    {
      id: "TK-2024-003",
      subject: "Feature request: Dark mode",
      status: "open",
      priority: "low",
      created: "Dec 5, 2024",
      updated: "Dec 5, 2024"
    }
  ];

  const guides = [
    {
      title: "Complete User Guide",
      description: "Comprehensive guide covering all NaviGo features",
      readTime: "15 min read",
      category: "Getting Started"
    },
    {
      title: "Advanced Trip Planning",
      description: "Tips and tricks for creating perfect itineraries",
      readTime: "10 min read",
      category: "Features"
    },
    {
      title: "Team Collaboration Guide",
      description: "How to effectively plan trips with your team",
      readTime: "8 min read",
      category: "Collaboration"
    },
    {
      title: "Mobile App Tutorial",
      description: "Getting the most out of NaviGo on mobile",
      readTime: "5 min read",
      category: "Mobile"
    }
  ];

  const filteredFAQ = faqItems.map(category => ({
    ...category,
    questions: category.questions.filter(item =>
      searchQuery === "" || 
      item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.answer.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })).filter(category => category.questions.length > 0);

  const handleSubmitTicket = () => {
    // Handle ticket submission
    console.log("Submitting ticket:", supportTicket);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <div>
          <h2 className="text-2xl font-bold">Help & Support</h2>
          <p className="text-gray-600">Get help and find answers to your questions</p>
        </div>
      </div>

      <Tabs defaultValue="help" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="help">Help Center</TabsTrigger>
          <TabsTrigger value="contact">Contact Us</TabsTrigger>
          <TabsTrigger value="tickets">My Tickets</TabsTrigger>
          <TabsTrigger value="guides">Guides</TabsTrigger>
        </TabsList>

        <TabsContent value="help" className="space-y-6">
          {/* Search Bar */}
          <Card>
            <CardContent className="pt-6">
              <div className="relative max-w-md mx-auto">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search for help..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action, index) => (
              <Card key={index} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex flex-col items-center text-center space-y-2">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <action.icon className="w-6 h-6 text-blue-600" />
                    </div>
                    <h3 className="font-medium">{action.title}</h3>
                    <p className="text-sm text-gray-600">{action.description}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* FAQ Section */}
          <Card>
            <CardHeader>
              <CardTitle>Frequently Asked Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {filteredFAQ.map((category, categoryIndex) => (
                  <div key={categoryIndex}>
                    <h4 className="font-medium text-lg mb-3">{category.category}</h4>
                    <Accordion type="single" collapsible className="space-y-2">
                      {category.questions.map((faq, faqIndex) => (
                        <AccordionItem key={faqIndex} value={`${categoryIndex}-${faqIndex}`} className="border rounded-lg px-4">
                          <AccordionTrigger className="text-left">
                            {faq.question}
                          </AccordionTrigger>
                          <AccordionContent className="text-gray-600">
                            {faq.answer}
                          </AccordionContent>
                        </AccordionItem>
                      ))}
                    </Accordion>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="contact" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Support Channels */}
            <Card>
              <CardHeader>
                <CardTitle>Contact Support</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {supportChannels.map((channel, index) => (
                  <div key={index} className="flex items-start gap-4 p-4 border rounded-lg">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <channel.icon className="w-5 h-5 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium">{channel.type}</h4>
                      <p className="text-sm text-gray-600 mb-2">{channel.description}</p>
                      <div className="space-y-1 text-xs text-gray-500">
                        <p>Hours: {channel.hours}</p>
                        <p>Response time: {channel.responseTime}</p>
                      </div>
                    </div>
                    <Button size="sm" variant="outline">
                      {channel.type === "Live Chat" ? "Start Chat" : "Contact"}
                    </Button>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Contact Form */}
            <Card>
              <CardHeader>
                <CardTitle>Send us a Message</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="subject">Subject</Label>
                  <Input
                    id="subject"
                    value={supportTicket.subject}
                    onChange={(e) => setSupportTicket({...supportTicket, subject: e.target.value})}
                    placeholder="Brief description of your issue"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Category</Label>
                    <Select value={supportTicket.category} onValueChange={(value) => setSupportTicket({...supportTicket, category: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="technical">Technical Issue</SelectItem>
                        <SelectItem value="billing">Billing Question</SelectItem>
                        <SelectItem value="feature">Feature Request</SelectItem>
                        <SelectItem value="bug">Bug Report</SelectItem>
                        <SelectItem value="account">Account Issue</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Priority</Label>
                    <Select value={supportTicket.priority} onValueChange={(value) => setSupportTicket({...supportTicket, priority: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={supportTicket.description}
                    onChange={(e) => setSupportTicket({...supportTicket, description: e.target.value})}
                    placeholder="Please provide detailed information about your issue..."
                    rows={5}
                  />
                </div>
                <Button className="w-full" onClick={handleSubmitTicket}>
                  Submit Ticket
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="tickets" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <HelpCircle className="w-5 h-5" />
                My Support Tickets
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentTickets.map((ticket) => (
                  <div key={ticket.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="flex flex-col">
                        <span className="font-medium">{ticket.subject}</span>
                        <span className="text-sm text-gray-600">Ticket #{ticket.id}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right text-sm">
                        <p className="text-gray-600">Created: {ticket.created}</p>
                        <p className="text-gray-600">Updated: {ticket.updated}</p>
                      </div>
                      <div className="flex flex-col items-center gap-2">
                        <Badge 
                          variant="secondary"
                          className={
                            ticket.status === 'resolved' ? 'bg-green-100 text-green-800' :
                            ticket.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                            'bg-gray-100 text-gray-800'
                          }
                        >
                          {ticket.status === 'resolved' ? 'Resolved' :
                           ticket.status === 'in_progress' ? 'In Progress' : 'Open'}
                        </Badge>
                        <Badge 
                          variant="outline"
                          className={
                            ticket.priority === 'high' ? 'border-red-500 text-red-700' :
                            ticket.priority === 'medium' ? 'border-orange-500 text-orange-700' :
                            'border-gray-500 text-gray-700'
                          }
                        >
                          {ticket.priority} priority
                        </Badge>
                      </div>
                      <Button variant="outline" size="sm">
                        View Details
                        <ChevronRight className="w-4 h-4 ml-1" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="guides" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {guides.map((guide, index) => (
              <Card key={index} className="cursor-pointer hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="space-y-3">
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <h3 className="font-medium">{guide.title}</h3>
                        <p className="text-sm text-gray-600">{guide.description}</p>
                      </div>
                      <ExternalLink className="w-4 h-4 text-gray-400" />
                    </div>
                    <div className="flex items-center justify-between">
                      <Badge variant="outline">{guide.category}</Badge>
                      <div className="flex items-center gap-1 text-sm text-gray-500">
                        <Clock className="w-4 h-4" />
                        {guide.readTime}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Additional Resources */}
          <Card>
            <CardHeader>
              <CardTitle>Additional Resources</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4">
                  <Book className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  <h4 className="font-medium">API Documentation</h4>
                  <p className="text-sm text-gray-600 mb-2">Technical docs for developers</p>
                  <Button variant="outline" size="sm">View Docs</Button>
                </div>
                <div className="text-center p-4">
                  <MessageCircle className="w-8 h-8 text-green-600 mx-auto mb-2" />
                  <h4 className="font-medium">Community Forum</h4>
                  <p className="text-sm text-gray-600 mb-2">Connect with other users</p>
                  <Button variant="outline" size="sm">Join Forum</Button>
                </div>
                <div className="text-center p-4">
                  <HelpCircle className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                  <h4 className="font-medium">Video Tutorials</h4>
                  <p className="text-sm text-gray-600 mb-2">Step-by-step video guides</p>
                  <Button variant="outline" size="sm">Watch Videos</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}