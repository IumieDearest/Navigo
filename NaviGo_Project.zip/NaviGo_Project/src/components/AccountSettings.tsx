import { useState } from "react";
import { Settings, Shield, Bell, Globe, Key, Smartphone, Mail, Lock, Eye, EyeOff, ArrowLeft } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Switch } from "./ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Separator } from "./ui/separator";

interface AccountSettingsProps {
  onBack: () => void;
}

export function AccountSettings({ onBack }: AccountSettingsProps) {
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [security, setSecurity] = useState({
    twoFactorAuth: true,
    loginAlerts: true,
    sessionTimeout: "30",
    passwordExpiry: false,
    deviceTrust: true
  });

  const [privacy, setPrivacy] = useState({
    dataCollection: false,
    analytics: true,
    marketing: false,
    profileVisibility: "private"
  });

  const [notifications, setNotifications] = useState({
    securityAlerts: true,
    accountUpdates: true,
    systemMaintenance: false,
    featureUpdates: true
  });

  const activeSessions = [
    { device: "MacBook Pro", location: "San Francisco, CA", lastActive: "Active now", current: true },
    { device: "iPhone 15", location: "San Francisco, CA", lastActive: "2 hours ago", current: false },
    { device: "iPad Air", location: "Los Angeles, CA", lastActive: "1 day ago", current: false }
  ];

  const loginHistory = [
    { date: "Dec 15, 2024", time: "2:30 PM", location: "San Francisco, CA", device: "MacBook Pro", status: "Success" },
    { date: "Dec 14, 2024", time: "8:45 AM", location: "San Francisco, CA", device: "iPhone 15", status: "Success" },
    { date: "Dec 13, 2024", time: "6:20 PM", location: "Los Angeles, CA", device: "iPad Air", status: "Success" },
    { date: "Dec 12, 2024", time: "11:15 AM", location: "Unknown", device: "Chrome Browser", status: "Failed" }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <div>
          <h2 className="text-2xl font-bold">Account Settings</h2>
          <p className="text-gray-600">Manage your account security and privacy settings</p>
        </div>
      </div>

      <Tabs defaultValue="security" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="privacy">Privacy</TabsTrigger>
          <TabsTrigger value="sessions">Sessions</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
        </TabsList>

        <TabsContent value="security" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Password Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="w-5 h-5" />
                  Password Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="currentPassword">Current Password</Label>
                    <div className="relative">
                      <Input
                        id="currentPassword"
                        type={showCurrentPassword ? "text" : "password"}
                        placeholder="Enter current password"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                      >
                        {showCurrentPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="newPassword">New Password</Label>
                    <div className="relative">
                      <Input
                        id="newPassword"
                        type={showNewPassword ? "text" : "password"}
                        placeholder="Enter new password"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                      >
                        {showNewPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="confirmPassword">Confirm New Password</Label>
                    <div className="relative">
                      <Input
                        id="confirmPassword"
                        type={showConfirmPassword ? "text" : "password"}
                        placeholder="Confirm new password"
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                        onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      >
                        {showConfirmPassword ? (
                          <EyeOff className="h-4 w-4" />
                        ) : (
                          <Eye className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                  <Button className="w-full">Update Password</Button>
                </div>
                <Separator />
                <div className="text-sm text-gray-600">
                  <p className="font-medium mb-2">Password requirements:</p>
                  <ul className="space-y-1 text-xs">
                    <li>• At least 8 characters long</li>
                    <li>• Contains uppercase and lowercase letters</li>
                    <li>• Contains at least one number</li>
                    <li>• Contains at least one special character</li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            {/* Two-Factor Authentication */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Two-Factor Authentication
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Authenticator App</p>
                    <p className="text-sm text-gray-600">Use an authenticator app for login verification</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300 border-green-200 dark:border-green-800">✓ Active</Badge>
                    <Switch 
                      checked={security.twoFactorAuth}
                      onCheckedChange={(checked) => setSecurity({...security, twoFactorAuth: checked})}
                      className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                    />
                  </div>
                </div>
                <Separator />
                <div className="space-y-3">
                  <p className="font-medium">Backup Codes</p>
                  <p className="text-sm text-gray-600">Use these codes if you lose access to your authenticator app</p>
                  <Button variant="outline" size="sm">View Backup Codes</Button>
                </div>
                <Separator />
                <div className="space-y-3">
                  <p className="font-medium">Recovery Options</p>
                  <p className="text-sm text-gray-600">Email: anna.mae.regis@email.com</p>
                  <Button variant="outline" size="sm">Update Recovery Email</Button>
                </div>
              </CardContent>
            </Card>

            {/* Security Preferences */}
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lock className="w-5 h-5" />
                  Security Preferences
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Login Alerts</p>
                        <p className="text-sm text-gray-600">Get notified of new device logins</p>
                      </div>
                      <Switch 
                        checked={security.loginAlerts}
                        onCheckedChange={(checked) => setSecurity({...security, loginAlerts: checked})}
                        className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Password Expiry</p>
                        <p className="text-sm text-gray-600">Require password change every 90 days</p>
                      </div>
                      <Switch 
                        checked={security.passwordExpiry}
                        onCheckedChange={(checked) => setSecurity({...security, passwordExpiry: checked})}
                        className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">Device Trust</p>
                        <p className="text-sm text-gray-600">Remember trusted devices for 30 days</p>
                      </div>
                      <Switch 
                        checked={security.deviceTrust}
                        onCheckedChange={(checked) => setSecurity({...security, deviceTrust: checked})}
                        className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                      />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <Label>Session Timeout</Label>
                      <Select value={security.sessionTimeout} onValueChange={(value) => setSecurity({...security, sessionTimeout: value})}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="15">15 minutes</SelectItem>
                          <SelectItem value="30">30 minutes</SelectItem>
                          <SelectItem value="60">1 hour</SelectItem>
                          <SelectItem value="240">4 hours</SelectItem>
                          <SelectItem value="never">Never</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="privacy" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                Privacy Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h4 className="font-medium mb-4">Data Collection</h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Anonymous Usage Data</p>
                      <p className="text-sm text-gray-600">Help improve NaviGo by sharing anonymous usage statistics</p>
                    </div>
                    <Switch 
                      checked={privacy.dataCollection}
                      onCheckedChange={(checked) => setPrivacy({...privacy, dataCollection: checked})}
                      className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Analytics & Performance</p>
                      <p className="text-sm text-gray-600">Allow collection of performance and analytics data</p>
                    </div>
                    <Switch 
                      checked={privacy.analytics}
                      onCheckedChange={(checked) => setPrivacy({...privacy, analytics: checked})}
                      className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Marketing Communications</p>
                      <p className="text-sm text-gray-600">Receive personalized offers and recommendations</p>
                    </div>
                    <Switch 
                      checked={privacy.marketing}
                      onCheckedChange={(checked) => setPrivacy({...privacy, marketing: checked})}
                      className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                    />
                  </div>
                </div>
              </div>
              <Separator />
              <div>
                <h4 className="font-medium mb-4">Profile Visibility</h4>
                <div>
                  <Label>Who can see your profile</Label>
                  <Select value={privacy.profileVisibility} onValueChange={(value) => setPrivacy({...privacy, profileVisibility: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="private">Only me</SelectItem>
                      <SelectItem value="friends">Friends only</SelectItem>
                      <SelectItem value="public">Public</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <Separator />
              <div>
                <h4 className="font-medium mb-4">Data Management</h4>
                <div className="space-y-3">
                  <Button variant="outline">Download My Data</Button>
                  <Button variant="outline">Delete Account</Button>
                  <p className="text-xs text-gray-500">
                    Account deletion is permanent and cannot be undone. All your data will be permanently removed.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sessions" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Smartphone className="w-5 h-5" />
                  Active Sessions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {activeSessions.map((session, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          <Smartphone className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-medium flex items-center gap-2">
                            {session.device}
                            {session.current && <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300 border-green-200 dark:border-green-800">✓ Current</Badge>}
                          </p>
                          <p className="text-sm text-gray-600">{session.location}</p>
                          <p className="text-xs text-gray-500">{session.lastActive}</p>
                        </div>
                      </div>
                      {!session.current && (
                        <Button variant="outline" size="sm">
                          Revoke
                        </Button>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Login History
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-80 overflow-y-auto">
                  {loginHistory.map((login, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">{login.device}</p>
                        <p className="text-sm text-gray-600">{login.location}</p>
                        <p className="text-xs text-gray-500">{login.date} at {login.time}</p>
                      </div>
                      <Badge 
                        variant="secondary" 
                        className={login.status === 'Success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}
                      >
                        {login.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Account Notifications
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h4 className="font-medium mb-4">Security & Account</h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Security Alerts</p>
                      <p className="text-sm text-gray-600">Notifications about security-related events</p>
                    </div>
                    <Switch 
                      checked={notifications.securityAlerts}
                      onCheckedChange={(checked) => setNotifications({...notifications, securityAlerts: checked})}
                      className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Account Updates</p>
                      <p className="text-sm text-gray-600">Important changes to your account</p>
                    </div>
                    <Switch 
                      checked={notifications.accountUpdates}
                      onCheckedChange={(checked) => setNotifications({...notifications, accountUpdates: checked})}
                      className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">System Maintenance</p>
                      <p className="text-sm text-gray-600">Notifications about scheduled maintenance</p>
                    </div>
                    <Switch 
                      checked={notifications.systemMaintenance}
                      onCheckedChange={(checked) => setNotifications({...notifications, systemMaintenance: checked})}
                      className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Feature Updates</p>
                      <p className="text-sm text-gray-600">Learn about new features and improvements</p>
                    </div>
                    <Switch 
                      checked={notifications.featureUpdates}
                      onCheckedChange={(checked) => setNotifications({...notifications, featureUpdates: checked})}
                      className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}