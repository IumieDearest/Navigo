import naviGoImage from 'figma:asset/79bd977b3889c1a721eb86afad67ab5e9ff98efe.png';

interface NaviGoLogoProps {
  variant?: 'circular' | 'square' | 'auto';
  className?: string;
  size?: number;
}

export function NaviGoLogo({ 
  variant = 'auto', 
  className = "", 
  size 
}: NaviGoLogoProps) {
  // Determine the appropriate size based on variant and context
  const defaultSize = variant === 'square' || 
    (variant === 'auto' && (className.includes('sidebar') || className.includes('dashboard'))) 
    ? 40 : 120;
  
  const logoSize = size || defaultSize;
  
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <img 
        src={naviGoImage} 
        alt="NaviGo - Astria Travels" 
        className="object-contain"
        style={{ 
          width: `${logoSize}px`, 
          height: 'auto'
        }}
      />
    </div>
  );
}

// Export legacy components for backward compatibility if needed
export { NaviGoLogo as NaviGoLogoCircular, NaviGoLogo as NaviGoLogoSquare };