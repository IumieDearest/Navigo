import { useState } from "react";
import { Bell, X, Check, AlertCircle, Info, Plane, Hotel, CreditCard, Calendar } from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "./ui/sheet";

// Helper functions shared between components
const getIcon = (type: string) => {
  switch (type) {
    case "booking": return Plane;
    case "price-alert": return AlertCircle;
    case "reminder": return Calendar;
    case "update": return Info;
    case "payment": return CreditCard;
    default: return Bell;
  }
};

const getIconColor = (type: string) => {
  switch (type) {
    case "booking": return "text-blue-500";
    case "price-alert": return "text-green-500";
    case "reminder": return "text-orange-500";
    case "update": return "text-purple-500";
    case "payment": return "text-red-500";
    default: return "text-gray-500";
  }
};

interface Notification {
  id: string;
  type: "booking" | "price-alert" | "reminder" | "update" | "payment";
  title: string;
  message: string;
  timestamp: string;
  isRead: boolean;
  actionRequired?: boolean;
}

interface NotificationsProps {
  onBack?: () => void;
}

export function Notifications({ onBack }: NotificationsProps) {
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: "1",
      type: "booking",
      title: "Flight Booking Confirmed",
      message: "Your flight from NYC to Paris on March 15th has been confirmed. Check-in opens 24 hours before departure.",
      timestamp: "2 hours ago",
      isRead: false,
      actionRequired: false
    },
    {
      id: "2",
      type: "price-alert",
      title: "Price Drop Alert",
      message: "The price for your saved Tokyo trip has dropped by $150! Book now to save.",
      timestamp: "1 day ago",
      isRead: false,
      actionRequired: true
    },
    {
      id: "3",
      type: "reminder",
      title: "Passport Expiration Reminder",
      message: "Your passport expires in 6 months. Consider renewing before your international travel.",
      timestamp: "3 days ago",
      isRead: true,
      actionRequired: true
    },
    {
      id: "4",
      type: "update",
      title: "Flight Status Update",
      message: "Your flight UA123 departure time has been updated to 2:30 PM (30 minutes delay).",
      timestamp: "1 week ago",
      isRead: true,
      actionRequired: false
    },
    {
      id: "5",
      type: "payment",
      title: "Payment Reminder",
      message: "Payment for your London hotel booking is due in 2 days. Complete payment to secure your reservation.",
      timestamp: "1 week ago",
      isRead: true,
      actionRequired: true
    }
  ]);

  const markAsRead = (id: string) => {
    setNotifications(notifications.map(notif => 
      notif.id === id ? { ...notif, isRead: true } : notif
    ));
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map(notif => ({ ...notif, isRead: true })));
  };

  const removeNotification = (id: string) => {
    setNotifications(notifications.filter(notif => notif.id !== id));
  };



  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Bell className="w-8 h-8 text-blue-500" />
              <div>
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Notifications</h1>
                <p className="text-gray-600 dark:text-gray-400 mt-1">
                  Stay updated with your travel plans
                  {unreadCount > 0 && (
                    <Badge className="ml-2 bg-red-500 text-white">
                      {unreadCount} new
                    </Badge>
                  )}
                </p>
              </div>
            </div>
            <div className="flex gap-2">
              {unreadCount > 0 && (
                <Button variant="outline" onClick={markAllAsRead}>
                  <Check className="w-4 h-4 mr-2" />
                  Mark all as read
                </Button>
              )}
              {onBack && (
                <Button variant="outline" onClick={onBack}>
                  Back to Dashboard
                </Button>
              )}
            </div>
          </div>
        </div>

        {/* Notifications List */}
        <div className="space-y-4">
          {notifications.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <Bell className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No notifications</h3>
                <p className="text-gray-600 dark:text-gray-400">You're all caught up! Check back later for updates.</p>
              </CardContent>
            </Card>
          ) : (
            notifications.map((notification) => {
              const Icon = getIcon(notification.type);
              const iconColor = getIconColor(notification.type);
              
              return (
                <Card 
                  key={notification.id} 
                  className={`transition-all hover:shadow-md ${
                    !notification.isRead ? 'bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-800' : ''
                  }`}
                >
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className={`p-2 rounded-full bg-gray-100 dark:bg-gray-800 ${iconColor}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1">
                            <h3 className="font-medium text-gray-900 dark:text-white flex items-center gap-2">
                              {notification.title}
                              {!notification.isRead && (
                                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                              )}
                              {notification.actionRequired && (
                                <Badge variant="outline" className="text-xs">
                                  Action Required
                                </Badge>
                              )}
                            </h3>
                            <p className="text-gray-600 dark:text-gray-400 mt-1 text-sm">
                              {notification.message}
                            </p>
                            <p className="text-xs text-gray-500 dark:text-gray-500 mt-2">
                              {notification.timestamp}
                            </p>
                          </div>
                          
                          <div className="flex items-center gap-1">
                            {!notification.isRead && (
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                onClick={() => markAsRead(notification.id)}
                                className="text-blue-600 hover:text-blue-700"
                              >
                                <Check className="w-4 h-4" />
                              </Button>
                            )}
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              onClick={() => removeNotification(notification.id)}
                              className="text-gray-400 hover:text-gray-600"
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                        
                        {notification.actionRequired && (
                          <div className="mt-3 flex gap-2">
                            <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                              Take Action
                            </Button>
                            <Button variant="outline" size="sm">
                              View Details
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
}

// Notification Bell Component for Header
export function NotificationBell() {
  const [notifications] = useState<Notification[]>([
    {
      id: "1",
      type: "booking",
      title: "Flight Booking Confirmed",
      message: "Your flight from NYC to Paris on March 15th has been confirmed.",
      timestamp: "2 hours ago",
      isRead: false
    },
    {
      id: "2",
      type: "price-alert",
      title: "Price Drop Alert",
      message: "The price for your saved Tokyo trip has dropped by $150!",
      timestamp: "1 day ago",
      isRead: false
    }
  ]);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="ghost" size="sm" className="relative">
          <Bell className="w-5 h-5 text-gray-600 dark:text-gray-400" />
          {unreadCount > 0 && (
            <Badge className="absolute -top-1 -right-1 w-5 h-5 p-0 flex items-center justify-center text-xs bg-red-500 text-white">
              {unreadCount}
            </Badge>
          )}
        </Button>
      </SheetTrigger>
      <SheetContent className="w-96">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5" />
            Notifications
            {unreadCount > 0 && (
              <Badge className="bg-red-500 text-white">
                {unreadCount}
              </Badge>
            )}
          </SheetTitle>
        </SheetHeader>
        
        <div className="mt-6 space-y-4">
          {notifications.slice(0, 5).map((notification) => {
            const Icon = getIcon(notification.type);
            const iconColor = getIconColor(notification.type);
            
            return (
              <div key={notification.id} className="border rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <div className={`p-1 rounded-full ${iconColor}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-sm flex items-center gap-2">
                      {notification.title}
                      {!notification.isRead && (
                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                      )}
                    </h4>
                    <p className="text-xs text-gray-600 dark:text-gray-400 mt-1 line-clamp-2">
                      {notification.message}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      {notification.timestamp}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
          
          <Separator />
          <Button variant="outline" className="w-full">
            View All Notifications
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}