import { useState } from "react";
import { MapPin, Star, Users, Calendar, DollarSign, TrendingUp, Compass, Mountain, Waves, Building, Camera, Coffee, Search, Filter, Heart, Share2 } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function Explore() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [priceRange, setPriceRange] = useState("all");

  const trendingDestinations = [
    {
      id: 1,
      name: "Santorini, Greece",
      country: "Greece",
      image: "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?w=400",
      rating: 4.8,
      reviews: 2420,
      priceRange: "$$$",
      category: "romantic",
      highlights: ["Sunset Views", "White Architecture", "Wine Tasting"],
      bestTime: "Apr - Oct",
      duration: "5-7 days",
      popularActivities: ["Photography", "Beach", "Culture"],
      trending: true,
      budget: { min: 150, max: 300 }
    },
    {
      id: 2,
      name: "Kyoto, Japan",
      country: "Japan",
      image: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?w=400",
      rating: 4.9,
      reviews: 3150,
      priceRange: "$$",
      category: "culture",
      highlights: ["Ancient Temples", "Cherry Blossoms", "Traditional Cuisine"],
      bestTime: "Mar - May, Sep - Nov",
      duration: "4-6 days",
      popularActivities: ["Temples", "Gardens", "Food"],
      trending: true,
      budget: { min: 100, max: 200 }
    },
    {
      id: 3,
      name: "Patagonia, Chile",
      country: "Chile",
      image: "https://images.unsplash.com/photo-1544735716-392fe2489ffa?w=400",
      rating: 4.7,
      reviews: 890,
      priceRange: "$$$",
      category: "adventure",
      highlights: ["Hiking Trails", "Glacier Views", "Wildlife"],
      bestTime: "Dec - Mar",
      duration: "8-12 days",
      popularActivities: ["Hiking", "Photography", "Nature"],
      trending: false,
      budget: { min: 200, max: 400 }
    },
    {
      id: 4,
      name: "Dubai, UAE",
      country: "UAE",
      image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=400",
      rating: 4.6,
      reviews: 1820,
      priceRange: "$$$$",
      category: "luxury",
      highlights: ["Modern Architecture", "Luxury Shopping", "Desert Safari"],
      bestTime: "Nov - Mar",
      duration: "4-5 days",
      popularActivities: ["Shopping", "Architecture", "Desert"],
      trending: true,
      budget: { min: 250, max: 500 }
    },
    {
      id: 5,
      name: "Bali, Indonesia",
      country: "Indonesia",
      image: "https://images.unsplash.com/photo-1537953773345-d172ccf13cf1?w=400",
      rating: 4.5,
      reviews: 2890,
      priceRange: "$",
      category: "beach",
      highlights: ["Beach Resorts", "Yoga Retreats", "Rice Terraces"],
      bestTime: "Apr - Oct",
      duration: "7-10 days",
      popularActivities: ["Beach", "Wellness", "Culture"],
      trending: true,
      budget: { min: 50, max: 150 }
    },
    {
      id: 6,
      name: "Reykjavik, Iceland",
      country: "Iceland",
      image: "https://images.unsplash.com/photo-1539650116574-75c0c6d00903?w=400",
      rating: 4.8,
      reviews: 1240,
      priceRange: "$$$$",
      category: "nature",
      highlights: ["Northern Lights", "Blue Lagoon", "Waterfalls"],
      bestTime: "Jun - Aug, Dec - Mar",
      duration: "5-7 days",
      popularActivities: ["Nature", "Photography", "Hot Springs"],
      trending: true,
      budget: { min: 200, max: 350 }
    }
  ];

  const categories = [
    { id: "all", name: "All Destinations", icon: Compass },
    { id: "beach", name: "Beach & Islands", icon: Waves },
    { id: "culture", name: "Culture & History", icon: Building },
    { id: "adventure", name: "Adventure", icon: Mountain },
    { id: "romantic", name: "Romantic", icon: Heart },
    { id: "luxury", name: "Luxury", icon: Star },
    { id: "nature", name: "Nature", icon: Mountain }
  ];

  const featuredExperiences = [
    {
      id: 1,
      name: "Northern Lights Photography Tour",
      location: "Iceland",
      image: "https://images.unsplash.com/photo-1483347756197-71ef80e95f73?w=400",
      price: 299,
      duration: "3 days",
      rating: 4.9,
      category: "Photography"
    },
    {
      id: 2,
      name: "Culinary Street Food Adventure",
      location: "Bangkok, Thailand",
      image: "https://images.unsplash.com/photo-1563379091339-03246963d7d9?w=400",
      price: 89,
      duration: "1 day",
      rating: 4.7,
      category: "Food & Drink"
    },
    {
      id: 3,
      name: "Safari Wildlife Experience",
      location: "Kenya",
      image: "https://images.unsplash.com/photo-1516426122078-c23e76319801?w=400",
      price: 1299,
      duration: "7 days",
      rating: 4.8,
      category: "Wildlife"
    }
  ];

  const filteredDestinations = trendingDestinations.filter(destination => {
    const matchesSearch = destination.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         destination.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         destination.highlights.some(h => h.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = selectedCategory === "all" || destination.category === selectedCategory;
    const matchesPrice = priceRange === "all" || 
                        (priceRange === "budget" && destination.budget.max <= 150) ||
                        (priceRange === "mid" && destination.budget.min <= 200 && destination.budget.max >= 100) ||
                        (priceRange === "luxury" && destination.budget.min >= 200);
    return matchesSearch && matchesCategory && matchesPrice;
  });

  const DestinationCard = ({ destination }: { destination: typeof trendingDestinations[0] }) => (
    <Card className="overflow-hidden hover:shadow-lg transition-all duration-300 group">
      <div className="relative">
        <ImageWithFallback
          src={destination.image}
          alt={destination.name}
          className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
        />
        {destination.trending && (
          <Badge className="absolute top-3 left-3 bg-red-500 text-white">
            <TrendingUp className="w-3 h-3 mr-1" />
            Trending
          </Badge>
        )}
        <div className="absolute top-3 right-3 flex space-x-2">
          <Button size="sm" variant="secondary" className="bg-white/80 backdrop-blur-sm p-2">
            <Heart className="w-4 h-4" />
          </Button>
          <Button size="sm" variant="secondary" className="bg-white/80 backdrop-blur-sm p-2">
            <Share2 className="w-4 h-4" />
          </Button>
        </div>
        <div className="absolute bottom-3 left-3">
          <span className="text-white text-sm font-medium bg-black/50 px-2 py-1 rounded">
            {destination.priceRange}
          </span>
        </div>
      </div>
      
      <CardContent className="p-4">
        <div className="mb-3">
          <h3 className="font-semibold text-lg mb-1">{destination.name}</h3>
          <p className="text-gray-600 text-sm flex items-center gap-1">
            <MapPin className="w-3 h-3" />
            {destination.country}
          </p>
        </div>

        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
            <span className="font-medium">{destination.rating}</span>
            <span className="text-gray-500 text-sm">({destination.reviews})</span>
          </div>
          <span className="text-sm text-gray-600">{destination.duration}</span>
        </div>

        <div className="mb-3">
          <p className="text-sm text-gray-500 mb-2">Highlights</p>
          <div className="flex flex-wrap gap-1">
            {destination.highlights.slice(0, 2).map((highlight, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                {highlight}
              </Badge>
            ))}
            {destination.highlights.length > 2 && (
              <Badge variant="outline" className="text-xs">
                +{destination.highlights.length - 2} more
              </Badge>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 mb-4 text-sm">
          <div>
            <p className="text-gray-500">Best Time</p>
            <p className="font-medium">{destination.bestTime}</p>
          </div>
          <div>
            <p className="text-gray-500">Budget/day</p>
            <p className="font-medium">${destination.budget.min}-${destination.budget.max}</p>
          </div>
        </div>

        <div className="flex space-x-2">
          <Button size="sm" className="flex-1">
            Plan Trip
          </Button>
          <Button size="sm" variant="outline">
            Learn More
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold mb-2">Explore Destinations</h2>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Discover amazing places around the world. Get personalized recommendations based on your preferences and travel style.
        </p>
      </div>

      {/* Search and Filters */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search destinations, countries, or activities..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10"
              />
            </div>
          </div>
          <Select value={priceRange} onValueChange={setPriceRange}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="Price Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Budgets</SelectItem>
              <SelectItem value="budget">Budget ($0-150/day)</SelectItem>
              <SelectItem value="mid">Mid-range ($100-250/day)</SelectItem>
              <SelectItem value="luxury">Luxury ($200+/day)</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Filter className="w-4 h-4 mr-2" />
            More Filters
          </Button>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-2">
          {categories.map((category) => {
            const Icon = category.icon;
            return (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category.id)}
                className="flex items-center gap-2"
              >
                <Icon className="w-4 h-4" />
                {category.name}
              </Button>
            );
          })}
        </div>
      </div>

      <Tabs defaultValue="destinations" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="destinations">Destinations</TabsTrigger>
          <TabsTrigger value="experiences">Experiences</TabsTrigger>
          <TabsTrigger value="inspiration">Inspiration</TabsTrigger>
        </TabsList>

        <TabsContent value="destinations" className="space-y-6">
          {/* Trending Section */}
          {selectedCategory === "all" && (
            <div className="mb-8">
              <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-red-500" />
                Trending Now
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {trendingDestinations.filter(d => d.trending).slice(0, 3).map((destination) => (
                  <DestinationCard key={destination.id} destination={destination} />
                ))}
              </div>
            </div>
          )}

          {/* All Destinations */}
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold">
                {selectedCategory === "all" ? "All Destinations" : `${categories.find(c => c.id === selectedCategory)?.name} Destinations`}
              </h3>
              <span className="text-sm text-gray-500">{filteredDestinations.length} destinations found</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredDestinations.map((destination) => (
                <DestinationCard key={destination.id} destination={destination} />
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="experiences" className="space-y-6">
          <div>
            <h3 className="text-xl font-semibold mb-4">Featured Experiences</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredExperiences.map((experience) => (
                <Card key={experience.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <ImageWithFallback
                    src={experience.image}
                    alt={experience.name}
                    className="w-full h-48 object-cover"
                  />
                  <CardContent className="p-4">
                    <Badge variant="outline" className="mb-2">{experience.category}</Badge>
                    <h3 className="font-semibold mb-2">{experience.name}</h3>
                    <p className="text-sm text-gray-600 mb-3 flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {experience.location}
                    </p>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="font-medium">{experience.rating}</span>
                      </div>
                      <span className="text-sm text-gray-600">{experience.duration}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-bold">${experience.price}</span>
                      <Button size="sm">Book Now</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="inspiration" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="p-6">
              <CardHeader className="p-0 mb-4">
                <CardTitle className="flex items-center gap-2">
                  <Coffee className="w-5 h-5" />
                  Travel Blog
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0 space-y-4">
                <div className="space-y-3">
                  <h4 className="font-medium">Latest Articles</h4>
                  <div className="space-y-2">
                    <p className="text-sm text-gray-600 hover:text-gray-900 cursor-pointer">
                      "10 Hidden Gems in Southeast Asia"
                    </p>
                    <p className="text-sm text-gray-600 hover:text-gray-900 cursor-pointer">
                      "Budget Travel Tips for Europe"
                    </p>
                    <p className="text-sm text-gray-600 hover:text-gray-900 cursor-pointer">
                      "Best Photography Spots in Japan"
                    </p>
                  </div>
                  <Button variant="outline" size="sm">View All Articles</Button>
                </div>
              </CardContent>
            </Card>

            <Card className="p-6">
              <CardHeader className="p-0 mb-4">
                <CardTitle className="flex items-center gap-2">
                  <Users className="w-5 h-5" />
                  Community
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0 space-y-4">
                <div className="space-y-3">
                  <h4 className="font-medium">Travel Stories</h4>
                  <div className="space-y-2">
                    <p className="text-sm text-gray-600">
                      Share your travel experiences and get inspired by others
                    </p>
                    <p className="text-sm text-gray-600">
                      Join discussions about destinations and travel tips
                    </p>
                  </div>
                  <Button variant="outline" size="sm">Join Community</Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      {filteredDestinations.length === 0 && (
        <div className="text-center py-12">
          <Compass className="w-16 h-16 mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No destinations found</h3>
          <p className="text-gray-500 mb-4">Try adjusting your search criteria</p>
          <Button>Browse All Destinations</Button>
        </div>
      )}
    </div>
  );
}