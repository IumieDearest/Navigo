import { useState } from "react";
import { Building, Users, DollarSign, TrendingDown, Calendar, FileText, Settings, Plus, BarChart3, Shield, Globe, CreditCard } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";

export function Business() {
  const [selectedPeriod, setSelectedPeriod] = useState("current-month");

  const companyStats = {
    totalEmployees: 150,
    activeTravel: 12,
    monthlySpend: 45600,
    savings: 8200,
    avgTripCost: 1250,
    pendingApprovals: 5
  };

  const travelPolicies = [
    {
      category: "Flight Booking",
      policy: "Economy class for domestic, Business for international >8hrs",
      compliance: 95,
      status: "active"
    },
    {
      category: "Accommodation",
      policy: "4-star hotels, max $200/night domestic, $300/night international",
      compliance: 87,
      status: "active"
    },
    {
      category: "Meal Allowance",
      policy: "$75/day domestic, $100/day international",
      compliance: 92,
      status: "active"
    },
    {
      category: "Approval Process",
      policy: "Manager approval required for trips >$2000",
      compliance: 100,
      status: "active"
    }
  ];

  const recentBookings = [
    {
      employee: "Sarah Johnson",
      department: "Sales",
      destination: "New York, NY",
      dates: "Mar 15-18, 2024",
      purpose: "Client Meeting",
      cost: 1850,
      status: "approved",
      bookingRef: "BK-001234"
    },
    {
      employee: "Mike Chen",
      department: "Engineering",
      destination: "San Francisco, CA",
      dates: "Mar 20-25, 2024",
      purpose: "Conference",
      cost: 2200,
      status: "pending",
      bookingRef: "BK-001235"
    },
    {
      employee: "Emma Wilson",
      department: "Marketing",
      destination: "London, UK",
      dates: "Apr 5-12, 2024",
      purpose: "Trade Show",
      cost: 3400,
      status: "approved",
      bookingRef: "BK-001236"
    }
  ];

  const departments = [
    { name: "Sales", employees: 45, trips: 28, spend: 18500, budget: 20000 },
    { name: "Engineering", employees: 65, trips: 15, spend: 12200, budget: 15000 },
    { name: "Marketing", employees: 25, trips: 22, spend: 11800, budget: 12000 },
    { name: "Operations", employees: 15, trips: 8, spend: 3100, budget: 5000 }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved": return "default";
      case "pending": return "secondary";
      case "rejected": return "destructive";
      default: return "outline";
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">Business Travel Management</h2>
          <p className="text-gray-600">Centralized corporate travel dashboard and policy management</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline">
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </Button>
          <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 text-white">
            <Plus className="w-4 h-4 mr-2" />
            New Travel Request
          </Button>
        </div>
      </div>

      {/* Period Selector */}
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Travel Overview</h3>
        <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="current-month">Current Month</SelectItem>
            <SelectItem value="last-month">Last Month</SelectItem>
            <SelectItem value="current-quarter">Current Quarter</SelectItem>
            <SelectItem value="current-year">Current Year</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Employees</CardTitle>
            <Users className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{companyStats.totalEmployees}</div>
            <p className="text-xs text-muted-foreground">
              {companyStats.activeTravel} currently traveling
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Spend</CardTitle>
            <DollarSign className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${companyStats.monthlySpend.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              -12% from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Savings</CardTitle>
            <TrendingDown className="w-4 h-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">${companyStats.savings.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">
              15% cost reduction
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pending Approvals</CardTitle>
            <Calendar className="w-4 h-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{companyStats.pendingApprovals}</div>
            <p className="text-xs text-muted-foreground">
              Require your attention
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="bookings">Bookings</TabsTrigger>
          <TabsTrigger value="departments">Departments</TabsTrigger>
          <TabsTrigger value="policies">Policies</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Travel Spend by Department */}
            <Card>
              <CardHeader>
                <CardTitle>Travel Spend by Department</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {departments.map((dept) => (
                    <div key={dept.name} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="font-medium">{dept.name}</span>
                        <span>${dept.spend.toLocaleString()} / ${dept.budget.toLocaleString()}</span>
                      </div>
                      <Progress 
                        value={(dept.spend / dept.budget) * 100} 
                        className="h-2"
                      />
                      <div className="flex justify-between text-xs text-gray-500">
                        <span>{dept.employees} employees</span>
                        <span>{dept.trips} trips this month</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                    <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center">
                      <Calendar className="w-4 h-4 text-white" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">New booking request</p>
                      <p className="text-xs text-gray-500">Mike Chen - San Francisco conference</p>
                    </div>
                    <span className="text-xs text-gray-500">2 hrs ago</span>
                  </div>
                  
                  <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                    <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                      <DollarSign className="w-4 h-4 text-white" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Travel policy savings</p>
                      <p className="text-xs text-gray-500">$320 saved on London flights</p>
                    </div>
                    <span className="text-xs text-gray-500">5 hrs ago</span>
                  </div>
                  
                  <div className="flex items-center space-x-3 p-3 bg-orange-50 rounded-lg">
                    <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                      <Shield className="w-4 h-4 text-white" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Policy compliance alert</p>
                      <p className="text-xs text-gray-500">Hotel booking exceeded limit</p>
                    </div>
                    <span className="text-xs text-gray-500">1 day ago</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Button variant="outline" className="h-20 flex-col space-y-2">
                  <Plus className="w-6 h-6" />
                  <span>New Travel Request</span>
                </Button>
                <Button variant="outline" className="h-20 flex-col space-y-2">
                  <BarChart3 className="w-6 h-6" />
                  <span>Generate Report</span>
                </Button>
                <Button variant="outline" className="h-20 flex-col space-y-2">
                  <Settings className="w-6 h-6" />
                  <span>Manage Policies</span>
                </Button>
                <Button variant="outline" className="h-20 flex-col space-y-2">
                  <CreditCard className="w-6 h-6" />
                  <span>Expense Review</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bookings" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Travel Bookings</h3>
            <div className="flex gap-2">
              <Button variant="outline">
                <FileText className="w-4 h-4 mr-2" />
                Export
              </Button>
              <Button>
                <Plus className="w-4 h-4 mr-2" />
                New Booking
              </Button>
            </div>
          </div>

          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Destination</TableHead>
                  <TableHead>Dates</TableHead>
                  <TableHead>Purpose</TableHead>
                  <TableHead>Cost</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentBookings.map((booking) => (
                  <TableRow key={booking.bookingRef}>
                    <TableCell className="font-medium">{booking.employee}</TableCell>
                    <TableCell>{booking.department}</TableCell>
                    <TableCell>{booking.destination}</TableCell>
                    <TableCell>{booking.dates}</TableCell>
                    <TableCell>{booking.purpose}</TableCell>
                    <TableCell>${booking.cost.toLocaleString()}</TableCell>
                    <TableCell>
                      <Badge variant={getStatusColor(booking.status)}>
                        {booking.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Button size="sm" variant="outline">
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>
        </TabsContent>

        <TabsContent value="departments" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Department Overview</h3>
            <Button variant="outline">
              <BarChart3 className="w-4 h-4 mr-2" />
              Department Report
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {departments.map((dept) => (
              <Card key={dept.name}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    {dept.name}
                    <Badge variant="outline">{dept.employees} employees</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">This Month</p>
                      <p className="text-xl font-bold">{dept.trips} trips</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Total Spend</p>
                      <p className="text-xl font-bold">${dept.spend.toLocaleString()}</p>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-sm mb-2">
                      <span>Budget Usage</span>
                      <span>{Math.round((dept.spend / dept.budget) * 100)}%</span>
                    </div>
                    <Progress value={(dept.spend / dept.budget) * 100} className="h-2" />
                    <p className="text-xs text-gray-500 mt-1">
                      ${(dept.budget - dept.spend).toLocaleString()} remaining
                    </p>
                  </div>

                  <Button size="sm" className="w-full">
                    View Details
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="policies" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Travel Policies</h3>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Policy
            </Button>
          </div>

          <div className="space-y-4">
            {travelPolicies.map((policy, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h4 className="font-semibold mb-2">{policy.category}</h4>
                      <p className="text-gray-600 text-sm">{policy.policy}</p>
                    </div>
                    <Badge variant={policy.status === "active" ? "default" : "secondary"}>
                      {policy.status}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex justify-between text-sm mb-1">
                        <span>Compliance Rate</span>
                        <span>{policy.compliance}%</span>
                      </div>
                      <Progress value={policy.compliance} className="h-2" />
                    </div>
                    <div className="ml-4 flex space-x-2">
                      <Button size="sm" variant="outline">
                        Edit
                      </Button>
                      <Button size="sm" variant="outline">
                        View Details
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="reports" className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">Travel Reports</h3>
            <Button>
              <BarChart3 className="w-4 h-4 mr-2" />
              Generate Custom Report
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-semibold">Monthly Summary</h4>
                <FileText className="w-5 h-5 text-gray-400" />
              </div>
              <p className="text-sm text-gray-600 mb-4">
                Comprehensive monthly travel spending and activity report
              </p>
              <Button size="sm" className="w-full">
                Download Report
              </Button>
            </Card>

            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-semibold">Department Analysis</h4>
                <BarChart3 className="w-5 h-5 text-gray-400" />
              </div>
              <p className="text-sm text-gray-600 mb-4">
                Detailed breakdown of travel expenses by department
              </p>
              <Button size="sm" className="w-full">
                View Analysis
              </Button>
            </Card>

            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-semibold">Policy Compliance</h4>
                <Shield className="w-5 h-5 text-gray-400" />
              </div>
              <p className="text-sm text-gray-600 mb-4">
                Track adherence to corporate travel policies
              </p>
              <Button size="sm" className="w-full">
                View Compliance
              </Button>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}