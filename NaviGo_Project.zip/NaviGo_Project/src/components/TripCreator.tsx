import { useState } from "react";
import { MapPin, Sparkles, Calendar, DollarSign } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Checkbox } from "./ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";

export function TripCreator() {
  const [interests, setInterests] = useState<string[]>([]);

  const interestOptions = [
    "Photography", "Food & Dining", "Nightlife", "Shopping",
    "Museums", "Adventure Sports", "Relaxation", "Nature"
  ];

  const toggleInterest = (interest: string) => {
    setInterests(prev => 
      prev.includes(interest) 
        ? prev.filter(i => i !== interest)
        : [...prev, interest]
    );
  };

  return (
    <section className="py-16 relative overflow-hidden">
      {/* Abstract background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-50 via-sky-50 to-teal-50 dark:from-slate-950 dark:via-slate-900 dark:to-teal-950" />
        <div className="absolute inset-0 travel-pattern-1 opacity-30" />
        
        {/* Decorative shapes */}
        <div className="absolute top-10 right-10 w-40 h-40 bg-gradient-to-br from-sky-300/10 to-teal-300/5 rounded-full blur-2xl" />
        <div className="absolute bottom-10 left-10 w-32 h-32 bg-gradient-to-br from-violet-300/10 to-purple-300/5 rounded-full blur-2xl" />
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Trip Creator Form */}
          <div className="lg:col-span-2">
            <Card className="glass-card border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-3 text-2xl">
                  <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-yellow-500 rounded-xl flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-white" />
                  </div>
                  Plan Your Dream Journey
                </CardTitle>
                <p className="text-gray-600 dark:text-gray-300 text-lg">
                  Share your travel dreams with us and we'll craft the perfect adventure tailored just for you!
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="budget">Budget (USD)</Label>
                    <div className="relative">
                      <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <Input 
                        id="budget"
                        placeholder="1000"
                        className="pl-10"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="distance">Max Distance (miles)</Label>
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <Input 
                        id="distance"
                        placeholder="500"
                        className="pl-10"
                      />
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="duration">Duration (days)</Label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <Input 
                        id="duration"
                        placeholder="5"
                        className="pl-10"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Trip Category</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose your adventure" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="adventure">Adventure</SelectItem>
                        <SelectItem value="relaxation">Relaxation</SelectItem>
                        <SelectItem value="cultural">Cultural</SelectItem>
                        <SelectItem value="business">Business</SelectItem>
                        <SelectItem value="family">Family</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-3">
                  <Label>Interests (Optional)</Label>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {interestOptions.map((interest) => (
                      <div key={interest} className="flex items-center space-x-2">
                        <Checkbox
                          id={interest}
                          checked={interests.includes(interest)}
                          onCheckedChange={() => toggleInterest(interest)}
                        />
                        <Label 
                          htmlFor={interest}
                          className="text-sm cursor-pointer"
                        >
                          {interest}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Button 
                  className="w-full bg-gradient-to-r from-sky-500 to-teal-500 hover:from-sky-600 hover:to-teal-600 text-white py-4 text-lg font-semibold rounded-xl shadow-lg transform hover:scale-105 transition-all duration-200"
                  size="lg"
                >
                  <Sparkles className="w-5 h-5 mr-2" />
                  Begin My Adventure
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Inspiration Sidebar */}
          <div className="space-y-6">
            <Card className="glass-card border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-xl">
                  <div className="w-8 h-8 bg-gradient-to-br from-violet-500 to-purple-500 rounded-lg flex items-center justify-center">
                    <MapPin className="w-4 h-4 text-white" />
                  </div>
                  Recent Adventures
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border-l-4 border-green-500 pl-4">
                  <h4 className="font-medium">Mountain Adventure in Colorado</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    Experience the breathtaking beauty of Colorado mountains with guided hiking trips, camping under the stars, and amazing wildlife photography opportunities.
                  </p>
                  <div className="flex items-center justify-between mt-3 text-sm text-gray-500 dark:text-gray-400">
                    <span>$1,200</span>
                    <span>5 days</span>
                    <span>300mi</span>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    <span className="bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-400 px-2 py-1 rounded-md text-xs">Hiking</span>
                    <span className="bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-400 px-2 py-1 rounded-md text-xs">Camping</span>
                    <span className="bg-purple-100 dark:bg-purple-900/20 text-purple-800 dark:text-purple-400 px-2 py-1 rounded-md text-xs">Photography</span>
                  </div>
                </div>

                <div className="border-l-4 border-blue-500 pl-4">
                  <h4 className="font-medium">Beach Paradise in Maldives</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                    Dive into crystal clear waters, explore vibrant coral reefs, and relax in overwater bungalows in this tropical paradise.
                  </p>
                  <div className="flex items-center justify-between mt-3 text-sm text-gray-500 dark:text-gray-400">
                    <span>$2,500</span>
                    <span>7 days</span>
                    <span>8500mi</span>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    <span className="bg-blue-100 dark:bg-blue-900/20 text-blue-800 dark:text-blue-400 px-2 py-1 rounded-md text-xs">Swimming</span>
                    <span className="bg-teal-100 dark:bg-teal-900/20 text-teal-800 dark:text-teal-400 px-2 py-1 rounded-md text-xs">Snorkeling</span>
                    <span className="bg-orange-100 dark:bg-orange-900/20 text-orange-800 dark:text-orange-400 px-2 py-1 rounded-md text-xs">Island Hopping</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-orange-50 to-yellow-50 dark:from-orange-950/50 dark:to-yellow-950/50 border-orange-200 dark:border-orange-800">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-orange-800 dark:text-orange-400">
                  <Sparkles className="w-5 h-5" />
                  Premium Plan
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
                  <span>✓</span>
                  <span>Unlimited trip generation</span>
                </div>
                <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
                  <span>✓</span>
                  <span>Advanced customization</span>
                </div>
                <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
                  <span>✓</span>
                  <span>Priority support</span>
                </div>
                <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
                  <span>✓</span>
                  <span>Export itineraries</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}