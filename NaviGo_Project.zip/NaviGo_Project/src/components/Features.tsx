import { Brain, Shield, Users, Smartphone, Calendar, TrendingUp } from "lucide-react";
import { Card, CardContent } from "./ui/card";

export function Features() {
  const features = [
    {
      icon: Brain,
      title: "AI-Powered Planning",
      description: "Our intelligent system learns your preferences and creates personalized itineraries that match your travel style.",
      color: "text-purple-600 bg-purple-100 dark:text-purple-400 dark:bg-purple-900/20"
    },
    {
      icon: Shield,
      title: "Secure Data Storage",
      description: "All your travel information is encrypted and securely stored, accessible only to you across all your devices.",
      color: "text-green-600 bg-green-100 dark:text-green-400 dark:bg-green-900/20"
    },
    {
      icon: Users,
      title: "Group Collaboration",
      description: "Plan trips with friends, family, or colleagues. Share itineraries, vote on activities, and coordinate seamlessly.",
      color: "text-blue-600 bg-blue-100 dark:text-blue-400 dark:bg-blue-900/20"
    },
    {
      icon: Smartphone,
      title: "Progressive Web App",
      description: "Access your travel plans anywhere with our mobile-optimized app that works online and offline.",
      color: "text-orange-600 bg-orange-100 dark:text-orange-400 dark:bg-orange-900/20"
    },
    {
      icon: Calendar,
      title: "Unified Dashboard",
      description: "All your trips, bookings, and travel documents in one synchronized dashboard across every device.",
      color: "text-cyan-600 bg-cyan-100 dark:text-cyan-400 dark:bg-cyan-900/20"
    },
    {
      icon: TrendingUp,
      title: "Business Savings",
      description: "Enterprise features including bulk discounts, expense tracking, and HR integrations to reduce travel costs.",
      color: "text-indigo-600 bg-indigo-100 dark:text-indigo-400 dark:bg-indigo-900/20"
    }
  ];

  return (
    <section className="py-16 bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Why Choose NaviGo?
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            We're not just another booking platform. We're your intelligent travel companion that grows with you.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card key={index} className="border-0 shadow-md hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className={`w-12 h-12 rounded-lg ${feature.color} flex items-center justify-center mb-4`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}