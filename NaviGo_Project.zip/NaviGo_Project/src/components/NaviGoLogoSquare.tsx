import naviGoImage from 'figma:asset/79bd977b3889c1a721eb86afad67ab5e9ff98efe.png';

interface NaviGoLogoSquareProps {
  className?: string;
  size?: number;
}

export function NaviGoLogoSquare({ className = "", size = 80 }: NaviGoLogoSquareProps) {
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <div 
        className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden"
        style={{ 
          width: size, 
          height: size,
          padding: size * 0.1
        }}
      >
        <img 
          src={naviGoImage} 
          alt="NaviGo - Astria Travels" 
          className="w-full h-full object-contain"
        />
      </div>
    </div>
  );
}