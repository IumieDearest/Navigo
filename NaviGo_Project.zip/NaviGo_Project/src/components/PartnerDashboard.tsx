import { useState } from "react";
import { 
  Plane, Hotel, Car, Bell, Settings, BarChart3, Users, 
  TrendingUp, Calendar, MapPin, CreditCard, Check, X, 
  AlertCircle, Clock, Star, Filter, Search, Utensils, Bus,
  Activity, Shield, Anchor, Briefcase, Package, Globe,
  Wifi, ParkingCircle, Bed, Camera, MapIcon, Gamepad2,
  Wind, Waves, Mountain, Plus
} from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { BusinessSpecificSettings } from "./BusinessSpecificSettings";

interface BookingRequest {
  id: string;
  type: "flight" | "hotel" | "car";
  customerName: string;
  customerEmail: string;
  details: {
    from?: string;
    to?: string;
    checkIn?: string;
    checkOut?: string;
    passengers?: number;
    guests?: number;
    roomType?: string;
    flightClass?: string;
  };
  requestedPrice: number;
  status: "pending" | "accepted" | "declined" | "negotiating";
  timestamp: string;
  priority: "high" | "medium" | "low";
}

interface PartnerDashboardProps {
  partnerType: string;
  partnerName: string;
}

export function PartnerDashboard({ partnerType, partnerName }: PartnerDashboardProps) {
  const [activeTab, setActiveTab] = useState("requests");
  const [statusFilter, setStatusFilter] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  // Get business type specific configuration
  const getBusinessConfig = (type: string) => {
    switch (type) {
      case 'airline':
        return {
          icon: Plane,
          primaryColor: 'blue',
          serviceName: 'Flights',
          features: ['Route Management', 'Fleet Analytics', 'Passenger Services', 'Pricing Optimization']
        };
      case 'hotel':
        return {
          icon: Hotel,
          primaryColor: 'purple',
          serviceName: 'Accommodation',
          features: ['Room Management', 'Occupancy Analytics', 'Guest Services', 'Revenue Management']
        };
      case 'car-rental':
        return {
          icon: Car,
          primaryColor: 'green',
          serviceName: 'Vehicle Rentals',
          features: ['Fleet Management', 'Rental Analytics', 'Customer Services', 'Maintenance Tracking']
        };
      case 'restaurant':
        return {
          icon: Utensils,
          primaryColor: 'orange',
          serviceName: 'Dining & Food',
          features: ['Menu Management', 'Reservation System', 'Customer Reviews', 'Delivery Integration']
        };
      case 'transportation':
        return {
          icon: Bus,
          primaryColor: 'indigo',
          serviceName: 'Ground Transport',
          features: ['Route Planning', 'Vehicle Tracking', 'Booking System', 'Driver Management']
        };
      case 'activities':
        return {
          icon: Activity,
          primaryColor: 'red',
          serviceName: 'Experiences',
          features: ['Activity Listings', 'Tour Management', 'Guide Services', 'Equipment Rental']
        };
      case 'travel-insurance':
        return {
          icon: Shield,
          primaryColor: 'teal',
          serviceName: 'Travel Insurance',
          features: ['Policy Management', 'Claims Processing', 'Risk Assessment', 'Customer Support']
        };
      case 'cruise':
        return {
          icon: Anchor,
          primaryColor: 'cyan',
          serviceName: 'Cruise Services',
          features: ['Cabin Management', 'Itinerary Planning', 'Onboard Services', 'Port Coordination']
        };
      case 'corporate-travel':
        return {
          icon: Briefcase,
          primaryColor: 'slate',
          serviceName: 'Corporate Travel',
          features: ['Employee Management', 'Expense Tracking', 'Policy Compliance', 'Reporting Tools']
        };
      default:
        return {
          icon: Package,
          primaryColor: 'gray',
          serviceName: 'Travel Services',
          features: ['Service Management', 'Booking System', 'Customer Support', 'Analytics Dashboard']
        };
    }
  };

  const businessConfig = getBusinessConfig(partnerType);

  const [bookingRequests, setBookingRequests] = useState<BookingRequest[]>([
    {
      id: "BR-001",
      type: "flight",
      customerName: "Anna Mae Regis",
      customerEmail: "anna.regis@email.com",
      details: {
        from: "New York (JFK)",
        to: "Paris (CDG)",
        passengers: 2,
        flightClass: "Business"
      },
      requestedPrice: 2400,
      status: "pending",
      timestamp: "2 hours ago",
      priority: "high"
    },
    {
      id: "BR-002",
      type: "flight",
      customerName: "John Smith",
      customerEmail: "john.smith@email.com",
      details: {
        from: "Los Angeles (LAX)",
        to: "London (LHR)",
        passengers: 1,
        flightClass: "Premium Economy"
      },
      requestedPrice: 1800,
      status: "pending",
      timestamp: "4 hours ago",
      priority: "medium"
    },
    {
      id: "BR-003",
      type: "flight",
      customerName: "Sarah Johnson",
      customerEmail: "sarah.j@email.com",
      details: {
        from: "London (LHR)",
        to: "Tokyo (NRT)",
        passengers: 1,
        flightClass: "Economy"
      },
      requestedPrice: 850,
      status: "negotiating",
      timestamp: "1 day ago",
      priority: "low"
    },
    {
      id: "BR-004",
      type: "flight",
      customerName: "Michael Chen",
      customerEmail: "m.chen@email.com",
      details: {
        from: "San Francisco (SFO)",
        to: "Amsterdam (AMS)",
        passengers: 3,
        flightClass: "Business"
      },
      requestedPrice: 4200,
      status: "accepted",
      timestamp: "2 days ago",
      priority: "high"
    },
    {
      id: "BR-005",
      type: "flight",
      customerName: "Emma Rodriguez",
      customerEmail: "emma.r@email.com",
      details: {
        from: "Miami (MIA)",
        to: "Barcelona (BCN)",
        passengers: 2,
        flightClass: "Economy"
      },
      requestedPrice: 1200,
      status: "declined",
      timestamp: "3 days ago",
      priority: "low"
    }
  ]);

  const handleStatusChange = (requestId: string, newStatus: BookingRequest["status"]) => {
    setBookingRequests(requests => 
      requests.map(request => 
        request.id === requestId ? { ...request, status: newStatus } : request
      )
    );
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "flight": return Plane;
      case "hotel": return Hotel;
      case "car": return Car;
      default: return Plane;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
      case "medium": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
      case "low": return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending": return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
      case "accepted": return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      case "declined": return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
      case "negotiating": return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const filteredRequests = bookingRequests.filter(request => {
    const matchesStatus = statusFilter === "all" || request.status === statusFilter;
    const matchesSearch = request.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         request.customerEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         request.id.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const stats = {
    totalRequests: bookingRequests.length,
    pendingRequests: bookingRequests.filter(r => r.status === "pending").length,
    acceptedRequests: bookingRequests.filter(r => r.status === "accepted").length,
    revenue: "₱15,240"
  };

  return (
    <section className="py-4 md:py-8 bg-gradient-to-br from-sky-50 via-white to-violet-50 dark:from-slate-900 dark:via-slate-950 dark:to-violet-950 min-h-screen travel-pattern-1">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Section */}
        <div className="mb-6 md:mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white mb-1 md:mb-2">Partner Dashboard</h1>
          <p className="text-sm md:text-base text-gray-600 dark:text-gray-400 mb-6">Manage your services, bookings, and insights in one place.</p>
          
          {/* Quick Actions - Mobile-first responsive design */}
          <div className="flex flex-col sm:flex-row gap-3 sm:justify-end mb-6">
            <Button size="sm" className="bg-gradient-to-r from-sky-500 to-teal-500 hover:from-sky-600 hover:to-teal-600 text-white rounded-xl shadow-lg w-full sm:w-auto">
              <Plus className="w-4 h-4 mr-2" />
              Add Travel Services
            </Button>
            <Button size="sm" variant="outline" className="rounded-xl border-gray-200 dark:border-gray-700 w-full sm:w-auto">
              <Globe className="w-4 h-4 mr-2" />
              View Live Listings
            </Button>
          </div>
        </div>
        {/* Stats Cards - Matching Travel Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-6 md:mb-8">
          <Card className="glass-card rounded-2xl shadow-lg border-0 cursor-pointer hover:shadow-xl transition-shadow" onClick={() => setActiveTab("requests")}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 md:pb-2 px-6 pt-6">
              <CardTitle className="text-base md:text-sm font-semibold">Requests</CardTitle>
              <div className="w-10 h-10 md:w-8 md:h-8 bg-gradient-to-br from-sky-500 to-teal-500 rounded-xl flex items-center justify-center">
                <BarChart3 className="w-5 h-5 md:w-4 md:h-4 text-white" />
              </div>
            </CardHeader>
            <CardContent className="px-6 pb-6">
              <div className="text-3xl md:text-2xl font-bold text-gray-900 dark:text-white">{stats.totalRequests}</div>
              <p className="text-sm md:text-xs text-gray-600 dark:text-gray-400 mt-1">+2 from yesterday</p>
            </CardContent>
          </Card>
          
          <Card className="glass-card rounded-2xl shadow-lg border-0 cursor-pointer hover:shadow-xl transition-shadow" onClick={() => {setActiveTab("requests"); setStatusFilter("pending");}}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 md:pb-2 px-6 pt-6">
              <CardTitle className="text-base md:text-sm font-semibold">Pending</CardTitle>
              <div className="w-10 h-10 md:w-8 md:h-8 bg-gradient-to-br from-orange-500 to-amber-500 rounded-xl flex items-center justify-center">
                <Clock className="w-5 h-5 md:w-4 md:h-4 text-white" />
              </div>
            </CardHeader>
            <CardContent className="px-6 pb-6">
              <div className="text-3xl md:text-2xl font-bold text-gray-900 dark:text-white">{stats.pendingRequests}</div>
              <p className="text-sm md:text-xs text-gray-600 dark:text-gray-400 mt-1">Avg response: 2h</p>
            </CardContent>
          </Card>
          
          <Card className="glass-card rounded-2xl shadow-lg border-0 cursor-pointer hover:shadow-xl transition-shadow" onClick={() => {setActiveTab("requests"); setStatusFilter("accepted");}}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 md:pb-2 px-6 pt-6">
              <CardTitle className="text-base md:text-sm font-semibold">Accepted</CardTitle>
              <div className="w-10 h-10 md:w-8 md:h-8 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center">
                <Check className="w-5 h-5 md:w-4 md:h-4 text-white" />
              </div>
            </CardHeader>
            <CardContent className="px-6 pb-6">
              <div className="text-3xl md:text-2xl font-bold text-gray-900 dark:text-white">{stats.acceptedRequests}</div>
              <p className="text-sm md:text-xs text-gray-600 dark:text-gray-400 mt-1">75% acceptance rate</p>
            </CardContent>
          </Card>
          
          <Card className="glass-card rounded-2xl shadow-lg border-0 cursor-pointer hover:shadow-xl transition-shadow" onClick={() => setActiveTab("analytics")}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 md:pb-2 px-6 pt-6">
              <CardTitle className="text-base md:text-sm font-semibold">Revenue</CardTitle>
              <div className="w-10 h-10 md:w-8 md:h-8 bg-gradient-to-br from-violet-500 to-purple-500 rounded-xl flex items-center justify-center">
                <TrendingUp className="w-5 h-5 md:w-4 md:h-4 text-white" />
              </div>
            </CardHeader>
            <CardContent className="px-6 pb-6">
              <div className="text-3xl md:text-2xl font-bold text-gray-900 dark:text-white">₱15,240</div>
              <p className="text-sm md:text-xs text-green-600 dark:text-green-400 mt-1">↗ +12% this month</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4 md:space-y-6">
          <TabsList className="glass-card grid w-full grid-cols-3 lg:w-fit">
            <TabsTrigger value="requests" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-sky-500 data-[state=active]:to-teal-500 data-[state=active]:text-white">Booking Requests</TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-sky-500 data-[state=active]:to-teal-500 data-[state=active]:text-white">Analytics</TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-sky-500 data-[state=active]:to-teal-500 data-[state=active]:text-white">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="requests" className="space-y-4 md:space-y-6">
            {/* Search & Filter Section */}
            <Card className="glass-card rounded-2xl shadow-lg border-0">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                      <Input
                        placeholder="Search by customer name, email, or request ID..."
                        className="pl-10 rounded-xl border-gray-200 dark:border-gray-700 focus:border-sky-500 focus:ring-sky-500"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                  </div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-[180px] rounded-xl border-gray-200 dark:border-gray-700">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                      <SelectItem value="accepted">Accepted</SelectItem>
                      <SelectItem value="declined">Declined</SelectItem>
                      <SelectItem value="negotiating">Negotiating</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Booking Requests */}
            <div className="space-y-4">
              {filteredRequests.length === 0 ? (
                <Card className="glass-card rounded-2xl shadow-lg border-0">
                  <CardContent className="p-12 text-center">
                    <AlertCircle className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No requests found</h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      {statusFilter === "all" 
                        ? "No booking requests match your search criteria." 
                        : `No ${statusFilter} requests found.`}
                    </p>
                  </CardContent>
                </Card>
              ) : (
                filteredRequests.map((request) => {
                  const TypeIcon = getTypeIcon(request.type);
                  
                  return (
                    <Card key={request.id} className="glass-card rounded-2xl shadow-lg border-0 hover:shadow-xl transition-shadow">
                      <CardContent className="p-4 sm:p-6">
                        <div className="flex flex-col gap-4">
                          <div className="flex items-start gap-4">
                            <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                              <TypeIcon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                            </div>
                            
                            <div className="flex-1 min-w-0">
                              <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 mb-2">
                                <h3 className="font-semibold text-gray-900 dark:text-white">
                                  Request #{request.id}
                                </h3>
                                <div className="flex flex-wrap items-center gap-2">
                                  <Badge className={getPriorityColor(request.priority)}>
                                    {request.priority} priority
                                  </Badge>
                                  <Badge className={getStatusColor(request.status)}>
                                    {request.status}
                                  </Badge>
                                  {request.status === "pending" && (
                                    <Badge variant="outline" className="text-xs">
                                      <Clock className="w-3 h-3 mr-1" />
                                      Response due in 4h
                                    </Badge>
                                  )}
                                </div>
                              </div>
                              
                              <div className="mb-3">
                                <div className="flex items-center gap-2 mb-1">
                                  <Avatar className="w-6 h-6">
                                    <AvatarFallback className="text-xs">
                                      {request.customerName.split(' ').map(n => n[0]).join('')}
                                    </AvatarFallback>
                                  </Avatar>
                                  <p className="font-medium text-gray-900 dark:text-white">{request.customerName}</p>
                                  <Badge variant="outline" className="text-xs">
                                    <Star className="w-3 h-3 mr-1 fill-yellow-400 text-yellow-400" />
                                    VIP Customer
                                  </Badge>
                                </div>
                                <p className="text-sm text-gray-600 dark:text-gray-400 ml-8">{request.customerEmail}</p>
                              </div>
                              
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                                {request.type === "flight" && (
                                  <>
                                    <div>
                                      <p className="text-sm text-gray-600 dark:text-gray-400">Route</p>
                                      <p className="font-medium">{request.details.from} → {request.details.to}</p>
                                    </div>
                                    <div>
                                      <p className="text-sm text-gray-600 dark:text-gray-400">Passengers & Class</p>
                                      <p className="font-medium">{request.details.passengers} passengers, {request.details.flightClass}</p>
                                    </div>
                                  </>
                                )}
                                
                                {request.type === "hotel" && (
                                  <>
                                    <div>
                                      <p className="text-sm text-gray-600 dark:text-gray-400">Stay Period</p>
                                      <p className="font-medium">{request.details.checkIn} to {request.details.checkOut}</p>
                                    </div>
                                    <div>
                                      <p className="text-sm text-gray-600 dark:text-gray-400">Guests & Room</p>
                                      <p className="font-medium">{request.details.guests} guests, {request.details.roomType}</p>
                                    </div>
                                  </>
                                )}
                                
                                <div>
                                  <p className="text-sm text-gray-600 dark:text-gray-400">Requested Price</p>
                                  <div className="flex items-center gap-2">
                                    <p className="font-bold text-green-600">₱{request.requestedPrice.toLocaleString()}</p>
                                    <Badge variant="outline" className="text-xs">
                                      Market avg: ₱{(request.requestedPrice * 1.15).toFixed(0)}
                                    </Badge>
                                  </div>
                                </div>
                              </div>

                              <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                                <div className="flex items-center gap-1">
                                  <Calendar className="w-4 h-4" />
                                  <span>Received {request.timestamp}</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <Users className="w-4 h-4" />
                                  <span>Customer since 2022</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <MapPin className="w-4 h-4" />
                                  <span>New York, USA</span>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          {/* Action Buttons - Moved below all content */}
                          <div className="mobile-button-container flex flex-col sm:flex-row gap-3 mt-4 pt-4 border-t border-gray-100 dark:border-gray-700">
                            {request.status === "pending" && (
                              <>
                                <Button 
                                  size="sm" 
                                  onClick={() => handleStatusChange(request.id, "accepted")}
                                  className="mobile-button bg-green-600 hover:bg-green-700 active:bg-green-800 text-white w-full sm:w-auto rounded-lg px-4 py-3 sm:py-2 font-medium touch-manipulation"
                                >
                                  <Check className="w-4 h-4 mr-2" />
                                  ✅ Accept
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  onClick={() => handleStatusChange(request.id, "negotiating")}
                                  className="mobile-button w-full sm:w-auto rounded-lg px-4 py-3 sm:py-2 font-medium border-gray-300 hover:bg-gray-50 active:bg-gray-100 dark:border-gray-600 dark:hover:bg-gray-800 dark:active:bg-gray-700 touch-manipulation"
                                >
                                  🔄 Negotiate
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="outline" 
                                  onClick={() => handleStatusChange(request.id, "declined")}
                                  className="mobile-button text-red-600 border-red-300 hover:bg-red-50 active:bg-red-100 dark:border-red-600 dark:hover:bg-red-950/50 dark:active:bg-red-900/50 w-full sm:w-auto rounded-lg px-4 py-3 sm:py-2 font-medium touch-manipulation"
                                >
                                  <X className="w-4 h-4 mr-2" />
                                  ❌ Decline
                                </Button>
                              </>
                            )}
                            
                            {request.status === "negotiating" && (
                              <>
                                <Button size="sm" variant="outline" className="mobile-button w-full sm:w-auto rounded-lg px-4 py-3 sm:py-2 font-medium border-gray-300 hover:bg-gray-50 active:bg-gray-100 dark:border-gray-600 dark:hover:bg-gray-800 dark:active:bg-gray-700 touch-manipulation">
                                  🔄 Counter Offer
                                </Button>
                                <Button size="sm" className="mobile-button bg-green-600 hover:bg-green-700 active:bg-green-800 text-white w-full sm:w-auto rounded-lg px-4 py-3 sm:py-2 font-medium touch-manipulation">
                                  ✅ Accept Current
                                </Button>
                                <Button size="sm" variant="ghost" className="mobile-button text-blue-600 hover:bg-blue-50 active:bg-blue-100 dark:hover:bg-blue-950/50 dark:active:bg-blue-900/50 w-full sm:w-auto rounded-lg px-4 py-3 sm:py-2 font-medium touch-manipulation">
                                  💬 Message Customer
                                </Button>
                              </>
                            )}
                            
                            {request.status === "accepted" && (
                              <>
                                <Button size="sm" variant="outline" className="mobile-button w-full sm:w-auto rounded-lg px-4 py-3 sm:py-2 font-medium border-gray-300 hover:bg-gray-50 active:bg-gray-100 dark:border-gray-600 dark:hover:bg-gray-800 dark:active:bg-gray-700 touch-manipulation">
                                  📋 View Booking
                                </Button>
                                <Button size="sm" variant="ghost" className="mobile-button text-blue-600 hover:bg-blue-50 active:bg-blue-100 dark:hover:bg-blue-950/50 dark:active:bg-blue-900/50 w-full sm:w-auto rounded-lg px-4 py-3 sm:py-2 font-medium touch-manipulation">
                                  📤 Send Updates
                                </Button>
                              </>
                            )}

                            {request.status === "declined" && (
                              <Button size="sm" variant="outline" className="mobile-button w-full sm:w-auto rounded-lg px-4 py-3 sm:py-2 font-medium border-gray-300 hover:bg-gray-50 active:bg-gray-100 dark:border-gray-600 dark:hover:bg-gray-800 dark:active:bg-gray-700 touch-manipulation">
                                📄 View Details
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-4 md:space-y-6">
            {/* Revenue Analytics */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
              <Card className="glass-card rounded-2xl shadow-lg border-0">
                <CardHeader>
                  <CardTitle>Revenue Breakdown</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between items-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">This Month</p>
                      <p className="text-xl font-bold text-green-600">₱15,240</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-green-600">+12% vs last month</p>
                      <p className="text-xs text-gray-500">₱13,600 previous</p>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">This Quarter</p>
                      <p className="text-xl font-bold text-blue-600">₱42,850</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-blue-600">+8% vs last quarter</p>
                      <p className="text-xs text-gray-500">12 bookings completed</p>
                    </div>
                  </div>

                  <div className="flex justify-between items-center p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Year to Date</p>
                      <p className="text-xl font-bold text-purple-600">₱156,240</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-purple-600">+15% vs last year</p>
                      <p className="text-xs text-gray-500">48 bookings completed</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="glass-card rounded-2xl shadow-lg border-0">
                <CardHeader>
                  <CardTitle>Request Analytics</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">75%</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Acceptance Rate</p>
                    </div>
                    <div className="text-center p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <p className="text-2xl font-bold text-gray-900 dark:text-white">2.3h</p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Avg Response Time</p>
                    </div>
                  </div>
                  
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Accepted Requests</span>
                        <span>75%</span>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div className="bg-green-500 h-2 rounded-full" style={{width: '75%'}}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Negotiated Requests</span>
                        <span>15%</span>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div className="bg-orange-500 h-2 rounded-full" style={{width: '15%'}}></div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Declined Requests</span>
                        <span>10%</span>
                      </div>
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                        <div className="bg-red-500 h-2 rounded-full" style={{width: '10%'}}></div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Customer Insights */}
            <Card className="glass-card rounded-2xl shadow-lg border-0">
              <CardHeader>
                <CardTitle>Top Customers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: "Anna Mae Regis", bookings: 8, revenue: "₱12,400", status: "VIP" },
                    { name: "John Smith", bookings: 5, revenue: "₱8,200", status: "Premium" },
                    { name: "Sarah Johnson", bookings: 3, revenue: "₱4,600", status: "Regular" },
                  ].map((customer, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarFallback>{customer.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium text-gray-900 dark:text-white">{customer.name}</p>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{customer.bookings} bookings</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-gray-900 dark:text-white">{customer.revenue}</p>
                        <Badge className={
                          customer.status === "VIP" ? "bg-purple-100 text-purple-800" :
                          customer.status === "Premium" ? "bg-blue-100 text-blue-800" :
                          "bg-gray-100 text-gray-800"
                        }>
                          {customer.status}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-4 md:space-y-6">
            <Card className="glass-card rounded-2xl shadow-lg border-0">
              <CardHeader>
                <CardTitle>Partner Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-400">Settings panel coming soon...</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}