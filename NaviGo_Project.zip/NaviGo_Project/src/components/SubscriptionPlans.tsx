import { 
  Check, 
  Star, 
  Building, 
  Users, 
  X, 
  MessageSquare, 
  Calendar, 
  Shield, 
  CreditCard, 
  Map, 
  Plane, 
  Globe, 
  HeadphonesIcon,
  Zap,
  Clock
} from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";

export function SubscriptionPlans() {
  return (
    <section className="relative py-20 overflow-hidden">
      {/* Modern gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-white to-purple-50 dark:from-gray-900 dark:via-gray-950 dark:to-blue-950"></div>
      
      {/* Abstract travel shapes */}
      <div className="absolute top-20 left-10 w-32 h-32 bg-gradient-to-br from-blue-200/30 to-purple-200/30 rounded-full blur-xl"></div>
      <div className="absolute bottom-20 right-10 w-40 h-40 bg-gradient-to-br from-orange-200/30 to-pink-200/30 rounded-full blur-xl"></div>
      <div className="absolute top-1/2 left-1/3 w-24 h-24 bg-gradient-to-br from-green-200/20 to-blue-200/20 rounded-full blur-lg"></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm px-4 py-2 rounded-full border border-white/20 mb-6">
            <Plane className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Choose Your Journey</span>
          </div>
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Our Plans
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
            From essential travel tools to enterprise solutions, find the perfect plan for your adventures
          </p>
        </div>

        <div className="grid lg:grid-cols-4 md:grid-cols-2 gap-8 max-w-7xl mx-auto">
          {/* Free Plan */}
          <Card className="relative backdrop-blur-md bg-white/60 dark:bg-gray-900/60 border border-white/20 shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-1">
            <CardHeader className="text-center pb-6">
              <div className="mx-auto w-16 h-16 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-700 dark:to-gray-800 rounded-2xl flex items-center justify-center mb-4 shadow-lg">
                <Map className="w-8 h-8 text-gray-600 dark:text-gray-400" />
              </div>
              <CardTitle className="text-xl mb-2">Free</CardTitle>
              <div className="mb-4">
                <span className="text-4xl font-bold bg-gradient-to-br from-gray-700 to-gray-900 dark:from-gray-200 dark:to-gray-400 bg-clip-text text-transparent">₱0</span>
                <span className="text-gray-600 dark:text-gray-400 block text-sm">Essential features</span>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Search destinations, flights & hotels</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Simple itineraries</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Limited travel guides</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Last 3 trips</span>
                </li>
                <li className="flex items-start gap-3">
                  <Calendar className="w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">1 calendar</span>
                </li>
              </ul>
              <Button className="w-full bg-gradient-to-r from-gray-600 to-gray-700 hover:from-gray-700 hover:to-gray-800 text-white rounded-xl shadow-lg">
                Begin Journey
              </Button>
            </CardContent>
          </Card>

          {/* Traveler Plan */}
          <Card className="relative backdrop-blur-md bg-white/70 dark:bg-gray-900/70 border border-blue-200/50 shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-1">
            <CardHeader className="text-center pb-6">
              <div className="mx-auto w-16 h-16 bg-gradient-to-br from-blue-100 to-blue-200 dark:from-blue-900/50 dark:to-blue-800/50 rounded-2xl flex items-center justify-center mb-4 shadow-lg">
                <Plane className="w-8 h-8 text-blue-600 dark:text-blue-400" />
              </div>
              <CardTitle className="text-xl mb-2">Traveler</CardTitle>
              <div className="mb-4">
                <span className="text-4xl font-bold bg-gradient-to-br from-blue-600 to-blue-800 bg-clip-text text-transparent">₱250</span>
                <span className="text-gray-600 dark:text-gray-400 block text-sm">/month</span>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-3">
                  <Zap className="w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">AI recommendations</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Booking & cloud storage</span>
                </li>
                <li className="flex items-start gap-3">
                  <Calendar className="w-5 h-5 text-purple-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Multi-calendar</span>
                </li>
                <li className="flex items-start gap-3">
                  <Globe className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Offline access</span>
                </li>
                <li className="flex items-start gap-3">
                  <MessageSquare className="w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Priority support</span>
                </li>
              </ul>
              <Button className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white rounded-xl shadow-lg">
                Choose Plan
              </Button>
            </CardContent>
          </Card>

          {/* Premium Plan - Most Popular */}
          <Card className="relative backdrop-blur-md bg-gradient-to-br from-orange-50/80 to-pink-50/80 dark:from-orange-950/80 dark:to-pink-950/80 border-2 border-gradient-to-r from-orange-300 to-pink-300 shadow-2xl hover:shadow-3xl transition-all duration-300 hover:-translate-y-2 scale-105">
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
              <Badge className="bg-gradient-to-r from-orange-500 to-pink-500 text-white px-6 py-2 rounded-full shadow-lg">
                ⭐ Most Popular
              </Badge>
            </div>
            <CardHeader className="text-center pb-6 pt-8">
              <div className="mx-auto w-16 h-16 bg-gradient-to-br from-orange-100 to-pink-100 dark:from-orange-900/50 dark:to-pink-900/50 rounded-2xl flex items-center justify-center mb-4 shadow-lg">
                <Star className="w-8 h-8 text-orange-600 dark:text-orange-400 fill-current" />
              </div>
              <CardTitle className="text-xl mb-2">Premium</CardTitle>
              <div className="mb-4">
                <span className="text-4xl font-bold bg-gradient-to-br from-orange-600 to-pink-600 bg-clip-text text-transparent">₱499</span>
                <span className="text-gray-600 dark:text-gray-400 block text-sm">/month</span>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-3">
                  <Check className="w-5 h-5 text-emerald-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">All Traveler features</span>
                </li>
                <li className="flex items-start gap-3">
                  <Clock className="w-5 h-5 text-orange-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">24/7 concierge service</span>
                </li>
                <li className="flex items-start gap-3">
                  <Users className="w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Group travel (up to 10)</span>
                </li>
                <li className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Integrated travel insurance</span>
                </li>
                <li className="flex items-start gap-3">
                  <HeadphonesIcon className="w-5 h-5 text-purple-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Priority support</span>
                </li>
              </ul>
              <Button className="w-full bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600 text-white rounded-xl shadow-lg font-semibold">
                Start Premium Journey
              </Button>
            </CardContent>
          </Card>

          {/* Enterprise Plan */}
          <Card className="relative backdrop-blur-md bg-white/70 dark:bg-gray-900/70 border border-purple-200/50 shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-1">
            <CardHeader className="text-center pb-6">
              <div className="mx-auto w-16 h-16 bg-gradient-to-br from-purple-100 to-indigo-100 dark:from-purple-900/50 dark:to-indigo-900/50 rounded-2xl flex items-center justify-center mb-4 shadow-lg">
                <Building className="w-8 h-8 text-purple-600 dark:text-purple-400" />
              </div>
              <CardTitle className="text-xl mb-2">Enterprise</CardTitle>
              <div className="mb-4">
                <span className="text-4xl font-bold bg-gradient-to-br from-purple-600 to-indigo-600 bg-clip-text text-transparent">Custom</span>
                <span className="text-gray-600 dark:text-gray-400 block text-sm">For organizations</span>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <ul className="space-y-3 mb-8">
                <li className="flex items-start gap-3">
                  <Building className="w-5 h-5 text-purple-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Custom export & policies</span>
                </li>
                <li className="flex items-start gap-3">
                  <Users className="w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Unlimited groups</span>
                </li>
                <li className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Custom policies</span>
                </li>
                <li className="flex items-start gap-3">
                  <MessageSquare className="w-5 h-5 text-purple-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Dedicated account manager</span>
                </li>
                <li className="flex items-start gap-3">
                  <Globe className="w-5 h-5 text-indigo-500 mt-0.5 flex-shrink-0" />
                  <span className="text-sm">Multi-tenancy</span>
                </li>
              </ul>
              <Button className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl shadow-lg">
                Contact Sales
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Trust indicators and CTA */}
        <div className="mt-16 text-center">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 border border-white/20 shadow-lg">
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">
                Join thousands of travelers who trust NaviGo
              </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                All plans include secure cloud storage, mobile sync, and are designed to grow with your travel needs. 
                Enterprise customers get priority onboarding and custom integrations.
              </p>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">99.9%</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Uptime</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600 dark:text-green-400">24/7</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Support</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">30</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Day trial</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">50K+</div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Happy travelers</div>
                </div>
              </div>
              
              <div className="text-center">
                <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 rounded-xl shadow-lg">
                  Start Your Journey Today
                </Button>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                  No setup fees • Cancel anytime • 30-day money-back guarantee
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}