import { useState } from "react";
import React from "react";
import { Calendar, MapPin, Users, Clock, DollarSign, TrendingUp, Plane, Car, Hotel, FileText, Download, Share2, Compass, Building, History, User, Luggage } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { MyTrips } from "./MyTrips";
import { Explore } from "./Explore";
import { Profile } from "./Profile";

interface DashboardProps {
  onNavigate?: (view: string) => void;
}

export function Dashboard({ onNavigate }: DashboardProps = {}) {
  const [activeTab, setActiveTab] = useState("overview");
  const [isMobile, setIsMobile] = useState(false);

  // Check if mobile view
  React.useEffect(() => {
    let timeoutId: number;
    const checkMobile = () => {
      clearTimeout(timeoutId);
      timeoutId = window.setTimeout(() => {
        setIsMobile(window.innerWidth < 768);
      }, 100);
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener('resize', checkMobile);
    };
  }, []);

  const upcomingTrips = [
    {
      id: 1,
      destination: "Tokyo, Japan",
      dates: "Mar 15-22, 2024",
      status: "Confirmed",
      budget: "₱2,800",
      spent: "₱1,200",
      progress: 43,
      image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400",
      travelers: 2,
      bookings: ["Flight", "Hotel", "Rail Pass"]
    },
    {
      id: 2,
      destination: "Paris, France",
      dates: "May 10-17, 2024",
      status: "Planning",
      budget: "₱3,200",
      spent: "₱0",
      progress: 15,
      image: "https://images.unsplash.com/photo-1502602898536-47ad22581b52?w=400",
      travelers: 1,
      bookings: ["Hotel"]
    }
  ];

  const recentBookings = [
    { type: "flight", destination: "Tokyo", airline: "ANA", date: "Mar 15", status: "Confirmed", amount: "₱800" },
    { type: "hotel", destination: "Tokyo", name: "Park Hyatt Tokyo", date: "Mar 15-22", status: "Confirmed", amount: "₱400" },
    { type: "activity", destination: "Tokyo", name: "Tokyo Food Tour", date: "Mar 17", status: "Pending", amount: "₱120" }
  ];

  const teamMembers = [
    { name: "Sarah Johnson", email: "sarah@company.com", role: "Admin", trips: 12 },
    { name: "Mike Chen", email: "mike@company.com", role: "Traveler", trips: 8 },
    { name: "Emma Wilson", email: "emma@company.com", role: "Traveler", trips: 15 }
  ];

  return (
    <section className="py-4 md:py-8 bg-gradient-to-br from-sky-50 via-white to-violet-50 dark:from-slate-900 dark:via-slate-950 dark:to-violet-950 min-h-screen travel-pattern-1">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header - Mobile Optimized */}
        <div className="mb-6 md:mb-8">
          <div className="md:hidden mb-4 glass-card p-4 rounded-2xl">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-sky-500 to-teal-500 rounded-xl flex items-center justify-center shadow-lg">
                <User className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="font-semibold text-gray-900 dark:text-white">Welcome back, Anna!</h2>
                <p className="text-sm text-gray-600 dark:text-gray-400">Ready for your next adventure?</p>
              </div>
            </div>
          </div>
          
          <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white mb-1 md:mb-2">Travel Dashboard</h1>
          <p className="text-sm md:text-base text-gray-600 dark:text-gray-400">Manage your trips, bookings, and travel preferences in one place</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4 md:space-y-6">
          {/* Desktop Tabs */}
          <TabsList className="hidden md:grid w-full grid-cols-3 lg:grid-cols-4 lg:w-fit glass-card">
            <TabsTrigger value="overview" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-sky-500 data-[state=active]:to-teal-500 data-[state=active]:text-white">Overview</TabsTrigger>
            <TabsTrigger value="trips" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-sky-500 data-[state=active]:to-teal-500 data-[state=active]:text-white">My Trips</TabsTrigger>
            <TabsTrigger value="explore" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-sky-500 data-[state=active]:to-teal-500 data-[state=active]:text-white">Explore</TabsTrigger>
            <TabsTrigger value="profile" className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-sky-500 data-[state=active]:to-teal-500 data-[state=active]:text-white">Profile</TabsTrigger>
          </TabsList>
          
          {/* Mobile Tab Selector */}
          <div className="md:hidden">
            <div className="flex items-center justify-between mb-4 glass-card p-3 rounded-2xl">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white capitalize">{activeTab}</h2>
              <select 
                value={activeTab} 
                onChange={(e) => setActiveTab(e.target.value)}
                className="bg-transparent text-sm font-medium text-gray-700 dark:text-gray-300 border-0 focus:ring-0 cursor-pointer"
              >
                <option value="overview">Overview</option>
                <option value="trips">My Trips</option>
                <option value="explore">Explore</option>
                <option value="profile">Profile</option>
              </select>
            </div>
          </div>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4 md:space-y-6">
            {/* Stats Cards - Mobile Optimized */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
              <Card className="glass-card rounded-2xl shadow-lg border-0 p-1 md:p-0">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 md:pb-2 px-6 pt-6 md:px-6 md:pt-6">
                  <CardTitle className="text-base md:text-sm font-semibold">Total Trips</CardTitle>
                  <div className="w-10 h-10 md:w-8 md:h-8 bg-gradient-to-br from-sky-500 to-teal-500 rounded-xl flex items-center justify-center">
                    <Plane className="w-5 h-5 md:w-4 md:h-4 text-white" />
                  </div>
                </CardHeader>
                <CardContent className="px-6 pb-6 md:px-6 md:pb-6">
                  <div className="text-3xl md:text-2xl font-bold text-gray-900 dark:text-white">23</div>
                  <p className="text-sm md:text-xs text-gray-600 dark:text-gray-400 mt-1">+2 from last month</p>
                </CardContent>
              </Card>

              <Card className="glass-card rounded-2xl shadow-lg border-0 p-1 md:p-0">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 md:pb-2 px-6 pt-6 md:px-6 md:pt-6">
                  <CardTitle className="text-base md:text-sm font-semibold">This Year Spent</CardTitle>
                  <div className="w-10 h-10 md:w-8 md:h-8 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-xl flex items-center justify-center">
                    <DollarSign className="w-5 h-5 md:w-4 md:h-4 text-white" />
                  </div>
                </CardHeader>
                <CardContent className="px-6 pb-6 md:px-6 md:pb-6">
                  <div className="text-3xl md:text-2xl font-bold text-gray-900 dark:text-white">₱12,450</div>
                  <p className="text-sm md:text-xs text-gray-600 dark:text-gray-400 mt-1">+15% from last year</p>
                </CardContent>
              </Card>

              <Card className="glass-card rounded-2xl shadow-lg border-0 p-1 md:p-0">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 md:pb-2 px-6 pt-6 md:px-6 md:pt-6">
                  <CardTitle className="text-base md:text-sm font-semibold">Countries Visited</CardTitle>
                  <div className="w-10 h-10 md:w-8 md:h-8 bg-gradient-to-br from-violet-500 to-purple-500 rounded-xl flex items-center justify-center">
                    <MapPin className="w-5 h-5 md:w-4 md:h-4 text-white" />
                  </div>
                </CardHeader>
                <CardContent className="px-6 pb-6 md:px-6 md:pb-6">
                  <div className="text-3xl md:text-2xl font-bold text-gray-900 dark:text-white">12</div>
                  <p className="text-sm md:text-xs text-gray-600 dark:text-gray-400 mt-1">3 new this year</p>
                </CardContent>
              </Card>

              <Card className="glass-card rounded-2xl shadow-lg border-0 p-1 md:p-0">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3 md:pb-2 px-6 pt-6 md:px-6 md:pt-6">
                  <CardTitle className="text-base md:text-sm font-semibold">Savings</CardTitle>
                  <div className="w-10 h-10 md:w-8 md:h-8 bg-gradient-to-br from-orange-500 to-amber-500 rounded-xl flex items-center justify-center">
                    <TrendingUp className="w-5 h-5 md:w-4 md:h-4 text-white" />
                  </div>
                </CardHeader>
                <CardContent className="px-6 pb-6 md:px-6 md:pb-6">
                  <div className="text-3xl md:text-2xl font-bold text-gray-900 dark:text-white">₱2,100</div>
                  <p className="text-sm md:text-xs text-gray-600 dark:text-gray-400 mt-1">Through bulk discounts</p>
                </CardContent>
              </Card>
            </div>

            {/* Upcoming Trips - Mobile Optimized */}
            <Card className="glass-card rounded-2xl shadow-lg border-0">
              <CardHeader className="px-6 pt-6 pb-4">
                <CardTitle className="text-xl md:text-lg font-semibold text-gray-900 dark:text-white">Upcoming Trips</CardTitle>
              </CardHeader>
              <CardContent className="px-6 pb-6">
                <div className="space-y-4 md:space-y-4">
                  {upcomingTrips.map((trip) => (
                    <div key={trip.id} className="flex flex-col md:flex-row md:items-center space-y-4 md:space-y-0 md:space-x-4 p-4 md:p-4 bg-white/50 dark:bg-gray-800/50 rounded-2xl backdrop-blur-sm border border-gray-200/30 dark:border-gray-700/30">
                      <div className="flex items-start space-x-4 md:space-x-4">
                        <ImageWithFallback
                          src={trip.image}
                          alt={trip.destination}
                          className="w-20 h-20 md:w-16 md:h-16 rounded-xl object-cover shadow-md"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between mb-2">
                            <h3 className="text-lg md:text-base font-semibold text-gray-900 dark:text-white truncate">{trip.destination}</h3>
                            <Badge 
                              variant={trip.status === "Confirmed" ? "default" : "secondary"}
                              className={trip.status === "Confirmed" ? "bg-gradient-to-r from-emerald-500 to-teal-500 text-white" : ""}
                            >
                              {trip.status}
                            </Badge>
                          </div>
                          <p className="text-sm md:text-sm text-gray-600 dark:text-gray-400 mb-3">{trip.dates}</p>
                          <div className="flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-gray-500 dark:text-gray-400">
                            <span className="flex items-center gap-1">
                              <Users className="w-4 h-4" />
                              {trip.travelers} traveler{trip.travelers > 1 ? 's' : ''}
                            </span>
                            <span>Budget: {trip.budget}</span>
                            <span>Spent: {trip.spent}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="w-full md:w-auto">
                        <div className="mb-3">
                          <div className="flex justify-between text-sm mb-2">
                            <span className="font-medium text-gray-700 dark:text-gray-300">Trip Planning Progress</span>
                            <span className="font-semibold text-gray-900 dark:text-white">{trip.progress}%</span>
                          </div>
                          <Progress value={trip.progress} className="h-3 md:h-2" />
                        </div>
                        <div className="flex flex-col md:flex-col space-y-2 md:space-y-2">
                          <Button 
                            size="sm" 
                            className="bg-gradient-to-r from-sky-500 to-teal-500 hover:from-sky-600 hover:to-teal-600 text-white shadow-md min-h-[44px] md:min-h-auto active:scale-95 transition-transform duration-100"
                          >
                            View Journey
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="glass-card border-0 shadow-sm min-h-[44px] md:min-h-auto active:scale-95 transition-transform duration-100"
                          >
                            <Share2 className="w-4 h-4 mr-1" />
                            Share Trip
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions - Mobile Only */}
            <div className="md:hidden">
              <Card className="glass-card rounded-2xl shadow-lg border-0">
                <CardHeader className="px-6 pt-6 pb-4">
                  <CardTitle className="text-xl font-semibold text-gray-900 dark:text-white">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="px-6 pb-6">
                  <div className="grid grid-cols-2 gap-3">
                    <Button 
                      className="bg-gradient-to-r from-sky-500 to-teal-500 hover:from-sky-600 hover:to-teal-600 text-white shadow-lg rounded-xl py-4 h-auto"
                      onClick={() => onNavigate?.('plan-trip')}
                    >
                      <div className="flex flex-col items-center space-y-2">
                        <MapPin className="w-6 h-6" />
                        <span className="text-sm font-medium">Plan Trip</span>
                      </div>
                    </Button>
                    <Button 
                      variant="outline"
                      className="glass-card border-0 shadow-sm rounded-xl py-4 h-auto hover:shadow-md"
                      onClick={() => onNavigate?.('my-trips')}
                    >
                      <div className="flex flex-col items-center space-y-2">
                        <Luggage className="w-6 h-6 text-teal-600" />
                        <span className="text-sm font-medium">My Trips</span>
                      </div>
                    </Button>
                    <Button 
                      variant="outline"
                      className="glass-card border-0 shadow-sm rounded-xl py-4 h-auto hover:shadow-md"
                      onClick={() => onNavigate?.('explore')}
                    >
                      <div className="flex flex-col items-center space-y-2">
                        <Compass className="w-6 h-6 text-violet-600" />
                        <span className="text-sm font-medium">Explore</span>
                      </div>
                    </Button>
                    <Button 
                      variant="outline"
                      className="glass-card border-0 shadow-sm rounded-xl py-4 h-auto hover:shadow-md"
                      onClick={() => onNavigate?.('history')}
                    >
                      <div className="flex flex-col items-center space-y-2">
                        <History className="w-6 h-6 text-orange-600" />
                        <span className="text-sm font-medium">History</span>
                      </div>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Partner Demo Section - Mobile Optimized */}
            <Card className="glass-card rounded-2xl shadow-lg border-0">
              <CardHeader className="px-6 pt-6 pb-4">
                <CardTitle className="text-xl md:text-lg font-semibold text-gray-900 dark:text-white">Partner Network Demo</CardTitle>
              </CardHeader>
              <CardContent className="px-6 pb-6">
                <p className="text-gray-600 dark:text-gray-400 mb-6 text-base md:text-sm leading-relaxed">
                  Experience the NaviGo platform from a partner's perspective - see how airlines and hotels receive and manage booking requests.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 md:gap-4">
                  <Button 
                    variant="outline" 
                    className="flex items-center justify-center gap-3 p-4 md:p-3 glass-card border-0 shadow-sm rounded-xl hover:shadow-md transition-all duration-200"
                    onClick={() => onNavigate?.('partner-dashboard')}
                  >
                    <div className="w-8 h-8 md:w-6 md:h-6 bg-gradient-to-br from-sky-500 to-blue-500 rounded-lg flex items-center justify-center">
                      <Plane className="w-4 h-4 md:w-4 md:h-4 text-white" />
                    </div>
                    <span className="font-medium">Airline Dashboard</span>
                  </Button>
                  <Button 
                    variant="outline" 
                    className="flex items-center justify-center gap-3 p-4 md:p-3 glass-card border-0 shadow-sm rounded-xl hover:shadow-md transition-all duration-200"
                    onClick={() => onNavigate?.('partner-dashboard')}
                  >
                    <div className="w-8 h-8 md:w-6 md:h-6 bg-gradient-to-br from-emerald-500 to-teal-500 rounded-lg flex items-center justify-center">
                      <Hotel className="w-4 h-4 md:w-4 md:h-4 text-white" />
                    </div>
                    <span className="font-medium">Hotel Dashboard</span>
                  </Button>
                  <Button 
                    variant="outline" 
                    className="flex items-center justify-center gap-3 p-4 md:p-3 glass-card border-0 shadow-sm rounded-xl hover:shadow-md transition-all duration-200"
                    onClick={() => onNavigate?.('partner-dashboard')}
                  >
                    <div className="w-8 h-8 md:w-6 md:h-6 bg-gradient-to-br from-orange-500 to-amber-500 rounded-lg flex items-center justify-center">
                      <Car className="w-4 h-4 md:w-4 md:h-4 text-white" />
                    </div>
                    <span className="font-medium">Car Rental Dashboard</span>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Trips Tab */}
          <TabsContent value="trips">
            <MyTrips />
          </TabsContent>

          {/* Explore Tab */}
          <TabsContent value="explore">
            <Explore />
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile">
            <Profile />
          </TabsContent>

          {/* Bookings Tab */}
          <TabsContent value="bookings" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Recent Bookings</h2>
              <Button variant="outline">
                <FileText className="w-4 h-4 mr-2" />
                Export All
              </Button>
            </div>

            <Card>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 dark:bg-gray-800">
                      <tr>
                        <th className="text-left p-4 font-medium">Type</th>
                        <th className="text-left p-4 font-medium">Destination</th>
                        <th className="text-left p-4 font-medium">Details</th>
                        <th className="text-left p-4 font-medium">Date</th>
                        <th className="text-left p-4 font-medium">Status</th>
                        <th className="text-left p-4 font-medium">Amount</th>
                        <th className="text-left p-4 font-medium">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {recentBookings.map((booking, index) => (
                        <tr key={index} className="border-t">
                          <td className="p-4">
                            <div className="flex items-center gap-2">
                              {booking.type === 'flight' && <Plane className="w-4 h-4 text-blue-500" />}
                              {booking.type === 'hotel' && <Hotel className="w-4 h-4 text-green-500" />}
                              {booking.type === 'activity' && <MapPin className="w-4 h-4 text-orange-500" />}
                              <span className="capitalize">{booking.type}</span>
                            </div>
                          </td>
                          <td className="p-4">{booking.destination}</td>
                          <td className="p-4">
                            {booking.type === 'flight' && booking.airline}
                            {booking.type === 'hotel' && booking.name}
                            {booking.type === 'activity' && booking.name}
                          </td>
                          <td className="p-4">{booking.date}</td>
                          <td className="p-4">
                            <Badge variant={booking.status === "Confirmed" ? "default" : "secondary"}>
                              {booking.status}
                            </Badge>
                          </td>
                          <td className="p-4">{booking.amount}</td>
                          <td className="p-4">
                            <Button size="sm" variant="outline">
                              View
                            </Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Team Tab */}
          <TabsContent value="team" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Team Management</h2>
              <Button>Invite Team Member</Button>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Team Members</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {teamMembers.map((member, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-full flex items-center justify-center">
                          <span className="text-white font-medium">
                            {member.name.split(' ').map(n => n[0]).join('')}
                          </span>
                        </div>
                        <div>
                          <h3 className="font-medium">{member.name}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{member.email}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <Badge variant="outline">{member.role}</Badge>
                        <span className="text-sm text-gray-500 dark:text-gray-400">{member.trips} trips</span>
                        <Button size="sm" variant="outline">
                          Manage
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}