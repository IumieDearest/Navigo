import { useState } from "react";
import { Calendar, MapPin, Star, DollarSign, Clock, Download, Share2, Search, Filter, Camera, Plane, Hotel, Car } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function History() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filterYear, setFilterYear] = useState("all");
  const [filterType, setFilterType] = useState("all");

  const pastTrips = [
    {
      id: 1,
      destination: "Tokyo, Japan",
      country: "Japan",
      dates: "Oct 15-22, 2023",
      year: "2023",
      duration: "8 days",
      type: "leisure",
      totalCost: 2800,
      rating: 5,
      image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400",
      highlights: ["Cherry Blossoms", "Temples", "Sushi"],
      notes: "Amazing cultural experience. The food was incredible and the temples were breathtaking.",
      bookings: {
        flights: 2,
        hotels: 3,
        activities: 8,
        transport: 5
      },
      expenses: {
        flights: 1200,
        accommodation: 800,
        food: 450,
        activities: 250,
        transport: 100
      },
      photos: 127,
      favorite: true
    },
    {
      id: 2,
      destination: "Paris, France",
      country: "France",
      dates: "Jul 5-12, 2023",
      year: "2023",
      duration: "7 days",
      type: "leisure",
      totalCost: 3200,
      rating: 4,
      image: "https://images.unsplash.com/photo-1502602898536-47ad22581b52?w=400",
      highlights: ["Eiffel Tower", "Louvre", "Seine River"],
      notes: "Romantic getaway with amazing art and architecture. The Seine river cruise was magical.",
      bookings: {
        flights: 2,
        hotels: 2,
        activities: 6,
        transport: 3
      },
      expenses: {
        flights: 1400,
        accommodation: 1000,
        food: 500,
        activities: 200,
        transport: 100
      },
      photos: 89,
      favorite: false
    },
    {
      id: 3,
      destination: "New York, USA",
      country: "USA",
      dates: "Mar 10-14, 2023",
      year: "2023",
      duration: "5 days",
      type: "business",
      totalCost: 1800,
      rating: 4,
      image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=400",
      highlights: ["Business Conference", "Central Park", "Broadway"],
      notes: "Productive business trip with some leisure time. Caught a great Broadway show.",
      bookings: {
        flights: 2,
        hotels: 1,
        activities: 2,
        transport: 4
      },
      expenses: {
        flights: 800,
        accommodation: 600,
        food: 250,
        activities: 100,
        transport: 50
      },
      photos: 45,
      favorite: false
    },
    {
      id: 4,
      destination: "Barcelona, Spain",
      country: "Spain",
      dates: "Sep 20-27, 2022",
      year: "2022",
      duration: "7 days",
      type: "leisure",
      totalCost: 2400,
      rating: 5,
      image: "https://images.unsplash.com/photo-1539037116277-4db20889f2d4?w=400",
      highlights: ["Sagrada Familia", "Park Güell", "Tapas"],
      notes: "Gaudi's architecture was mind-blowing. The food scene exceeded all expectations.",
      bookings: {
        flights: 2,
        hotels: 2,
        activities: 7,
        transport: 2
      },
      expenses: {
        flights: 900,
        accommodation: 700,
        food: 400,
        activities: 300,
        transport: 100
      },
      photos: 156,
      favorite: true
    },
    {
      id: 5,
      destination: "Bali, Indonesia",
      country: "Indonesia",
      dates: "Dec 18-28, 2022",
      year: "2022",
      duration: "10 days",
      type: "leisure",
      totalCost: 2200,
      rating: 5,
      image: "https://images.unsplash.com/photo-1537953773345-d172ccf13cf1?w=400",
      highlights: ["Rice Terraces", "Beach Resorts", "Spa"],
      notes: "Perfect relaxation trip. The spa treatments and beach time were exactly what I needed.",
      bookings: {
        flights: 2,
        hotels: 3,
        activities: 5,
        transport: 3
      },
      expenses: {
        flights: 800,
        accommodation: 600,
        food: 300,
        activities: 350,
        transport: 150
      },
      photos: 203,
      favorite: true
    }
  ];

  const filteredTrips = pastTrips.filter(trip => {
    const matchesSearch = trip.destination.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         trip.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         trip.highlights.some(h => h.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesYear = filterYear === "all" || trip.year === filterYear;
    const matchesType = filterType === "all" || trip.type === filterType;
    return matchesSearch && matchesYear && matchesType;
  });

  const totalStats = {
    totalTrips: pastTrips.length,
    totalSpent: pastTrips.reduce((sum, trip) => sum + trip.totalCost, 0),
    countriesVisited: new Set(pastTrips.map(trip => trip.country)).size,
    totalDays: pastTrips.reduce((sum, trip) => sum + parseInt(trip.duration), 0),
    totalPhotos: pastTrips.reduce((sum, trip) => sum + trip.photos, 0),
    averageRating: pastTrips.reduce((sum, trip) => sum + trip.rating, 0) / pastTrips.length
  };

  const expenseCategories = pastTrips.reduce((acc, trip) => {
    Object.entries(trip.expenses).forEach(([category, amount]) => {
      acc[category] = (acc[category] || 0) + amount;
    });
    return acc;
  }, {} as Record<string, number>);

  const TripCard = ({ trip }: { trip: typeof pastTrips[0] }) => (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative">
        <ImageWithFallback
          src={trip.image}
          alt={trip.destination}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-4 left-4">
          <Badge variant={trip.type === "business" ? "default" : "secondary"}>
            {trip.type}
          </Badge>
        </div>
        <div className="absolute top-4 right-4 flex space-x-2">
          {trip.favorite && <Badge variant="outline" className="bg-white/80 backdrop-blur-sm">★ Favorite</Badge>}
          <Badge variant="outline" className="bg-white/80 backdrop-blur-sm">
            <Camera className="w-3 h-3 mr-1" />
            {trip.photos}
          </Badge>
        </div>
        <div className="absolute bottom-4 left-4">
          <div className="flex items-center space-x-1 text-white">
            {[...Array(5)].map((_, i) => (
              <Star 
                key={i} 
                className={`w-4 h-4 ${i < trip.rating ? 'fill-yellow-400 text-yellow-400' : 'text-white/50'}`} 
              />
            ))}
          </div>
        </div>
      </div>
      
      <CardContent className="p-6">
        <div className="mb-4">
          <h3 className="text-xl font-semibold mb-2">{trip.destination}</h3>
          <div className="flex items-center text-gray-600 space-x-4 text-sm">
            <span className="flex items-center gap-1">
              <Calendar className="w-4 h-4" />
              {trip.dates}
            </span>
            <span className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              {trip.duration}
            </span>
          </div>
        </div>

        <div className="mb-4">
          <p className="text-sm text-gray-600 italic">"{trip.notes}"</p>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <p className="text-sm text-gray-500">Total Cost</p>
            <p className="font-semibold">${trip.totalCost.toLocaleString()}</p>
          </div>
          <div>
            <p className="text-sm text-gray-500">Rating</p>
            <p className="font-semibold">{trip.rating}/5 stars</p>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-2 mb-4">
          <div className="text-center">
            <Plane className="w-5 h-5 mx-auto mb-1 text-blue-500" />
            <span className="text-xs font-medium">{trip.bookings.flights}</span>
          </div>
          <div className="text-center">
            <Hotel className="w-5 h-5 mx-auto mb-1 text-green-500" />
            <span className="text-xs font-medium">{trip.bookings.hotels}</span>
          </div>
          <div className="text-center">
            <Camera className="w-5 h-5 mx-auto mb-1 text-orange-500" />
            <span className="text-xs font-medium">{trip.bookings.activities}</span>
          </div>
          <div className="text-center">
            <Car className="w-5 h-5 mx-auto mb-1 text-purple-500" />
            <span className="text-xs font-medium">{trip.bookings.transport}</span>
          </div>
        </div>

        <div className="mb-4">
          <p className="text-sm text-gray-500 mb-2">Highlights</p>
          <div className="flex flex-wrap gap-1">
            {trip.highlights.map((highlight, index) => (
              <Badge key={index} variant="outline" className="text-xs">
                {highlight}
              </Badge>
            ))}
          </div>
        </div>

        <div className="flex space-x-2">
          <Button size="sm" className="flex-1">
            View Details
          </Button>
          <Button size="sm" variant="outline">
            <Share2 className="w-4 h-4" />
          </Button>
          <Button size="sm" variant="outline">
            <Download className="w-4 h-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold mb-2">Travel History</h2>
        <p className="text-gray-600">
          Your complete travel journey with memories, expenses, and insights
        </p>
      </div>

      {/* Travel Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{totalStats.totalTrips}</div>
            <p className="text-sm text-gray-600">Total Trips</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">${totalStats.totalSpent.toLocaleString()}</div>
            <p className="text-sm text-gray-600">Total Spent</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-600">{totalStats.countriesVisited}</div>
            <p className="text-sm text-gray-600">Countries</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-600">{totalStats.totalDays}</div>
            <p className="text-sm text-gray-600">Days Traveled</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-pink-600">{totalStats.totalPhotos}</div>
            <p className="text-sm text-gray-600">Photos</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-yellow-600">{totalStats.averageRating.toFixed(1)}</div>
            <p className="text-sm text-gray-600">Avg Rating</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="trips" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="trips">All Trips</TabsTrigger>
          <TabsTrigger value="expenses">Expense Analysis</TabsTrigger>
          <TabsTrigger value="insights">Travel Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="trips" className="space-y-6">
          {/* Filters and Search */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search destinations, countries, or highlights..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10"
              />
            </div>
            <Select value={filterYear} onValueChange={setFilterYear}>
              <SelectTrigger className="w-full sm:w-32">
                <SelectValue placeholder="Year" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Years</SelectItem>
                <SelectItem value="2023">2023</SelectItem>
                <SelectItem value="2022">2022</SelectItem>
                <SelectItem value="2021">2021</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="w-full sm:w-32">
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="leisure">Leisure</SelectItem>
                <SelectItem value="business">Business</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Filter className="w-4 h-4 mr-2" />
              More
            </Button>
          </div>

          {/* Trips Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTrips.map((trip) => (
              <TripCard key={trip.id} trip={trip} />
            ))}
          </div>

          {filteredTrips.length === 0 && (
            <div className="text-center py-12">
              <MapPin className="w-16 h-16 mx-auto text-gray-300 mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No trips found</h3>
              <p className="text-gray-500">Try adjusting your search criteria</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="expenses" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Expense Breakdown */}
            <Card>
              <CardHeader>
                <CardTitle>Expense Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {Object.entries(expenseCategories).map(([category, amount]) => (
                    <div key={category} className="flex justify-between items-center">
                      <span className="capitalize">{category}</span>
                      <span className="font-semibold">${amount.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Average Cost by Destination */}
            <Card>
              <CardHeader>
                <CardTitle>Cost by Trip</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {pastTrips.slice(0, 5).map((trip) => (
                    <div key={trip.id} className="flex justify-between items-center">
                      <div>
                        <p className="font-medium">{trip.destination}</p>
                        <p className="text-sm text-gray-500">{trip.dates}</p>
                      </div>
                      <span className="font-semibold">${trip.totalCost.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Export Options */}
          <Card>
            <CardHeader>
              <CardTitle>Export Options</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4">
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export CSV
                </Button>
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export PDF Report
                </Button>
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Tax Summary
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Travel Patterns</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600">Most Visited Season</p>
                  <p className="font-semibold">Summer (40% of trips)</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Average Trip Duration</p>
                  <p className="font-semibold">{Math.round(totalStats.totalDays / totalStats.totalTrips)} days</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Preferred Trip Type</p>
                  <p className="font-semibold">Leisure (80% of trips)</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Average Cost per Day</p>
                  <p className="font-semibold">${Math.round(totalStats.totalSpent / totalStats.totalDays)}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Favorite Destinations</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {pastTrips.filter(trip => trip.favorite).map((trip) => (
                  <div key={trip.id} className="flex items-center space-x-3">
                    <ImageWithFallback
                      src={trip.image}
                      alt={trip.destination}
                      className="w-12 h-12 rounded-lg object-cover"
                    />
                    <div>
                      <p className="font-medium">{trip.destination}</p>
                      <div className="flex items-center space-x-1">
                        {[...Array(trip.rating)].map((_, i) => (
                          <Star key={i} className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Budget Insights</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600">Most Expensive Trip</p>
                  <p className="font-semibold">Paris, France ($3,200)</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Best Value Trip</p>
                  <p className="font-semibold">Bali, Indonesia ($220/day)</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Biggest Expense Category</p>
                  <p className="font-semibold">Flights (38% of total)</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Travel Goals</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-sm text-gray-600">Next Milestone</p>
                  <p className="font-semibold">Visit 15 Countries (3 to go)</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Continents Visited</p>
                  <p className="font-semibold">4 out of 7</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600">Travel Streak</p>
                  <p className="font-semibold">3 years running</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}