import { Button } from "./ui/button";
import { Plane, Compass, MapPin, Globe, Star, ArrowRight, Users } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export function LandingHero() {
  return (
    <section className="relative min-h-[calc(100vh-8rem)] flex items-center overflow-hidden">
      {/* Abstract Background */}
      <div className="absolute inset-0 z-0">
        {/* Primary gradient */}
        <div className="absolute inset-0 bg-gradient-to-br from-sky-50 via-white to-violet-50 dark:from-slate-900 dark:via-slate-950 dark:to-violet-950" />
        
        {/* Layered abstract patterns */}
        <div className="absolute inset-0 travel-pattern-3" />
        
        {/* Large organic shapes */}
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-gradient-to-br from-sky-400/15 to-teal-400/10 rounded-full blur-3xl" />
        <div className="absolute top-1/2 -right-40 w-80 h-80 bg-gradient-to-bl from-violet-400/15 to-purple-400/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 left-1/3 w-72 h-72 bg-gradient-to-tr from-orange-400/10 to-yellow-400/10 rounded-full blur-3xl" />
        
        {/* Geometric accent shapes */}
        <div className="absolute top-20 left-20 w-32 h-32 bg-gradient-to-br from-sky-300/10 to-teal-300/5 transform rotate-45 rounded-2xl blur-sm" />
        <div className="absolute bottom-32 right-32 w-24 h-24 bg-gradient-to-br from-violet-300/10 to-purple-300/5 transform -rotate-12 rounded-2xl blur-sm" />
      </div>

      {/* Subtle geometric icons */}
      <div className="absolute inset-0 z-10 pointer-events-none overflow-hidden">
        <div className="absolute top-24 right-24 w-12 h-12 opacity-8">
          <Plane className="w-full h-full text-sky-600 dark:text-sky-400 transform rotate-45" />
        </div>
        <div className="absolute top-1/3 right-1/4 w-10 h-10 opacity-8">
          <Compass className="w-full h-full text-teal-600 dark:text-teal-400" />
        </div>
        <div className="absolute bottom-1/3 right-20 w-8 h-8 opacity-8">
          <Globe className="w-full h-full text-violet-600 dark:text-violet-400" />
        </div>
        <div className="absolute top-1/2 right-12 w-6 h-6 opacity-8">
          <MapPin className="w-full h-full text-orange-600 dark:text-orange-400" />
        </div>
        <div className="absolute bottom-24 right-1/3 w-6 h-6 opacity-8">
          <Star className="w-full h-full text-yellow-600 dark:text-yellow-400" />
        </div>
      </div>

      {/* Content */}
      <div className="relative z-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="max-w-4xl">
          {/* Travel Badge */}
          <div className="inline-flex items-center space-x-2 glass-card rounded-full px-6 py-3 mb-8">
            <div className="w-6 h-6 bg-gradient-to-br from-orange-500 to-yellow-500 rounded-full flex items-center justify-center">
              <Compass className="w-3 h-3 text-white" />
            </div>
            <span className="text-gray-700 dark:text-gray-300 text-sm font-medium">Your Adventure Starts Here</span>
            <div className="w-2 h-2 bg-gradient-to-r from-orange-400 to-yellow-400 rounded-full animate-pulse" />
          </div>

          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-8 leading-tight">
            <span className="block text-gray-900 dark:text-white mb-2">Discover Your Next</span>
            <span className="bg-gradient-to-r from-sky-600 via-teal-600 to-violet-600 dark:from-sky-400 dark:via-teal-400 dark:to-violet-400 bg-clip-text text-transparent">
              Epic Adventure
            </span>
          </h1>

          <p className="text-xl md:text-2xl text-gray-600 dark:text-gray-300 mb-10 max-w-3xl leading-relaxed">
            Unlock intelligent travel planning with AI-powered recommendations, seamless collaboration, and cost optimization. 
            Turn your wanderlust into unforgettable journeys.
          </p>

          {/* Feature Pills */}
          <div className="flex flex-wrap gap-3 mb-10">
            <div className="flex items-center space-x-2 glass-card rounded-full px-4 py-2">
              <div className="w-2 h-2 bg-gradient-to-r from-sky-500 to-sky-400 rounded-full" />
              <span className="text-gray-700 dark:text-gray-300 text-sm">AI-Powered Planning</span>
            </div>
            <div className="flex items-center space-x-2 glass-card rounded-full px-4 py-2">
              <div className="w-2 h-2 bg-gradient-to-r from-teal-500 to-teal-400 rounded-full" />
              <span className="text-gray-700 dark:text-gray-300 text-sm">Group Collaboration</span>
            </div>
            <div className="flex items-center space-x-2 glass-card rounded-full px-4 py-2">
              <div className="w-2 h-2 bg-gradient-to-r from-orange-500 to-orange-400 rounded-full" />
              <span className="text-gray-700 dark:text-gray-300 text-sm">Smart Savings</span>
            </div>
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button 
              size="lg"
              className="bg-gradient-to-r from-sky-500 to-teal-500 hover:from-sky-600 hover:to-teal-600 text-white px-8 py-4 text-lg font-semibold rounded-xl shadow-2xl transform hover:scale-105 transition-all duration-300 group"
            >
              <Plane className="w-5 h-5 mr-2 group-hover:translate-x-1 transition-transform" />
              Start Your Journey
              <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
            
            <Button 
              variant="outline"
              size="lg"
              className="glass-card border-2 border-gray-200/50 dark:border-gray-700/50 text-gray-700 dark:text-gray-300 hover:bg-white/80 dark:hover:bg-black/80 px-8 py-4 text-lg font-semibold rounded-xl transition-all duration-300"
            >
              <MapPin className="w-5 h-5 mr-2" />
              Explore Features
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="mt-12 flex items-center space-x-8 text-gray-500 dark:text-gray-400">
            <div className="flex items-center space-x-2">
              <Star className="w-5 h-5 text-yellow-500 fill-current" />
              <span className="text-sm">4.9/5 Rating</span>
            </div>
            <div className="flex items-center space-x-2">
              <Users className="w-5 h-5" />
              <span className="text-sm">50K+ Travelers</span>
            </div>
            <div className="flex items-center space-x-2">
              <Globe className="w-5 h-5" />
              <span className="text-sm">190+ Countries</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}