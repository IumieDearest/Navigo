import { useState } from "react";
import {
  User,
  Settings,
  Bell,
  CreditCard,
  Globe,
  Shield,
  Camera,
  Edit,
  Save,
  X,
  MapPin,
  Calendar,
  Phone,
  Mail,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Switch } from "./ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "./ui/tabs";
import { Textarea } from "./ui/textarea";
import { Separator } from "./ui/separator";

export function Profile() {
  const [isEditing, setIsEditing] = useState(false);
  const [profileData, setProfileData] = useState({
    firstName: "Anna Mae",
    lastName: "Regis",
    email: "aregis_ccs@uspf.edu.ph",
    phone: "(+63)953 062-4663",
    location: "Cebu City, Philippines",
    bio: "Passionate traveler exploring the world one destination at a time. Love experiencing new cultures and cuisines.",
    timezone: "Pacific Standard Time",
    dateFormat: "MM/DD/YYYY",
    currency: "USD",
  });

  const [preferences, setPreferences] = useState({
    flightClass: "first alss",
    seatPreference: "window",
    mealPreference: "meatatarian",
    hotelStarRating: "5-star",
    hotelRoomType: "single",
    budgetRange: "mid-range",
    travelStyle: "leisure",
    activityLevel: "moderate",
  });

  const [notifications, setNotifications] = useState({
    emailBookingConfirmations: true,
    emailPriceAlerts: true,
    emailTravelReminders: true,
    pushNotifications: true,
    smsAlerts: false,
    marketingEmails: false,
    weeklyDigest: true,
  });

  const [security, setSecurity] = useState({
    twoFactorAuth: true,
    loginAlerts: true,
    dataSharing: false,
    profileVisibility: "private",
  });

  const travelStats = {
    totalTrips: 23,
    countriesVisited: 12,
    totalSpent: 45600,
    totalMiles: 125000,
    favoriteDestination: "Tokyo, Japan",
    nextTrip: "Nanning, Guangxi, China",
  };

  const achievements = [
    {
      name: "Globe Trotter",
      description: "Visited 10+ countries",
      earned: true,
    },
    {
      name: "Budget Master",
      description: "Saved $5000+ with smart booking",
      earned: true,
    },
    {
      name: "Frequent Flyer",
      description: "100,000+ miles traveled",
      earned: true,
    },
    {
      name: "Adventure Seeker",
      description: "Tried 20+ activities",
      earned: false,
    },
    {
      name: "Cultural Explorer",
      description: "Visited 5+ UNESCO sites",
      earned: false,
    },
  ];

  const handleSave = () => {
    setIsEditing(false);
    // Here you would typically save to backend
  };

  const handleCancel = () => {
    setIsEditing(false);
    // Reset form data to original values
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold">
            Profile Settings
          </h2>
          <p className="text-gray-600">
            Manage your account preferences and travel settings
          </p>
        </div>
        <div className="flex gap-2">
          {isEditing ? (
            <>
              <Button variant="outline" onClick={handleCancel}>
                <X className="w-4 h-4 mr-2" />
                Cancel
              </Button>
              <Button onClick={handleSave}>
                <Save className="w-4 h-4 mr-2" />
                Save Changes
              </Button>
            </>
          ) : (
            <Button onClick={() => setIsEditing(true)}>
              <Edit className="w-4 h-4 mr-2" />
              Edit Profile
            </Button>
          )}
        </div>
      </div>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="preferences">Travel</TabsTrigger>
          <TabsTrigger value="notifications">
            Notifications
          </TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="billing">Billing</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Profile Info */}
            <div className="lg:col-span-2 space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Personal Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-4 mb-6">
                    <div className="w-20 h-20 bg-gradient-to-br from-cyan-400 to-blue-500 rounded-full flex items-center justify-center">
                      <User className="w-10 h-10 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold">
                        {profileData.firstName}{" "}
                        {profileData.lastName}
                      </h3>
                      <p className="text-gray-600">
                        {profileData.email}
                      </p>
                      <Badge className="bg-orange-100 text-orange-800 mt-1">
                        Premium Member
                      </Badge>
                    </div>
                    <Button size="sm" variant="outline">
                      <Camera className="w-4 h-4 mr-2" />
                      Change Photo
                    </Button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">
                        First Name
                      </Label>
                      <Input
                        id="firstName"
                        value={profileData.firstName}
                        onChange={(e) =>
                          setProfileData({
                            ...profileData,
                            firstName: e.target.value,
                          })
                        }
                        disabled={!isEditing}
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName">
                        Last Name
                      </Label>
                      <Input
                        id="lastName"
                        value={profileData.lastName}
                        onChange={(e) =>
                          setProfileData({
                            ...profileData,
                            lastName: e.target.value,
                          })
                        }
                        disabled={!isEditing}
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">
                        Email Address
                      </Label>
                      <Input
                        id="email"
                        type="email"
                        value={profileData.email}
                        onChange={(e) =>
                          setProfileData({
                            ...profileData,
                            email: e.target.value,
                          })
                        }
                        disabled={!isEditing}
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">
                        Phone Number
                      </Label>
                      <Input
                        id="phone"
                        value={profileData.phone}
                        onChange={(e) =>
                          setProfileData({
                            ...profileData,
                            phone: e.target.value,
                          })
                        }
                        disabled={!isEditing}
                      />
                    </div>
                    <div>
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        value={profileData.location}
                        onChange={(e) =>
                          setProfileData({
                            ...profileData,
                            location: e.target.value,
                          })
                        }
                        disabled={!isEditing}
                      />
                    </div>
                    <div>
                      <Label htmlFor="timezone">Timezone</Label>
                      <Select
                        value={profileData.timezone}
                        onValueChange={(value) =>
                          setProfileData({
                            ...profileData,
                            timezone: value,
                          })
                        }
                        disabled={!isEditing}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Pacific Standard Time">
                            Pacific Standard Time
                          </SelectItem>
                          <SelectItem value="Mountain Standard Time">
                            Mountain Standard Time
                          </SelectItem>
                          <SelectItem value="Central Standard Time">
                            Central Standard Time
                          </SelectItem>
                          <SelectItem value="Eastern Standard Time">
                            Eastern Standard Time
                          </SelectItem>
                          <SelectItem value="Greenwich Mean Time">
                            Greenwich Mean Time
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea
                      id="bio"
                      value={profileData.bio}
                      onChange={(e) =>
                        setProfileData({
                          ...profileData,
                          bio: e.target.value,
                        })
                      }
                      disabled={!isEditing}
                      rows={3}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Regional Settings */}
              <Card>
                <CardHeader>
                  <CardTitle>Regional Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Date Format</Label>
                      <Select
                        value={profileData.dateFormat}
                        onValueChange={(value) =>
                          setProfileData({
                            ...profileData,
                            dateFormat: value,
                          })
                        }
                        disabled={!isEditing}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="MM/DD/YYYY">
                            MM/DD/YYYY
                          </SelectItem>
                          <SelectItem value="DD/MM/YYYY">
                            DD/MM/YYYY
                          </SelectItem>
                          <SelectItem value="YYYY-MM-DD">
                            YYYY-MM-DD
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Currency</Label>
                      <Select
                        value={profileData.currency}
                        onValueChange={(value) =>
                          setProfileData({
                            ...profileData,
                            currency: value,
                          })
                        }
                        disabled={!isEditing}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="USD">
                            USD - US Dollar
                          </SelectItem>
                          <SelectItem value="EUR">
                            EUR - Euro
                          </SelectItem>
                          <SelectItem value="GBP">
                            GBP - British Pound
                          </SelectItem>
                          <SelectItem value="JPY">
                            JPY - Japanese Yen
                          </SelectItem>
                          <SelectItem value="CAD">
                            CAD - Canadian Dollar
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Travel Stats & Achievements */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Travel Stats</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">
                        {travelStats.totalTrips}
                      </div>
                      <p className="text-sm text-gray-600">
                        Total Trips
                      </p>
                    </div>
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">
                        {travelStats.countriesVisited}
                      </div>
                      <p className="text-sm text-gray-600">
                        Countries
                      </p>
                    </div>
                    <div className="text-center p-3 bg-purple-50 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">
                        $
                        {(
                          travelStats.totalSpent / 1000
                        ).toFixed(0)}
                        K
                      </div>
                      <p className="text-sm text-gray-600">
                        Total Spent
                      </p>
                    </div>
                    <div className="text-center p-3 bg-orange-50 rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">
                        {(
                          travelStats.totalMiles / 1000
                        ).toFixed(0)}
                        K
                      </div>
                      <p className="text-sm text-gray-600">
                        Miles
                      </p>
                    </div>
                  </div>
                  <Separator />
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <MapPin className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-600">
                        Favorite Destination
                      </span>
                    </div>
                    <p className="font-medium">
                      {travelStats.favoriteDestination}
                    </p>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-2">
                      <Calendar className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-600">
                        Next Trip
                      </span>
                    </div>
                    <p className="font-medium">
                      {travelStats.nextTrip}
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Achievements</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {achievements.map((achievement, index) => (
                      <div
                        key={index}
                        className={`flex items-center space-x-3 p-3 rounded-lg ${achievement.earned ? "bg-green-50" : "bg-gray-50"}`}
                      >
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center ${achievement.earned ? "bg-green-500" : "bg-gray-300"}`}
                        >
                          {achievement.earned ? "★" : "☆"}
                        </div>
                        <div className="flex-1">
                          <p
                            className={`font-medium ${achievement.earned ? "text-green-800" : "text-gray-600"}`}
                          >
                            {achievement.name}
                          </p>
                          <p className="text-xs text-gray-500">
                            {achievement.description}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="preferences" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Flight Preferences</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Preferred Class</Label>
                  <Select
                    value={preferences.flightClass}
                    onValueChange={(value) =>
                      setPreferences({
                        ...preferences,
                        flightClass: value,
                      })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="economy">
                        Economy
                      </SelectItem>
                      <SelectItem value="premium-economy">
                        Premium Economy
                      </SelectItem>
                      <SelectItem value="business">
                        Business
                      </SelectItem>
                      <SelectItem value="first">
                        First Class
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Seat Preference</Label>
                  <Select
                    value={preferences.seatPreference}
                    onValueChange={(value) =>
                      setPreferences({
                        ...preferences,
                        seatPreference: value,
                      })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="window">
                        Window
                      </SelectItem>
                      <SelectItem value="aisle">
                        Aisle
                      </SelectItem>
                      <SelectItem value="middle">
                        Middle
                      </SelectItem>
                      <SelectItem value="no-preference">
                        No Preference
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Meal Preference</Label>
                  <Select
                    value={preferences.mealPreference}
                    onValueChange={(value) =>
                      setPreferences({
                        ...preferences,
                        mealPreference: value,
                      })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="standard">
                        Standard
                      </SelectItem>
                      <SelectItem value="vegetarian">
                        Vegetarian
                      </SelectItem>
                      <SelectItem value="vegan">
                        Vegan
                      </SelectItem>
                      <SelectItem value="kosher">
                        Kosher
                      </SelectItem>
                      <SelectItem value="halal">
                        Halal
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Hotel Preferences</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Star Rating</Label>
                  <Select
                    value={preferences.hotelStarRating}
                    onValueChange={(value) =>
                      setPreferences({
                        ...preferences,
                        hotelStarRating: value,
                      })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="3-star">
                        3-Star
                      </SelectItem>
                      <SelectItem value="4-star">
                        4-Star
                      </SelectItem>
                      <SelectItem value="5-star">
                        5-Star
                      </SelectItem>
                      <SelectItem value="luxury">
                        Luxury
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Room Type</Label>
                  <Select
                    value={preferences.hotelRoomType}
                    onValueChange={(value) =>
                      setPreferences({
                        ...preferences,
                        hotelRoomType: value,
                      })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="single">
                        Single
                      </SelectItem>
                      <SelectItem value="double">
                        Double
                      </SelectItem>
                      <SelectItem value="suite">
                        Suite
                      </SelectItem>
                      <SelectItem value="family">
                        Family Room
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Budget Range</Label>
                  <Select
                    value={preferences.budgetRange}
                    onValueChange={(value) =>
                      setPreferences({
                        ...preferences,
                        budgetRange: value,
                      })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="budget">
                        Budget ($50-100/night)
                      </SelectItem>
                      <SelectItem value="mid-range">
                        Mid-range ($100-250/night)
                      </SelectItem>
                      <SelectItem value="luxury">
                        Luxury ($250+/night)
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Travel Style</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Travel Type</Label>
                  <Select
                    value={preferences.travelStyle}
                    onValueChange={(value) =>
                      setPreferences({
                        ...preferences,
                        travelStyle: value,
                      })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="leisure">
                        Leisure
                      </SelectItem>
                      <SelectItem value="business">
                        Business
                      </SelectItem>
                      <SelectItem value="adventure">
                        Adventure
                      </SelectItem>
                      <SelectItem value="cultural">
                        Cultural
                      </SelectItem>
                      <SelectItem value="romantic">
                        Romantic
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Activity Level</Label>
                  <Select
                    value={preferences.activityLevel}
                    onValueChange={(value) =>
                      setPreferences({
                        ...preferences,
                        activityLevel: value,
                      })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="relaxed">
                        Relaxed
                      </SelectItem>
                      <SelectItem value="moderate">
                        Moderate
                      </SelectItem>
                      <SelectItem value="active">
                        Active
                      </SelectItem>
                      <SelectItem value="adventurous">
                        Adventurous
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent
          value="notifications"
          className="space-y-6"
        >
          <Card>
            <CardHeader>
              <CardTitle>Notification Preferences</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h4 className="font-medium mb-4">
                  Email Notifications
                </h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">
                        Booking Confirmations
                      </p>
                      <p className="text-sm text-gray-600">
                        Receive confirmation emails for all
                        bookings
                      </p>
                    </div>
                    <Switch
                      checked={
                        notifications.emailBookingConfirmations
                      }
                      onCheckedChange={(checked) =>
                        setNotifications({
                          ...notifications,
                          emailBookingConfirmations: checked,
                        })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">
                        Price Alerts
                      </p>
                      <p className="text-sm text-gray-600">
                        Get notified when prices drop for your
                        watched trips
                      </p>
                    </div>
                    <Switch
                      checked={notifications.emailPriceAlerts}
                      onCheckedChange={(checked) =>
                        setNotifications({
                          ...notifications,
                          emailPriceAlerts: checked,
                        })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">
                        Travel Reminders
                      </p>
                      <p className="text-sm text-gray-600">
                        Reminders about upcoming trips and
                        check-ins
                      </p>
                    </div>
                    <Switch
                      checked={
                        notifications.emailTravelReminders
                      }
                      onCheckedChange={(checked) =>
                        setNotifications({
                          ...notifications,
                          emailTravelReminders: checked,
                        })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">
                        Weekly Digest
                      </p>
                      <p className="text-sm text-gray-600">
                        Weekly summary of travel deals and
                        recommendations
                      </p>
                    </div>
                    <Switch
                      checked={notifications.weeklyDigest}
                      onCheckedChange={(checked) =>
                        setNotifications({
                          ...notifications,
                          weeklyDigest: checked,
                        })
                      }
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h4 className="font-medium mb-4">
                  Mobile Notifications
                </h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">
                        Push Notifications
                      </p>
                      <p className="text-sm text-gray-600">
                        Allow push notifications on mobile
                        devices
                      </p>
                    </div>
                    <Switch
                      checked={notifications.pushNotifications}
                      onCheckedChange={(checked) =>
                        setNotifications({
                          ...notifications,
                          pushNotifications: checked,
                        })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">SMS Alerts</p>
                      <p className="text-sm text-gray-600">
                        Critical travel alerts via SMS
                      </p>
                    </div>
                    <Switch
                      checked={notifications.smsAlerts}
                      onCheckedChange={(checked) =>
                        setNotifications({
                          ...notifications,
                          smsAlerts: checked,
                        })
                      }
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h4 className="font-medium mb-4">Marketing</h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">
                        Marketing Emails
                      </p>
                      <p className="text-sm text-gray-600">
                        Promotional offers and travel
                        inspiration
                      </p>
                    </div>
                    <Switch
                      checked={notifications.marketingEmails}
                      onCheckedChange={(checked) =>
                        setNotifications({
                          ...notifications,
                          marketingEmails: checked,
                        })
                      }
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h4 className="font-medium mb-4">
                  Account Security
                </h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">
                        Two-Factor Authentication
                      </p>
                      <p className="text-sm text-gray-600">
                        Add an extra layer of security to your
                        account
                      </p>
                    </div>
                    <Switch
                      checked={security.twoFactorAuth}
                      onCheckedChange={(checked) =>
                        setSecurity({
                          ...security,
                          twoFactorAuth: checked,
                        })
                      }
                    />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">
                        Login Alerts
                      </p>
                      <p className="text-sm text-gray-600">
                        Get notified of new device logins
                      </p>
                    </div>
                    <Switch
                      checked={security.loginAlerts}
                      onCheckedChange={(checked) =>
                        setSecurity({
                          ...security,
                          loginAlerts: checked,
                        })
                      }
                    />
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h4 className="font-medium mb-4">
                  Privacy Settings
                </h4>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">
                        Data Sharing
                      </p>
                      <p className="text-sm text-gray-600">
                        Allow anonymized data sharing for
                        service improvement
                      </p>
                    </div>
                    <Switch
                      checked={security.dataSharing}
                      onCheckedChange={(checked) =>
                        setSecurity({
                          ...security,
                          dataSharing: checked,
                        })
                      }
                    />
                  </div>
                  <div>
                    <Label>Profile Visibility</Label>
                    <Select
                      value={security.profileVisibility}
                      onValueChange={(value) =>
                        setSecurity({
                          ...security,
                          profileVisibility: value,
                        })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="private">
                          Private
                        </SelectItem>
                        <SelectItem value="friends">
                          Friends Only
                        </SelectItem>
                        <SelectItem value="public">
                          Public
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <Separator />

              <div>
                <h4 className="font-medium mb-4">Password</h4>
                <Button variant="outline">
                  Change Password
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="billing" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Current Plan</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-orange-50 rounded-lg border border-orange-200">
                    <h3 className="font-semibold text-orange-800">
                      Premium Plan
                    </h3>
                    <p className="text-orange-700">$25/month</p>
                    <p className="text-sm text-orange-600 mt-2">
                      Unlimited trips, group collaboration,
                      priority support
                    </p>
                  </div>
                  <div className="text-sm text-gray-600">
                    <p>Next billing date: April 15, 2024</p>
                    <p>Plan renews automatically</p>
                  </div>
                  <div className="flex space-x-2">
                    <Button variant="outline">
                      Change Plan
                    </Button>
                    <Button variant="outline">
                      Cancel Subscription
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Payment Methods</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <CreditCard className="w-8 h-8 text-gray-400" />
                      <div>
                        <p className="font-medium">
                          •••• •••• •••• 4242
                        </p>
                        <p className="text-sm text-gray-600">
                          Expires 12/25
                        </p>
                      </div>
                    </div>
                    <Badge>Primary</Badge>
                  </div>
                  <Button variant="outline" className="w-full">
                    Add Payment Method
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>Billing History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">
                        Premium Plan
                      </p>
                      <p className="text-sm text-gray-600">
                        March 15, 2024
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">$25.00</p>
                      <Button size="sm" variant="outline">
                        Download
                      </Button>
                    </div>
                  </div>
                  <div className="flex justify-between items-center p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">
                        Premium Plan
                      </p>
                      <p className="text-sm text-gray-600">
                        February 15, 2024
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">$25.00</p>
                      <Button size="sm" variant="outline">
                        Download
                      </Button>
                    </div>
                  </div>
                  <div className="flex justify-between items-center p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">
                        Premium Plan
                      </p>
                      <p className="text-sm text-gray-600">
                        January 15, 2024
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">$25.00</p>
                      <Button size="sm" variant="outline">
                        Download
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}