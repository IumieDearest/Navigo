import { useState } from "react";
import { 
  Plane, Hotel, Car, Bell, Settings, BarChart3, Users, 
  TrendingUp, Calendar, MapPin, CreditCard, Check, X, 
  AlertCircle, Clock, Star, Filter, Search, Utensils, Bus,
  Activity, Shield, Anchor, Briefcase, Package, Globe,
  Plus, Building2, Award, Eye, MessageCircle, FileText,
  Target, DollarSign, UserCheck, ArrowUpRight, PieChart,
  LineChart, TrendingDown, Zap, Crown, Diamond
} from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { BusinessSpecificSettings } from "./BusinessSpecificSettings";
import { NaviGoLogoCircular } from "./NaviGoLogoCircular";

interface BookingRequest {
  id: string;
  type: "flight" | "hotel" | "car";
  customerName: string;
  customerEmail: string;
  details: {
    from?: string;
    to?: string;
    checkIn?: string;
    checkOut?: string;
    passengers?: number;
    guests?: number;
    roomType?: string;
    flightClass?: string;
  };
  requestedPrice: number;
  status: "pending" | "accepted" | "declined" | "negotiating";
  timestamp: string;
  priority: "high" | "medium" | "low";
}

interface PartnerDashboardProps {
  partnerType: string;
  partnerName: string;
}

export function PartnerDashboardUpdated({ partnerType, partnerName }: PartnerDashboardProps) {
  const [activeTab, setActiveTab] = useState("requests");
  const [statusFilter, setStatusFilter] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  // Get business type specific configuration
  const getBusinessConfig = (type: string) => {
    switch (type) {
      case 'airline':
        return {
          icon: Plane,
          primaryColor: 'indigo',
          serviceName: 'Airlines',
          tier: 'Premium Partner',
          tierIcon: Crown,
          features: ['Route Management', 'Fleet Analytics', 'Passenger Services', 'Pricing Optimization']
        };
      case 'hotel':
        return {
          icon: Hotel,
          primaryColor: 'purple',
          serviceName: 'Hospitality',
          tier: 'Elite Partner',
          tierIcon: Diamond,
          features: ['Room Management', 'Occupancy Analytics', 'Guest Services', 'Revenue Management']
        };
      case 'car-rental':
        return {
          icon: Car,
          primaryColor: 'emerald',
          serviceName: 'Vehicle Rentals',
          tier: 'Verified Partner',
          tierIcon: Award,
          features: ['Fleet Management', 'Rental Analytics', 'Customer Services', 'Maintenance Tracking']
        };
      default:
        return {
          icon: Package,
          primaryColor: 'slate',
          serviceName: 'Travel Services',
          tier: 'Standard Partner',
          tierIcon: Award,
          features: ['Service Management', 'Booking System', 'Customer Support', 'Analytics Dashboard']
        };
    }
  };

  const businessConfig = getBusinessConfig(partnerType);

  const [bookingRequests, setBookingRequests] = useState<BookingRequest[]>([
    {
      id: "BR-001",
      type: "flight",
      customerName: "Anna Mae Regis",
      customerEmail: "anna.regis@email.com",
      details: {
        from: "New York (JFK)",
        to: "Paris (CDG)",
        passengers: 2,
        flightClass: "Business"
      },
      requestedPrice: 2400,
      status: "pending",
      timestamp: "2 hours ago",
      priority: "high"
    },
    {
      id: "BR-002",
      type: "flight",
      customerName: "John Smith",
      customerEmail: "john.smith@email.com",
      details: {
        from: "Los Angeles (LAX)",
        to: "London (LHR)",
        passengers: 1,
        flightClass: "Premium Economy"
      },
      requestedPrice: 1800,
      status: "pending",
      timestamp: "4 hours ago",
      priority: "medium"
    },
    {
      id: "BR-003",
      type: "flight",
      customerName: "Sarah Johnson",
      customerEmail: "sarah.j@email.com",
      details: {
        from: "London (LHR)",
        to: "Tokyo (NRT)",
        passengers: 1,
        flightClass: "Economy"
      },
      requestedPrice: 850,
      status: "negotiating",
      timestamp: "1 day ago",
      priority: "low"
    },
    {
      id: "BR-004",
      type: "flight",
      customerName: "Michael Chen",
      customerEmail: "m.chen@email.com",
      details: {
        from: "San Francisco (SFO)",
        to: "Amsterdam (AMS)",
        passengers: 3,
        flightClass: "Business"
      },
      requestedPrice: 4200,
      status: "accepted",
      timestamp: "2 days ago",
      priority: "high"
    }
  ]);

  const handleStatusChange = (requestId: string, newStatus: BookingRequest["status"]) => {
    setBookingRequests(requests => 
      requests.map(request => 
        request.id === requestId ? { ...request, status: newStatus } : request
      )
    );
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "flight": return Plane;
      case "hotel": return Hotel;
      case "car": return Car;
      default: return Plane;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-50 text-red-700 border border-red-200";
      case "medium": return "bg-amber-50 text-amber-700 border border-amber-200";
      case "low": return "bg-emerald-50 text-emerald-700 border border-emerald-200";
      default: return "bg-gray-50 text-gray-700 border border-gray-200";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending": return "bg-blue-50 text-blue-700 border border-blue-200";
      case "accepted": return "bg-emerald-50 text-emerald-700 border border-emerald-200";
      case "declined": return "bg-red-50 text-red-700 border border-red-200";
      case "negotiating": return "bg-purple-50 text-purple-700 border border-purple-200";
      default: return "bg-gray-50 text-gray-700 border border-gray-200";
    }
  };

  const filteredRequests = bookingRequests.filter(request => {
    const matchesStatus = statusFilter === "all" || request.status === statusFilter;
    const matchesSearch = request.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         request.customerEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         request.id.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const stats = {
    totalRequests: bookingRequests.length,
    pendingRequests: bookingRequests.filter(r => r.status === "pending").length,
    acceptedRequests: bookingRequests.filter(r => r.status === "accepted").length,
    revenue: "₱248,650"
  };

  const BusinessIcon = businessConfig.icon;
  const TierIcon = businessConfig.tierIcon;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-indigo-50/30 dark:from-slate-900 dark:via-slate-950 dark:to-indigo-950/30">
      {/* Enterprise Header */}
      <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 shadow-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col lg:flex-row lg:items-center gap-6">
            {/* Business Profile Card */}
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 border border-white/20 flex-1">
              <div className="flex items-center gap-4">
                <div className="relative">
                  <div className="w-16 h-16 bg-white rounded-xl flex items-center justify-center shadow-lg">
                    <NaviGoLogoCircular className="w-10 h-10" />
                  </div>
                  <div className="absolute -top-1 -right-1 w-6 h-6 bg-gradient-to-r from-emerald-400 to-teal-400 rounded-full flex items-center justify-center">
                    <TierIcon className="w-3 h-3 text-white" />
                  </div>
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-1">
                    <h1 className="text-2xl font-bold text-white">{partnerName}</h1>
                    <Badge className="bg-emerald-500/20 text-emerald-100 border border-emerald-400/30 px-3 py-1">
                      <TierIcon className="w-3 h-3 mr-1" />
                      {businessConfig.tier}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2 text-indigo-100">
                    <BusinessIcon className="w-4 h-4" />
                    <span className="text-sm">{businessConfig.serviceName} • Partner since 2022</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Button 
                size="lg" 
                className="bg-white/20 hover:bg-white/30 text-white border border-white/30 backdrop-blur-sm rounded-xl px-6 py-3 font-medium"
              >
                <Plus className="w-5 h-5 mr-2" />
                Add Travel Services
              </Button>
              <Button 
                size="lg"
                variant="outline" 
                className="bg-transparent hover:bg-white/10 text-white border-white/30 hover:border-white/50 rounded-xl px-6 py-3 font-medium"
              >
                <Eye className="w-5 h-5 mr-2" />
                View Listings
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-6 relative z-10">
        {/* Performance Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-white/70 backdrop-blur-sm border border-white/50 shadow-xl rounded-2xl overflow-hidden group hover:shadow-2xl transition-all duration-300 cursor-pointer" 
                onClick={() => setActiveTab("requests")}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl shadow-lg">
                  <BarChart3 className="w-6 h-6 text-white" />
                </div>
                <ArrowUpRight className="w-5 h-5 text-gray-400 group-hover:text-indigo-600 transition-colors" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-medium text-gray-600 uppercase tracking-wide">Total Requests</h3>
                <div className="text-3xl font-bold text-gray-900">{stats.totalRequests}</div>
                <p className="text-sm text-emerald-600 font-medium">↗ +15% this week</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/70 backdrop-blur-sm border border-white/50 shadow-xl rounded-2xl overflow-hidden group hover:shadow-2xl transition-all duration-300 cursor-pointer" 
                onClick={() => {setActiveTab("requests"); setStatusFilter("pending");}}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gradient-to-br from-amber-500 to-orange-600 rounded-xl shadow-lg">
                  <Clock className="w-6 h-6 text-white" />
                </div>
                <ArrowUpRight className="w-5 h-5 text-gray-400 group-hover:text-amber-600 transition-colors" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-medium text-gray-600 uppercase tracking-wide">Pending Approval</h3>
                <div className="text-3xl font-bold text-gray-900">{stats.pendingRequests}</div>
                <p className="text-sm text-gray-600">Avg response: 1.2h</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/70 backdrop-blur-sm border border-white/50 shadow-xl rounded-2xl overflow-hidden group hover:shadow-2xl transition-all duration-300 cursor-pointer" 
                onClick={() => {setActiveTab("requests"); setStatusFilter("accepted");}}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-xl shadow-lg">
                  <UserCheck className="w-6 h-6 text-white" />
                </div>
                <ArrowUpRight className="w-5 h-5 text-gray-400 group-hover:text-emerald-600 transition-colors" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-medium text-gray-600 uppercase tracking-wide">Accepted Bookings</h3>
                <div className="text-3xl font-bold text-gray-900">{stats.acceptedRequests}</div>
                <p className="text-sm text-emerald-600 font-medium">92% acceptance rate</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/70 backdrop-blur-sm border border-white/50 shadow-xl rounded-2xl overflow-hidden group hover:shadow-2xl transition-all duration-300 cursor-pointer" 
                onClick={() => setActiveTab("analytics")}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl shadow-lg">
                  <DollarSign className="w-6 h-6 text-white" />
                </div>
                <ArrowUpRight className="w-5 h-5 text-gray-400 group-hover:text-purple-600 transition-colors" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm font-medium text-gray-600 uppercase tracking-wide">Revenue (MTD)</h3>
                <div className="text-3xl font-bold text-gray-900">{stats.revenue}</div>
                <p className="text-sm text-emerald-600 font-medium">↗ +24% vs last month</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          {/* Pill-shaped Tab Navigation */}
          <div className="flex justify-center mb-8">
            <TabsList className="bg-white/70 backdrop-blur-sm border border-white/50 shadow-xl rounded-full p-2 grid grid-cols-3 w-fit">
              <TabsTrigger 
                value="requests" 
                className="rounded-full px-8 py-3 data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-600 data-[state=active]:to-purple-600 data-[state=active]:text-white data-[state=active]:shadow-lg font-medium"
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Booking Requests
              </TabsTrigger>
              <TabsTrigger 
                value="analytics" 
                className="rounded-full px-8 py-3 data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-600 data-[state=active]:to-purple-600 data-[state=active]:text-white data-[state=active]:shadow-lg font-medium"
              >
                <PieChart className="w-4 h-4 mr-2" />
                Analytics
              </TabsTrigger>
              <TabsTrigger 
                value="settings" 
                className="rounded-full px-8 py-3 data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-600 data-[state=active]:to-purple-600 data-[state=active]:text-white data-[state=active]:shadow-lg font-medium"
              >
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="requests" className="space-y-6">
            {/* Enhanced Search & Filter */}
            <Card className="bg-white/70 backdrop-blur-sm border border-white/50 shadow-xl rounded-2xl">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <Input
                        placeholder="Search customers, booking IDs, or routes..."
                        className="pl-12 pr-4 py-3 rounded-xl border-gray-200 focus:border-indigo-500 focus:ring-indigo-500 bg-white/80 text-base"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="w-48 rounded-xl border-gray-200 bg-white/80 py-3">
                        <Filter className="w-4 h-4 mr-2" />
                        <SelectValue placeholder="Filter by status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Requests</SelectItem>
                        <SelectItem value="pending">Pending Review</SelectItem>
                        <SelectItem value="accepted">Accepted</SelectItem>
                        <SelectItem value="declined">Declined</SelectItem>
                        <SelectItem value="negotiating">In Negotiation</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Booking Requests */}
            <div className="space-y-4">
              {filteredRequests.length === 0 ? (
                <Card className="bg-white/70 backdrop-blur-sm border border-white/50 shadow-xl rounded-2xl">
                  <CardContent className="p-12 text-center">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <AlertCircle className="w-8 h-8 text-gray-400" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">No requests found</h3>
                    <p className="text-gray-600 max-w-md mx-auto">
                      {statusFilter === "all" 
                        ? "No booking requests match your search criteria." 
                        : `No ${statusFilter} requests found.`}
                    </p>
                  </CardContent>
                </Card>
              ) : (
                filteredRequests.map((request) => {
                  const TypeIcon = getTypeIcon(request.type);
                  
                  return (
                    <Card key={request.id} className="bg-white/70 backdrop-blur-sm border border-white/50 shadow-xl rounded-2xl hover:shadow-2xl transition-all duration-300 overflow-hidden">
                      <CardContent className="p-6">
                        <div className="flex flex-col gap-6">
                          {/* Request Header */}
                          <div className="flex items-start gap-4">
                            <div className="p-3 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-xl">
                              <TypeIcon className="w-6 h-6 text-indigo-600" />
                            </div>
                            
                            <div className="flex-1">
                              <div className="flex flex-col lg:flex-row lg:items-center gap-3 mb-3">
                                <h3 className="text-lg font-semibold text-gray-900">
                                  Request #{request.id}
                                </h3>
                                <div className="flex flex-wrap items-center gap-2">
                                  <Badge className={getPriorityColor(request.priority)}>
                                    {request.priority.toUpperCase()} PRIORITY
                                  </Badge>
                                  <Badge className={getStatusColor(request.status)}>
                                    {request.status.toUpperCase()}
                                  </Badge>
                                  {request.status === "pending" && (
                                    <Badge className="bg-blue-50 text-blue-700 border border-blue-200">
                                      <Zap className="w-3 h-3 mr-1" />
                                      URGENT - 2h left
                                    </Badge>
                                  )}
                                </div>
                              </div>
                              
                              {/* Customer Info */}
                              <div className="flex items-center gap-3 mb-4">
                                <Avatar className="w-10 h-10 border-2 border-white shadow-md">
                                  <AvatarFallback className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white font-semibold">
                                    {request.customerName.split(' ').map(n => n[0]).join('')}
                                  </AvatarFallback>
                                </Avatar>
                                <div>
                                  <div className="flex items-center gap-2">
                                    <p className="font-semibold text-gray-900">{request.customerName}</p>
                                    <Badge className="bg-yellow-50 text-yellow-700 border border-yellow-200 text-xs">
                                      <Star className="w-3 h-3 mr-1 fill-yellow-400 text-yellow-400" />
                                      VIP
                                    </Badge>
                                  </div>
                                  <p className="text-sm text-gray-600">{request.customerEmail}</p>
                                </div>
                              </div>
                              
                              {/* Request Details */}
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-4">
                                {request.type === "flight" && (
                                  <>
                                    <div className="space-y-1">
                                      <p className="text-sm font-medium text-gray-500 uppercase tracking-wide">Route</p>
                                      <p className="font-semibold text-gray-900">{request.details.from} → {request.details.to}</p>
                                    </div>
                                    <div className="space-y-1">
                                      <p className="text-sm font-medium text-gray-500 uppercase tracking-wide">Passengers & Class</p>
                                      <p className="font-semibold text-gray-900">{request.details.passengers} passengers • {request.details.flightClass}</p>
                                    </div>
                                  </>
                                )}
                                
                                <div className="space-y-1">
                                  <p className="text-sm font-medium text-gray-500 uppercase tracking-wide">Requested Price</p>
                                  <div className="flex items-center gap-2">
                                    <p className="text-xl font-bold text-emerald-600">₱{request.requestedPrice.toLocaleString()}</p>
                                    <Badge className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-xs">
                                      15% below market
                                    </Badge>
                                  </div>
                                </div>
                              </div>

                              {/* Metadata */}
                              <div className="flex flex-wrap items-center gap-4 text-sm text-gray-500">
                                <div className="flex items-center gap-1">
                                  <Calendar className="w-4 h-4" />
                                  <span>Received {request.timestamp}</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <Users className="w-4 h-4" />
                                  <span>Customer since 2022</span>
                                </div>
                                <div className="flex items-center gap-1">
                                  <MapPin className="w-4 h-4" />
                                  <span>New York, USA</span>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          {/* Action Buttons */}
                          <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-gray-100">
                            {request.status === "pending" && (
                              <>
                                <Button 
                                  size="lg"
                                  onClick={() => handleStatusChange(request.id, "accepted")}
                                  className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl px-6 py-3 font-medium shadow-lg"
                                >
                                  <Check className="w-5 h-5 mr-2" />
                                  Accept Request
                                </Button>
                                <Button 
                                  size="lg"
                                  variant="outline"
                                  onClick={() => handleStatusChange(request.id, "negotiating")}
                                  className="border-indigo-200 text-indigo-700 hover:bg-indigo-50 rounded-xl px-6 py-3 font-medium"
                                >
                                  <MessageCircle className="w-5 h-5 mr-2" />
                                  Negotiate Price
                                </Button>
                                <Button 
                                  size="lg"
                                  variant="outline"
                                  onClick={() => handleStatusChange(request.id, "declined")}
                                  className="border-red-200 text-red-700 hover:bg-red-50 rounded-xl px-6 py-3 font-medium"
                                >
                                  <X className="w-5 h-5 mr-2" />
                                  Decline
                                </Button>
                              </>
                            )}
                            
                            {request.status === "accepted" && (
                              <>
                                <Button 
                                  size="lg"
                                  className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl px-6 py-3 font-medium shadow-lg"
                                >
                                  <FileText className="w-5 h-5 mr-2" />
                                  View Booking Details
                                </Button>
                                <Button 
                                  size="lg"
                                  variant="outline"
                                  className="border-gray-200 text-gray-700 hover:bg-gray-50 rounded-xl px-6 py-3 font-medium"
                                >
                                  <MessageCircle className="w-5 h-5 mr-2" />
                                  Contact Customer
                                </Button>
                              </>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <Card className="bg-white/70 backdrop-blur-sm border border-white/50 shadow-xl rounded-2xl">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                  <PieChart className="w-8 h-8 text-indigo-600" />
                  Partner Analytics Dashboard
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-6 bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl">
                    <TrendingUp className="w-8 h-8 text-indigo-600 mx-auto mb-3" />
                    <h3 className="font-semibold text-gray-900 mb-1">Performance Score</h3>
                    <div className="text-3xl font-bold text-indigo-600">94.2%</div>
                    <p className="text-sm text-gray-600">Above industry average</p>
                  </div>
                  <div className="text-center p-6 bg-gradient-to-br from-emerald-50 to-teal-50 rounded-xl">
                    <Target className="w-8 h-8 text-emerald-600 mx-auto mb-3" />
                    <h3 className="font-semibold text-gray-900 mb-1">Response Time</h3>
                    <div className="text-3xl font-bold text-emerald-600">1.2h</div>
                    <p className="text-sm text-gray-600">Average response time</p>
                  </div>
                  <div className="text-center p-6 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl">
                    <Star className="w-8 h-8 text-purple-600 mx-auto mb-3" />
                    <h3 className="font-semibold text-gray-900 mb-1">Customer Rating</h3>
                    <div className="text-3xl font-bold text-purple-600">4.9/5</div>
                    <p className="text-sm text-gray-600">Based on 847 reviews</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card className="bg-white/70 backdrop-blur-sm border border-white/50 shadow-xl rounded-2xl">
              <CardHeader>
                <CardTitle className="text-2xl font-bold text-gray-900 flex items-center gap-3">
                  <Settings className="w-8 h-8 text-indigo-600" />
                  Partner Account Settings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <BusinessSpecificSettings />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}