import { createContext, useContext, useState, ReactNode } from 'react';

type SubscriptionPlan = 'free' | 'traveler' | 'premium';

interface SubscriptionContextType {
  currentPlan: SubscriptionPlan;
  changePlan: (newPlan: SubscriptionPlan) => void;
  hasFeature: (feature: string) => boolean;
  planFeatures: Record<SubscriptionPlan, string[]>;
}

const SubscriptionContext = createContext<SubscriptionContextType | undefined>(undefined);

export function useSubscription() {
  const context = useContext(SubscriptionContext);
  if (!context) {
    throw new Error('useSubscription must be used within a SubscriptionProvider');
  }
  return context;
}

interface SubscriptionProviderProps {
  children: ReactNode;
}

export function SubscriptionProvider({ children }: SubscriptionProviderProps) {
  const [currentPlan, setCurrentPlan] = useState<SubscriptionPlan>('premium');

  const planFeatures: Record<SubscriptionPlan, string[]> = {
    free: [
      'search-destinations',
      'simple-itineraries', 
      'limited-guides',
      'last-3-trips',
      '1-calendar'
    ],
    traveler: [
      'search-destinations',
      'simple-itineraries',
      'limited-guides',
      'last-3-trips', 
      '1-calendar',
      'ai-recommendations',
      'booking-cloud-storage',
      'multi-calendar',
      'offline-access',
      'priority-support'
    ],
    premium: [
      'search-destinations',
      'simple-itineraries',
      'limited-guides',
      'unlimited-trips',
      'unlimited-calendars',
      'ai-recommendations',
      'booking-cloud-storage',
      'multi-calendar',
      'offline-access',
      'priority-support',
      'concierge-service',
      'group-travel',
      'travel-insurance',
      'premium-support'
    ]
  };

  const changePlan = (newPlan: SubscriptionPlan) => {
    setCurrentPlan(newPlan);
  };

  const hasFeature = (feature: string): boolean => {
    return planFeatures[currentPlan]?.includes(feature) || false;
  };

  return (
    <SubscriptionContext.Provider 
      value={{ 
        currentPlan, 
        changePlan, 
        hasFeature, 
        planFeatures 
      }}
    >
      {children}
    </SubscriptionContext.Provider>
  );
}