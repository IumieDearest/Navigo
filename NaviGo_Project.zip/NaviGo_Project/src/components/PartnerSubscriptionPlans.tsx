import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { NaviGoLogo } from "./NaviGoLogo";
import { 
  Check, 
  Building2, 
  Users, 
  BarChart3, 
  CreditCard, 
  Shield, 
  Headphones, 
  Globe,
  Zap,
  Star,
  ArrowLeft,
  Crown,
  Sparkles,
  X
} from "lucide-react";

interface PartnerSubscriptionPlansProps {
  onBack?: () => void;
  currentPlan?: 'starter' | 'professional' | 'enterprise' | null;
}

export function PartnerSubscriptionPlans({ onBack, currentPlan = null }: PartnerSubscriptionPlansProps) {
  const [selectedPlan, setSelectedPlan] = useState<'starter' | 'professional' | 'enterprise' | null>(currentPlan);
  const [isAnnual, setIsAnnual] = useState(false);

  const plans = [
    {
      id: 'starter' as const,
      name: 'STARTER',
      price: 999,
      description: 'Perfect for small businesses getting started',
      features: [
        'Listing on NaviGo',
        'Access to basic booking system',
        'Email support',
        'Basic analytics',
        'Up to 50 bookings/month'
      ],
      badge: null,
      color: 'from-blue-500 to-cyan-500',
      popular: false
    },
    {
      id: 'professional' as const,
      name: 'PROFESSIONAL',
      price: 2999,
      description: 'Advanced features for growing businesses',
      features: [
        'Customer insights',
        'Featured placement',
        'Integration with booking APIs',
        'Priority support',
        'Advanced analytics dashboard',
        'Up to 500 bookings/month',
        'Custom branding'
      ],
      badge: 'Most Popular',
      color: 'from-purple-500 to-pink-500',
      popular: true
    },
    {
      id: 'enterprise' as const,
      name: 'ENTERPRISE',
      price: null,
      description: 'Tailored solutions for large enterprises',
      features: [
        'Unlimited listings',
        'Dedicated account manager',
        'Custom policies',
        'Full analytics dashboard',
        'Multi-tenancy',
        'White-label solution',
        '24/7 phone support',
        'Custom integrations',
        'SLA guarantee'
      ],
      badge: 'Premium',
      color: 'from-yellow-500 to-orange-500',
      popular: false
    }
  ];

  const handlePlanSelect = (planId: 'starter' | 'professional' | 'enterprise') => {
    setSelectedPlan(planId);
  };

  const handleUpgrade = () => {
    // Handle upgrade logic here
    console.log('Upgrading to:', selectedPlan);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-violet-50 dark:from-slate-900 dark:via-slate-950 dark:to-violet-950">
      {/* Header */}
      <div className="bg-white/80 dark:bg-gray-950/80 backdrop-blur-md border-b border-sky-200/30 dark:border-gray-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              {onBack && (
                <Button variant="ghost" size="sm" onClick={onBack} className="mr-2">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
              )}
              <div className="flex items-center space-x-3">
                <NaviGoLogo variant="square" size={32} />
                <div className="flex items-center space-x-2">
                  <span className="font-semibold text-gray-900 dark:text-white">NaviGo</span>
                  <Badge variant="secondary" className="bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300">
                    B2B Portal
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <NaviGoLogo variant="circular" size={80} />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-teal-600 bg-clip-text text-transparent mb-4">
            OUR NAVIGO PLAN (B2B)
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 mb-8 max-w-3xl mx-auto">
            Choose the perfect plan to grow your travel business with NaviGo's comprehensive partner platform
          </p>
          
          {/* Annual Toggle */}
          <div className="flex items-center justify-center gap-4 mb-8">
            <span className={`text-sm ${!isAnnual ? 'font-medium text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400'}`}>
              Monthly
            </span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsAnnual(!isAnnual)}
              className={`relative w-12 h-6 rounded-full p-0 ${
                isAnnual ? 'bg-gradient-to-r from-blue-500 to-purple-500' : 'bg-gray-200 dark:bg-gray-700'
              }`}
            >
              <div
                className={`absolute w-5 h-5 bg-white rounded-full shadow-md transition-transform duration-200 ${
                  isAnnual ? 'translate-x-6' : 'translate-x-1'
                } top-0.5`}
              />
            </Button>
            <span className={`text-sm ${isAnnual ? 'font-medium text-gray-900 dark:text-white' : 'text-gray-500 dark:text-gray-400'}`}>
              Annual
            </span>
            {isAnnual && (
              <Badge variant="secondary" className="bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300">
                Save 20%
              </Badge>
            )}
          </div>
        </div>

        {/* Plans Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {plans.map((plan) => {
            const isSelected = selectedPlan === plan.id;
            const isCurrent = currentPlan === plan.id;
            const monthlyPrice = plan.price;
            const annualPrice = plan.price ? Math.round(plan.price * 12 * 0.8) : null;
            const displayPrice = isAnnual && annualPrice ? annualPrice : monthlyPrice;
            
            return (
              <Card 
                key={plan.id}
                className={`relative glass-card rounded-3xl shadow-xl border-2 transition-all duration-300 hover:shadow-2xl hover:-translate-y-1 ${
                  plan.popular 
                    ? 'border-purple-400 dark:border-purple-600 ring-2 ring-purple-400/20' 
                    : isSelected 
                      ? 'border-blue-400 dark:border-blue-600' 
                      : 'border-gray-200/50 dark:border-gray-700/50'
                } ${
                  isCurrent ? 'ring-2 ring-green-400/30 border-green-400' : ''
                }`}
              >
                {plan.badge && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <Badge className={`px-4 py-1 ${
                      plan.popular 
                        ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white' 
                        : 'bg-gradient-to-r from-yellow-500 to-orange-500 text-white'
                    }`}>
                      {plan.popular ? (
                        <>
                          <Star className="w-3 h-3 mr-1" />
                          {plan.badge}
                        </>
                      ) : (
                        <>
                          <Crown className="w-3 h-3 mr-1" />
                          {plan.badge}
                        </>
                      )}
                    </Badge>
                  </div>
                )}

                {isCurrent && (
                  <div className="absolute -top-4 right-4">
                    <Badge className="bg-green-500 text-white">
                      <Check className="w-3 h-3 mr-1" />
                      Current Plan
                    </Badge>
                  </div>
                )}

                <CardHeader className="text-center pb-8 pt-8">
                  <div className={`w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-to-br ${plan.color} flex items-center justify-center`}>
                    {plan.id === 'starter' && <Building2 className="w-8 h-8 text-white" />}
                    {plan.id === 'professional' && <Sparkles className="w-8 h-8 text-white" />}
                    {plan.id === 'enterprise' && <Crown className="w-8 h-8 text-white" />}
                  </div>
                  
                  <CardTitle className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
                    {plan.name}
                  </CardTitle>
                  
                  <div className="mb-4">
                    {plan.price ? (
                      <div className="text-center">
                        <div className="flex items-baseline justify-center gap-1">
                          <span className="text-4xl font-bold text-gray-900 dark:text-white">
                            ₱{displayPrice?.toLocaleString()}
                          </span>
                          <span className="text-gray-500 dark:text-gray-400">
                            /{isAnnual ? 'year' : 'month'}
                          </span>
                        </div>
                        {isAnnual && plan.price && (
                          <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                            ₱{Math.round(plan.price * 0.8).toLocaleString()}/month when billed annually
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="text-center">
                        <div className="text-3xl font-bold text-gray-900 dark:text-white">
                          Custom pricing
                        </div>
                        <div className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                          Contact our sales team
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <p className="text-gray-600 dark:text-gray-400 text-sm">
                    {plan.description}
                  </p>
                </CardHeader>

                <CardContent className="px-6 pb-8">
                  <ul className="space-y-4 mb-8">
                    {plan.features.map((feature, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <div className={`flex-shrink-0 w-5 h-5 rounded-full bg-gradient-to-br ${plan.color} flex items-center justify-center mt-0.5`}>
                          <Check className="w-3 h-3 text-white" />
                        </div>
                        <span className="text-gray-700 dark:text-gray-300 text-sm">
                          {feature}
                        </span>
                      </li>
                    ))}
                  </ul>

                  <Button 
                    className={`w-full h-12 rounded-xl font-medium transition-all duration-200 ${
                      isCurrent
                        ? 'bg-gray-100 text-gray-500 cursor-not-allowed dark:bg-gray-800 dark:text-gray-400'
                        : plan.popular
                          ? 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white shadow-lg hover:shadow-xl'
                          : isSelected
                            ? `bg-gradient-to-r ${plan.color} text-white shadow-lg hover:shadow-xl`
                            : 'bg-white border-2 border-gray-200 text-gray-900 hover:border-gray-300 dark:bg-gray-800 dark:border-gray-700 dark:text-white dark:hover:border-gray-600'
                    }`}
                    onClick={() => handlePlanSelect(plan.id)}
                    disabled={isCurrent}
                  >
                    {isCurrent ? (
                      'Current Plan'
                    ) : plan.id === 'enterprise' ? (
                      'Contact Sales'
                    ) : isSelected ? (
                      'Selected'
                    ) : (
                      'Choose Plan'
                    )}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* CTA Section */}
        {selectedPlan && selectedPlan !== currentPlan && (
          <div className="text-center">
            <Card className="glass-card rounded-2xl shadow-xl border-0 max-w-2xl mx-auto">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                  Ready to upgrade your business?
                </h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  {selectedPlan === 'enterprise' 
                    ? 'Our enterprise team will contact you within 24 hours to discuss your custom solution.'
                    : `Upgrade to ${plans.find(p => p.id === selectedPlan)?.name} and unlock powerful features to grow your travel business.`
                  }
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <Button 
                    size="lg"
                    className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white px-8 py-3 rounded-xl font-medium"
                    onClick={handleUpgrade}
                  >
                    {selectedPlan === 'enterprise' ? 'Contact Sales Team' : 'Upgrade Now'}
                  </Button>
                  <Button 
                    size="lg"
                    variant="outline"
                    className="px-8 py-3 rounded-xl font-medium"
                  >
                    Schedule Demo
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Features Comparison */}
        <div className="mt-16">
          <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-12">
            Compare Features
          </h2>
          
          <Card className="glass-card rounded-2xl shadow-xl border-0 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200 dark:border-gray-700">
                    <th className="text-left p-6 font-medium text-gray-900 dark:text-white">Feature</th>
                    <th className="text-center p-6 font-medium text-gray-900 dark:text-white">Starter</th>
                    <th className="text-center p-6 font-medium text-gray-900 dark:text-white">Professional</th>
                    <th className="text-center p-6 font-medium text-gray-900 dark:text-white">Enterprise</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { feature: 'Monthly Bookings', starter: '50', professional: '500', enterprise: 'Unlimited' },
                    { feature: 'API Integrations', starter: '1', professional: '5', enterprise: 'Unlimited' },
                    { feature: 'Custom Branding', starter: false, professional: true, enterprise: true },
                    { feature: 'Priority Support', starter: false, professional: true, enterprise: true },
                    { feature: 'Dedicated Manager', starter: false, professional: false, enterprise: true },
                    { feature: 'White-label Solution', starter: false, professional: false, enterprise: true },
                    { feature: 'SLA Guarantee', starter: false, professional: false, enterprise: true },
                  ].map((row, index) => (
                    <tr key={index} className="border-b border-gray-100 dark:border-gray-800 hover:bg-gray-50/50 dark:hover:bg-gray-800/50">
                      <td className="p-6 font-medium text-gray-900 dark:text-white">{row.feature}</td>
                      <td className="p-6 text-center">
                        {typeof row.starter === 'boolean' ? (
                          row.starter ? (
                            <Check className="w-5 h-5 text-green-500 mx-auto" />
                          ) : (
                            <X className="w-5 h-5 text-gray-300 mx-auto" />
                          )
                        ) : (
                          <span className="text-gray-700 dark:text-gray-300">{row.starter}</span>
                        )}
                      </td>
                      <td className="p-6 text-center">
                        {typeof row.professional === 'boolean' ? (
                          row.professional ? (
                            <Check className="w-5 h-5 text-green-500 mx-auto" />
                          ) : (
                            <X className="w-5 h-5 text-gray-300 mx-auto" />
                          )
                        ) : (
                          <span className="text-gray-700 dark:text-gray-300">{row.professional}</span>
                        )}
                      </td>
                      <td className="p-6 text-center">
                        {typeof row.enterprise === 'boolean' ? (
                          row.enterprise ? (
                            <Check className="w-5 h-5 text-green-500 mx-auto" />
                          ) : (
                            <X className="w-5 h-5 text-gray-300 mx-auto" />
                          )
                        ) : (
                          <span className="text-gray-700 dark:text-gray-300">{row.enterprise}</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}