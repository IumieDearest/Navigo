import { useState, useRef, useEffect } from "react";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Badge } from "./ui/badge";
import { NaviGoLogo } from "./NaviGoLogo";
import { 
  Bell, 
  Building2, 
  ChevronDown, 
  Settings, 
  HelpCircle, 
  LogOut,
  BarChart3,
  Users,
  CreditCard,
  Crown,
  Moon,
  Sun,
  Check,
  X,
  Globe,
  Shield,
  Palette,
  Mail,
  Smartphone,
  AlertCircle,
  TrendingUp,
  UserPlus,
  Clock
} from "lucide-react";
import { useDarkMode } from "./DarkModeContext";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Switch } from "./ui/switch";
import { Separator } from "./ui/separator";

interface PartnerHeaderProps {
  onNavigate: (view: 'dashboard' | 'account-management' | 'billing' | 'settings' | 'help-support' | 'subscription') => void;
  onSignOut?: () => void;
}

export function PartnerHeader({ onNavigate, onSignOut }: PartnerHeaderProps) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [notificationCount, setNotificationCount] = useState(3);
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: 'system',
      title: 'API Rate Limit Warning',
      message: 'Your API usage is approaching the monthly limit',
      time: '5 min ago',
      unread: true,
      icon: AlertCircle,
      color: 'text-orange-500'
    },
    {
      id: 2,
      type: 'business',
      title: 'New Booking Commission',
      message: '$1,250 commission earned from flight booking',
      time: '1 hour ago',
      unread: true,
      icon: TrendingUp,
      color: 'text-green-500'
    },
    {
      id: 3,
      type: 'system',
      title: 'Team Member Added',
      message: 'John Smith was added to your partner account',
      time: '3 hours ago',
      unread: true,
      icon: UserPlus,
      color: 'text-blue-500'
    },
    {
      id: 4,
      type: 'system',
      title: 'Monthly Report Ready',
      message: 'Your November performance report is available',
      time: '1 day ago',
      unread: false,
      icon: BarChart3,
      color: 'text-purple-500'
    }
  ]);
  const [settings, setSettings] = useState({
    emailNotifications: true,
    pushNotifications: false,
    marketingEmails: true,
    apiAlerts: true,
    darkMode: false
  });
  
  const dropdownRef = useRef<HTMLDivElement>(null);
  const settingsRef = useRef<HTMLDivElement>(null);
  const notificationsRef = useRef<HTMLDivElement>(null);
  const { isDark, toggleDark } = useDarkMode();

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
      if (settingsRef.current && !settingsRef.current.contains(event.target as Node)) {
        setIsSettingsOpen(false);
      }
      if (notificationsRef.current && !notificationsRef.current.contains(event.target as Node)) {
        setIsNotificationsOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
    setIsSettingsOpen(false);
    setIsNotificationsOpen(false);
  };

  const toggleSettings = () => {
    setIsSettingsOpen(!isSettingsOpen);
    setIsNotificationsOpen(false);
    setIsDropdownOpen(false);
  };

  const toggleNotifications = () => {
    setIsNotificationsOpen(!isNotificationsOpen);
    setIsSettingsOpen(false);
    setIsDropdownOpen(false);
  };

  const markNotificationAsRead = (id: number) => {
    setNotifications(prev => 
      prev.map(notif => 
        notif.id === id ? { ...notif, unread: false } : notif
      )
    );
    setNotificationCount(prev => Math.max(0, prev - 1));
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notif => ({ ...notif, unread: false }))
    );
    setNotificationCount(0);
  };

  const updateSetting = (key: keyof typeof settings, value: boolean) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b border-gray-200 dark:border-slate-700 bg-white/95 dark:bg-slate-950/95 backdrop-blur supports-[backdrop-filter]:bg-white/60 dark:supports-[backdrop-filter]:bg-slate-950/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <NaviGoLogo variant="square" size={40} />
            <Badge variant="secondary" className="hidden sm:inline-flex bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300">
              Partner Portal
            </Badge>
          </div>

          {/* Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Button 
              variant="ghost" 
              onClick={() => onNavigate('dashboard')}
              className="text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              Dashboard
            </Button>
          </nav>

          {/* Right side */}
          <div className="flex items-center space-x-4">
            {/* Dark Mode Toggle */}
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleDark}
              className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
            >
              {isDark ? (
                <Sun className="h-5 w-5" />
              ) : (
                <Moon className="h-5 w-5" />
              )}
            </Button>

            {/* Settings */}
            <div className="relative" ref={settingsRef}>
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleSettings}
                className={`text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 ${isSettingsOpen ? 'bg-gray-100 dark:bg-gray-800' : ''}`}
              >
                <Settings className="h-5 w-5" />
              </Button>

              {/* Settings Dropdown */}
              {isSettingsOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-gray-900 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 z-50">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="flex items-center gap-2">
                        <Settings className="h-5 w-5" />
                        Settings
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {/* Theme Settings */}
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Palette className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                          <span className="font-medium">Appearance</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-600 dark:text-gray-400">Dark mode</span>
                          <Switch
                            checked={isDark}
                            onCheckedChange={toggleDark}
                          />
                        </div>
                      </div>

                      <Separator />

                      {/* Notification Settings */}
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Bell className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                          <span className="font-medium">Notifications</span>
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">Email notifications</span>
                            <Switch
                              checked={settings.emailNotifications}
                              onCheckedChange={(checked) => updateSetting('emailNotifications', checked)}
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">Push notifications</span>
                            <Switch
                              checked={settings.pushNotifications}
                              onCheckedChange={(checked) => updateSetting('pushNotifications', checked)}
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">Marketing emails</span>
                            <Switch
                              checked={settings.marketingEmails}
                              onCheckedChange={(checked) => updateSetting('marketingEmails', checked)}
                            />
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600 dark:text-gray-400">API alerts</span>
                            <Switch
                              checked={settings.apiAlerts}
                              onCheckedChange={(checked) => updateSetting('apiAlerts', checked)}
                            />
                          </div>
                        </div>
                      </div>

                      <Separator />

                      {/* Quick Actions */}
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Shield className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                          <span className="font-medium">Quick Actions</span>
                        </div>
                        <div className="space-y-2">
                          <Button variant="outline" size="sm" className="w-full justify-start">
                            <Globe className="h-4 w-4 mr-2" />
                            Language Settings
                          </Button>
                          <Button variant="outline" size="sm" className="w-full justify-start">
                            <Shield className="h-4 w-4 mr-2" />
                            Security Settings
                          </Button>
                          <Button variant="outline" size="sm" className="w-full justify-start">
                            <Smartphone className="h-4 w-4 mr-2" />
                            API Configuration
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>

            {/* Notifications */}
            <div className="relative" ref={notificationsRef}>
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleNotifications}
                className={`text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 ${isNotificationsOpen ? 'bg-gray-100 dark:bg-gray-800' : ''}`}
              >
                <Bell className="h-5 w-5" />
                {notificationCount > 0 && (
                  <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">
                    {notificationCount}
                  </span>
                )}
              </Button>

              {/* Notifications Dropdown */}
              {isNotificationsOpen && (
                <div className="absolute right-0 mt-2 w-96 bg-white dark:bg-gray-900 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 z-50">
                  <Card>
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <CardTitle className="flex items-center gap-2">
                          <Bell className="h-5 w-5" />
                          Notifications
                          {notificationCount > 0 && (
                            <Badge variant="destructive" className="text-xs">
                              {notificationCount}
                            </Badge>
                          )}
                        </CardTitle>
                        {notificationCount > 0 && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={markAllAsRead}
                            className="text-xs"
                          >
                            Mark all read
                          </Button>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent className="p-0">
                      <div className="max-h-96 overflow-y-auto">
                        {notifications.length === 0 ? (
                          <div className="p-6 text-center text-gray-500 dark:text-gray-400">
                            <Bell className="h-8 w-8 mx-auto mb-2 opacity-50" />
                            <p>No notifications</p>
                          </div>
                        ) : (
                          notifications.map((notification) => {
                            const IconComponent = notification.icon;
                            return (
                              <div
                                key={notification.id}
                                className={`p-4 border-b border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors ${
                                  notification.unread ? 'bg-blue-50/50 dark:bg-blue-950/20' : ''
                                }`}
                              >
                                <div className="flex items-start gap-3">
                                  <div className={`flex-shrink-0 ${notification.color}`}>
                                    <IconComponent className="h-5 w-5" />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-start justify-between gap-2">
                                      <div>
                                        <p className="font-medium text-gray-900 dark:text-white">
                                          {notification.title}
                                        </p>
                                        <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                                          {notification.message}
                                        </p>
                                        <div className="flex items-center gap-2 mt-2">
                                          <Clock className="h-3 w-3 text-gray-400" />
                                          <span className="text-xs text-gray-500 dark:text-gray-400">
                                            {notification.time}
                                          </span>
                                          {notification.unread && (
                                            <Badge variant="secondary" className="text-xs">
                                              New
                                            </Badge>
                                          )}
                                        </div>
                                      </div>
                                      <div className="flex gap-1">
                                        {notification.unread && (
                                          <Button
                                            variant="ghost"
                                            size="sm"
                                            onClick={() => markNotificationAsRead(notification.id)}
                                            className="h-6 w-6 p-0"
                                          >
                                            <Check className="h-3 w-3" />
                                          </Button>
                                        )}
                                        <Button
                                          variant="ghost"
                                          size="sm"
                                          className="h-6 w-6 p-0 text-gray-400 hover:text-red-500"
                                        >
                                          <X className="h-3 w-3" />
                                        </Button>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                      
                      {notifications.length > 0 && (
                        <div className="p-3 border-t border-gray-100 dark:border-gray-800">
                          <Button variant="outline" size="sm" className="w-full">
                            View All Notifications
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              )}
            </div>

            {/* User Menu */}
            <div className="relative" ref={dropdownRef}>
              <Button
                variant="ghost"
                onClick={toggleDropdown}
                className="flex items-center space-x-2 text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
              >
                <Avatar className="h-8 w-8">
                  <AvatarImage src="/api/placeholder/32/32" alt="Business" />
                  <AvatarFallback className="bg-blue-100 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300">
                    <Building2 className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="hidden sm:block text-left">
                  <div className="text-sm font-medium">Skyline Airways</div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">Premium Partner</div>
                </div>
                <ChevronDown className="h-4 w-4" />
              </Button>

              {/* Dropdown Menu */}
              {isDropdownOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-gray-900 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 py-2 z-50">
                  {/* Business Info */}
                  <div className="px-4 py-3 border-b border-gray-100 dark:border-gray-800">
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src="/api/placeholder/40/40" alt="Business" />
                        <AvatarFallback className="bg-purple-100 dark:bg-purple-900/20 text-purple-700 dark:text-purple-300">
                          <Building2 className="h-5 w-5" />
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <div className="font-medium text-gray-900 dark:text-white">Your Business</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">Airlines Partner</div>
                        <Badge variant="secondary" className="text-xs bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300">
                          Active
                        </Badge>
                      </div>
                    </div>
                  </div>

                  {/* Menu Items */}
                  <div className="py-2">
                    <button 
                      onClick={() => { onNavigate('account-management'); setIsDropdownOpen(false); }}
                      className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-800 flex items-center space-x-3"
                    >
                      <Users className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                      <span className="text-sm text-gray-700 dark:text-gray-300">Account Management</span>
                    </button>
                    
                    <button 
                      onClick={() => { onNavigate('billing'); setIsDropdownOpen(false); }}
                      className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-800 flex items-center space-x-3"
                    >
                      <CreditCard className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                      <span className="text-sm text-gray-700 dark:text-gray-300">Billing & Payments</span>
                    </button>
                    
                    <button 
                      onClick={() => { onNavigate('subscription'); setIsDropdownOpen(false); }}
                      className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-800 flex items-center space-x-3"
                    >
                      <Crown className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                      <span className="text-sm text-gray-700 dark:text-gray-300">Subscription Plans</span>
                    </button>
                    
                    <button 
                      onClick={() => { onNavigate('settings'); setIsDropdownOpen(false); }}
                      className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-800 flex items-center space-x-3"
                    >
                      <Settings className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                      <span className="text-sm text-gray-700 dark:text-gray-300">Partner Settings</span>
                    </button>
                    
                    <button 
                      onClick={() => { onNavigate('help-support'); setIsDropdownOpen(false); }}
                      className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-800 flex items-center space-x-3"
                    >
                      <HelpCircle className="h-4 w-4 text-gray-500 dark:text-gray-400" />
                      <span className="text-sm text-gray-700 dark:text-gray-300">Help & Support</span>
                    </button>
                  </div>

                  <div className="border-t border-gray-100 dark:border-gray-800 pt-2">
                    <button 
                      onClick={() => { onSignOut?.(); setIsDropdownOpen(false); }}
                      className="w-full px-4 py-2 text-left hover:bg-gray-50 dark:hover:bg-gray-800 flex items-center space-x-3 text-red-600 dark:text-red-400"
                    >
                      <LogOut className="h-4 w-4" />
                      <span className="text-sm">Sign out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}