import { useState } from "react";
import { 
  Plane, Hotel, Car, Bell, Settings, BarChart3, Users, 
  TrendingUp, Calendar, MapPin, CreditCard, Check, X, 
  AlertCircle, Clock, Star, Filter, Search, Utensils, Bus,
  Activity, Shield, Anchor, Briefcase, Package, Globe,
  Plus, Building2, Award, Eye, MessageCircle, FileText,
  Target, DollarSign, UserCheck, ArrowUpRight, PieChart,
  LineChart, TrendingDown, Zap, Crown, Diamond
} from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { BusinessSpecificSettings } from "./BusinessSpecificSettings";
import { NaviGoLogoCircular } from "./NaviGoLogoCircular";

interface BookingRequest {
  id: string;
  type: "flight" | "hotel" | "car";
  customerName: string;
  customerEmail: string;
  details: {
    from?: string;
    to?: string;
    checkIn?: string;
    checkOut?: string;
    passengers?: number;
    guests?: number;
    roomType?: string;
    flightClass?: string;
  };
  requestedPrice: number;
  status: "pending" | "accepted" | "declined" | "negotiating";
  timestamp: string;
  priority: "high" | "medium" | "low";
}

interface PartnerDashboardProps {
  partnerType: string;
  partnerName: string;
}

export function PartnerDashboardCleaned({ partnerType, partnerName }: PartnerDashboardProps) {
  const [activeTab, setActiveTab] = useState("requests");
  const [statusFilter, setStatusFilter] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  // Get business type specific configuration
  const getBusinessConfig = (type: string) => {
    switch (type) {
      case 'airline':
        return {
          icon: Plane,
          serviceName: 'Airlines',
          tier: 'Premium Partner',
          tierIcon: Crown,
          features: ['Route Management', 'Fleet Analytics', 'Passenger Services', 'Pricing Optimization']
        };
      case 'hotel':
        return {
          icon: Hotel,
          serviceName: 'Hospitality',
          tier: 'Elite Partner',
          tierIcon: Diamond,
          features: ['Room Management', 'Occupancy Analytics', 'Guest Services', 'Revenue Management']
        };
      case 'car-rental':
        return {
          icon: Car,
          serviceName: 'Vehicle Rentals',
          tier: 'Verified Partner',
          tierIcon: Award,
          features: ['Fleet Management', 'Rental Analytics', 'Customer Services', 'Maintenance Tracking']
        };
      default:
        return {
          icon: Package,
          serviceName: 'Travel Services',
          tier: 'Standard Partner',
          tierIcon: Award,
          features: ['Service Management', 'Booking System', 'Customer Support', 'Analytics Dashboard']
        };
    }
  };

  const businessConfig = getBusinessConfig(partnerType);

  const [bookingRequests, setBookingRequests] = useState<BookingRequest[]>([
    {
      id: "BR-001",
      type: "flight",
      customerName: "Anna Mae Regis",
      customerEmail: "anna.regis@email.com",
      details: {
        from: "New York (JFK)",
        to: "Paris (CDG)",
        passengers: 2,
        flightClass: "Business"
      },
      requestedPrice: 2400,
      status: "pending",
      timestamp: "2 hours ago",
      priority: "high"
    },
    {
      id: "BR-002",
      type: "flight",
      customerName: "John Smith",
      customerEmail: "john.smith@email.com",
      details: {
        from: "Los Angeles (LAX)",
        to: "London (LHR)",
        passengers: 1,
        flightClass: "Premium Economy"
      },
      requestedPrice: 1800,
      status: "pending",
      timestamp: "4 hours ago",
      priority: "medium"
    },
    {
      id: "BR-003",
      type: "flight",
      customerName: "Sarah Johnson",
      customerEmail: "sarah.j@email.com",
      details: {
        from: "London (LHR)",
        to: "Tokyo (NRT)",
        passengers: 1,
        flightClass: "Economy"
      },
      requestedPrice: 850,
      status: "negotiating",
      timestamp: "1 day ago",
      priority: "low"
    },
    {
      id: "BR-004",
      type: "flight",
      customerName: "Michael Chen",
      customerEmail: "m.chen@email.com",
      details: {
        from: "San Francisco (SFO)",
        to: "Amsterdam (AMS)",
        passengers: 3,
        flightClass: "Business"
      },
      requestedPrice: 4200,
      status: "accepted",
      timestamp: "2 days ago",
      priority: "high"
    }
  ]);

  const handleStatusChange = (requestId: string, newStatus: BookingRequest["status"]) => {
    setBookingRequests(requests => 
      requests.map(request => 
        request.id === requestId ? { ...request, status: newStatus } : request
      )
    );
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "flight": return Plane;
      case "hotel": return Hotel;
      case "car": return Car;
      default: return Plane;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-50 text-red-600 border border-red-200";
      case "medium": return "bg-amber-50 text-amber-600 border border-amber-200";
      case "low": return "bg-green-50 text-green-600 border border-green-200";
      default: return "bg-gray-50 text-gray-600 border border-gray-200";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending": return "bg-blue-50 text-blue-600 border border-blue-200";
      case "accepted": return "bg-green-50 text-green-600 border border-green-200";
      case "declined": return "bg-red-50 text-red-600 border border-red-200";
      case "negotiating": return "bg-purple-50 text-purple-600 border border-purple-200";
      default: return "bg-gray-50 text-gray-600 border border-gray-200";
    }
  };

  const filteredRequests = bookingRequests.filter(request => {
    const matchesStatus = statusFilter === "all" || request.status === statusFilter;
    const matchesSearch = request.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         request.customerEmail.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         request.id.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesStatus && matchesSearch;
  });

  const stats = {
    totalRequests: bookingRequests.length,
    pendingRequests: bookingRequests.filter(r => r.status === "pending").length,
    acceptedRequests: bookingRequests.filter(r => r.status === "accepted").length,
    revenue: "₱248,650"
  };

  const BusinessIcon = businessConfig.icon;
  const TierIcon = businessConfig.tierIcon;

  return (
    <section className="py-4 md:py-8 bg-gradient-to-b from-sky-400 via-sky-200 to-white dark:from-slate-900 dark:via-slate-950 dark:to-slate-800 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Business Profile Header - Enhanced */}
        <div className="mb-6">
          <Card className="bg-gradient-to-r from-sky-500 to-blue-400 dark:bg-slate-800/90 border border-sky-300/50 dark:border-slate-700 shadow-lg backdrop-blur-sm">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="relative">
                    <div className="w-12 h-12 bg-white/90 dark:bg-blue-950 rounded-xl flex items-center justify-center border border-white/50 dark:border-blue-800 shadow-sm">
                      <NaviGoLogoCircular className="w-6 h-6" />
                    </div>
                    <div className="absolute -top-1 -right-1 w-5 h-5 bg-white rounded-full flex items-center justify-center shadow-sm border border-sky-200">
                      <TierIcon className="w-2.5 h-2.5 text-sky-600" />
                    </div>
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <h1 className="text-lg font-semibold text-white dark:text-white">{partnerName}</h1>
                      <Badge variant="secondary" className="text-xs bg-white/90 text-sky-700 border border-white/50 shadow-sm dark:bg-blue-950 dark:text-blue-300">
                        {businessConfig.tier}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-white/90 dark:text-gray-400">
                      <BusinessIcon className="w-4 h-4" />
                      <span>{businessConfig.serviceName} • Partner since 2022</span>
                    </div>
                  </div>
                </div>
                
                {/* Action Buttons */}
                <div className="flex gap-2">
                  <Button className="bg-white text-sky-700 hover:bg-gray-50 shadow-md border border-white/50 font-semibold">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Services
                  </Button>
                  <Button variant="outline" className="bg-white/90 border-white/50 text-sky-700 hover:bg-white hover:border-white shadow-md font-semibold dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-800">
                    <Eye className="w-4 h-4 mr-2" />
                    View Listings
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Enhanced Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 shadow-md hover:shadow-xl transition-all duration-200 cursor-pointer" 
                onClick={() => setActiveTab("requests")}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="p-3 bg-blue-500 rounded-lg">
                  <BarChart3 className="w-5 h-5 text-white" />
                </div>
                <ArrowUpRight className="w-4 h-4 text-gray-400" />
              </div>
              <div className="space-y-1">
                <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide font-medium">Total Requests</p>
                <div className="text-xl font-bold text-gray-900 dark:text-white">{stats.totalRequests}</div>
                <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">↗ +15% this week</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 shadow-md hover:shadow-xl transition-all duration-200 cursor-pointer" 
                onClick={() => {setActiveTab("requests"); setStatusFilter("pending");}}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="p-3 bg-orange-500 rounded-lg">
                  <Clock className="w-5 h-5 text-white" />
                </div>
                <ArrowUpRight className="w-4 h-4 text-gray-400" />
              </div>
              <div className="space-y-1">
                <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide font-medium">Pending</p>
                <div className="text-xl font-bold text-gray-900 dark:text-white">{stats.pendingRequests}</div>
                <p className="text-xs text-gray-600 dark:text-gray-400">Avg response: 1.2h</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 shadow-md hover:shadow-xl transition-all duration-200 cursor-pointer" 
                onClick={() => {setActiveTab("requests"); setStatusFilter("accepted");}}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="p-3 bg-green-500 rounded-lg">
                  <UserCheck className="w-5 h-5 text-white" />
                </div>
                <ArrowUpRight className="w-4 h-4 text-gray-400" />
              </div>
              <div className="space-y-1">
                <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide font-medium">Accepted</p>
                <div className="text-xl font-bold text-gray-900 dark:text-white">{stats.acceptedRequests}</div>
                <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">92% acceptance rate</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 shadow-md hover:shadow-xl transition-all duration-200 cursor-pointer" 
                onClick={() => setActiveTab("analytics")}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="p-3 bg-purple-500 rounded-lg">
                  <DollarSign className="w-5 h-5 text-white" />
                </div>
                <ArrowUpRight className="w-4 h-4 text-gray-400" />
              </div>
              <div className="space-y-1">
                <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide font-medium">Revenue (MTD)</p>
                <div className="text-xl font-bold text-gray-900 dark:text-white">{stats.revenue}</div>
                <p className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">↗ +24% vs last month</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          {/* Enhanced Tab Navigation */}
          <div className="flex justify-center">
            <TabsList className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 shadow-lg rounded-xl grid grid-cols-3 w-fit">
              <TabsTrigger 
                value="requests" 
                className="rounded-lg px-6 py-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-sky-500 data-[state=active]:to-blue-600 data-[state=active]:text-white data-[state=active]:shadow-md font-medium"
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Requests
              </TabsTrigger>
              <TabsTrigger 
                value="analytics" 
                className="rounded-lg px-6 py-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-sky-500 data-[state=active]:to-blue-600 data-[state=active]:text-white data-[state=active]:shadow-md font-medium"
              >
                <PieChart className="w-4 h-4 mr-2" />
                Analytics
              </TabsTrigger>
              <TabsTrigger 
                value="settings" 
                className="rounded-lg px-6 py-2 data-[state=active]:bg-gradient-to-r data-[state=active]:from-sky-500 data-[state=active]:to-blue-600 data-[state=active]:text-white data-[state=active]:shadow-md font-medium"
              >
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="requests" className="space-y-6">
            {/* Search & Filter */}
            <Card className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 shadow-md">
              <CardContent className="p-4">
                <div className="flex flex-col lg:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                      <Input
                        placeholder="Search customers, booking IDs, or routes..."
                        className="pl-10 border-gray-300 dark:border-gray-600 bg-white focus:border-blue-500"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="w-48">
                    <Select value={statusFilter} onValueChange={setStatusFilter}>
                      <SelectTrigger className="border-gray-300 dark:border-gray-600 bg-white">
                        <Filter className="w-4 h-4 mr-2" />
                        <SelectValue placeholder="Filter by status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Requests</SelectItem>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="accepted">Accepted</SelectItem>
                        <SelectItem value="declined">Declined</SelectItem>
                        <SelectItem value="negotiating">Negotiating</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Booking Requests */}
            <div className="space-y-4">
              {filteredRequests.length === 0 ? (
                <Card className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 shadow-md">
                  <CardContent className="p-8 text-center">
                    <div className="w-12 h-12 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
                      <AlertCircle className="w-6 h-6 text-gray-400" />
                    </div>
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No requests found</h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      {statusFilter === "all" 
                        ? "No booking requests match your search criteria." 
                        : `No ${statusFilter} requests found.`}
                    </p>
                  </CardContent>
                </Card>
              ) : (
                filteredRequests.map((request) => {
                  const TypeIcon = getTypeIcon(request.type);
                  
                  return (
                    <Card key={request.id} className="bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 shadow-md hover:shadow-lg transition-all duration-200">
                      <CardContent className="p-6">
                        <div className="space-y-4">
                          {/* Request Header */}
                          <div className="flex items-start justify-between">
                            <div className="flex items-start gap-4">
                              <div className="p-2 bg-blue-500 rounded-lg">
                                <TypeIcon className="w-5 h-5 text-white" />
                              </div>
                              
                              <div className="flex-1">
                                <div className="flex flex-col lg:flex-row lg:items-center gap-2 mb-2">
                                  <h3 className="font-semibold text-gray-900 dark:text-white">
                                    Request #{request.id}
                                  </h3>
                                  <div className="flex flex-wrap items-center gap-2">
                                    <Badge className={getPriorityColor(request.priority)}>
                                      {request.priority.toUpperCase()}
                                    </Badge>
                                    <Badge className={getStatusColor(request.status)}>
                                      {request.status.toUpperCase()}
                                    </Badge>
                                    {request.status === "pending" && (
                                      <Badge className="bg-red-50 text-red-600 border border-red-200">
                                        <Clock className="w-3 h-3 mr-1" />
                                        2h left
                                      </Badge>
                                    )}
                                  </div>
                                </div>
                                
                                {/* Customer Info */}
                                <div className="flex items-center gap-3 mb-3">
                                  <Avatar className="w-8 h-8">
                                    <AvatarFallback className="bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 text-sm">
                                      {request.customerName.split(' ').map(n => n[0]).join('')}
                                    </AvatarFallback>
                                  </Avatar>
                                  <div>
                                    <div className="flex items-center gap-2">
                                      <p className="font-medium text-gray-900 dark:text-white">{request.customerName}</p>
                                      <Badge className="bg-yellow-50 text-yellow-600 border border-yellow-200 text-xs">
                                        <Star className="w-3 h-3 mr-1 fill-yellow-400 text-yellow-400" />
                                        VIP
                                      </Badge>
                                    </div>
                                    <p className="text-sm text-gray-600 dark:text-gray-400">{request.customerEmail}</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          
                          {/* Request Details */}
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-gray-50 dark:bg-slate-900 rounded-lg">
                            {request.type === "flight" && (
                              <>
                                <div>
                                  <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Route</p>
                                  <p className="font-medium text-gray-900 dark:text-white">{request.details.from} → {request.details.to}</p>
                                </div>
                                <div>
                                  <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Details</p>
                                  <p className="font-medium text-gray-900 dark:text-white">{request.details.passengers} passengers • {request.details.flightClass}</p>
                                </div>
                              </>
                            )}
                            
                            <div>
                              <p className="text-xs text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1">Requested Price</p>
                              <div className="flex items-center gap-2">
                                <p className="text-lg font-bold text-green-600 dark:text-green-400">₱{request.requestedPrice.toLocaleString()}</p>
                                <Badge className="bg-green-50 text-green-600 border border-green-200 text-xs">
                                  15% below market
                                </Badge>
                              </div>
                            </div>
                          </div>

                          {/* Action Buttons */}
                          {request.status === "pending" && (
                            <div className="flex flex-col sm:flex-row gap-3 pt-3 border-t border-gray-100 dark:border-slate-700">
                              <Button 
                                onClick={() => handleStatusChange(request.id, "accepted")}
                                className="bg-gradient-to-r from-emerald-500 to-green-600 hover:from-emerald-600 hover:to-green-700 text-white shadow-sm border-0"
                              >
                                <Check className="w-4 h-4 mr-2" />
                                Accept Request
                              </Button>
                              <Button 
                                variant="outline"
                                onClick={() => handleStatusChange(request.id, "negotiating")}
                                className="bg-white/70 border-sky-200 text-sky-700 hover:bg-sky-50 hover:border-sky-300 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-800"
                              >
                                <MessageCircle className="w-4 h-4 mr-2" />
                                Negotiate
                              </Button>
                              <Button 
                                variant="outline"
                                onClick={() => handleStatusChange(request.id, "declined")}
                                className="bg-white/70 border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300 dark:border-red-600 dark:text-red-400 dark:hover:bg-red-950"
                              >
                                <X className="w-4 h-4 mr-2" />
                                Decline
                              </Button>
                            </div>
                          )}
                          
                          {request.status === "accepted" && (
                            <div className="flex flex-col sm:flex-row gap-3 pt-3 border-t border-gray-100 dark:border-slate-700">
                              <Button className="bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-700 hover:to-blue-700 text-white shadow-sm border-0">
                                <FileText className="w-4 h-4 mr-2" />
                                View Booking
                              </Button>
                              <Button variant="outline" className="bg-white/70 border-sky-200 text-sky-700 hover:bg-sky-50 hover:border-sky-300 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-800">
                                <MessageCircle className="w-4 h-4 mr-2" />
                                Contact Customer
                              </Button>
                            </div>
                          )}

                          {/* Metadata */}
                          <div className="flex flex-wrap items-center gap-4 text-xs text-gray-500 dark:text-gray-400 pt-2 border-t border-gray-100 dark:border-slate-700">
                            <div className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              <span>Received {request.timestamp}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Users className="w-3 h-3" />
                              <span>Customer since 2022</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <MapPin className="w-3 h-3" />
                              <span>New York, USA</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <Card className="bg-white/80 dark:bg-slate-800/90 border border-white/40 dark:border-slate-700 shadow-sm backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-gray-900 dark:text-white flex items-center gap-3">
                  <PieChart className="w-6 h-6 text-sky-600" />
                  Analytics Dashboard
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-6 bg-gradient-to-br from-sky-50 to-blue-50 dark:bg-slate-900 rounded-xl backdrop-blur-sm">
                    <TrendingUp className="w-6 h-6 text-sky-600 mx-auto mb-2" />
                    <h3 className="font-medium text-gray-900 dark:text-white mb-1">Performance Score</h3>
                    <div className="text-2xl font-bold text-sky-600">94.2%</div>
                    <p className="text-xs text-gray-600 dark:text-gray-400">Above industry average</p>
                  </div>
                  <div className="text-center p-6 bg-gradient-to-br from-emerald-50 to-green-50 dark:bg-slate-900 rounded-xl backdrop-blur-sm">
                    <Target className="w-6 h-6 text-emerald-600 mx-auto mb-2" />
                    <h3 className="font-medium text-gray-900 dark:text-white mb-1">Response Time</h3>
                    <div className="text-2xl font-bold text-emerald-600">1.2h</div>
                    <p className="text-xs text-gray-600 dark:text-gray-400">Average response time</p>
                  </div>
                  <div className="text-center p-6 bg-gradient-to-br from-violet-50 to-purple-50 dark:bg-slate-900 rounded-xl backdrop-blur-sm">
                    <Star className="w-6 h-6 text-violet-600 mx-auto mb-2" />
                    <h3 className="font-medium text-gray-900 dark:text-white mb-1">Customer Rating</h3>
                    <div className="text-2xl font-bold text-violet-600">4.9/5</div>
                    <p className="text-xs text-gray-600 dark:text-gray-400">Based on 847 reviews</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card className="bg-white/80 dark:bg-slate-800/90 border border-white/40 dark:border-slate-700 shadow-sm backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-xl font-semibold text-gray-900 dark:text-white flex items-center gap-3">
                  <Settings className="w-6 h-6 text-sky-600" />
                  Partner Settings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <BusinessSpecificSettings />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}