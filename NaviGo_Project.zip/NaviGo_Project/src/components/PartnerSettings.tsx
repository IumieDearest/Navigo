import { useState } from "react";
import { 
  ArrowLeft, Settings, Bell, Shield, Globe, 
  Moon, Sun, Monitor, Key, Database, Zap,
  Save, RefreshCw, Eye, EyeOff, Copy, Check
} from "lucide-react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Switch } from "./ui/switch";
import { Label } from "./ui/label";
import { Input } from "./ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Slider } from "./ui/slider";
import { Badge } from "./ui/badge";
import { Separator } from "./ui/separator";
import { useDarkMode } from "./DarkModeContext";

interface PartnerSettingsProps {
  onBack: () => void;
}

export function PartnerSettings({ onBack }: PartnerSettingsProps) {
  const { isDark, toggleDark } = useDarkMode();
  const [showApiKey, setShowApiKey] = useState(false);
  const [apiKeyCopied, setApiKeyCopied] = useState(false);
  
  const [settings, setSettings] = useState({
    autoAcceptThreshold: 5000,
    responseTimeLimit: 24,
    enableWebhooks: true,
    emailNotifications: true,
    smsNotifications: false,
    desktopNotifications: true,
    marketingEmails: false,
    dataRetention: 365,
    apiRateLimit: 1000,
    enableAnalytics: true
  });

  const apiKey = "sk_live_51H7x8fGqERKQm8XJ9Z2YpT4VnQ7K3M";
  
  const handleCopyApiKey = () => {
    navigator.clipboard.writeText(apiKey);
    setApiKeyCopied(true);
    setTimeout(() => setApiKeyCopied(false), 2000);
  };

  const handleSaveSettings = () => {
    // Save settings logic here
    console.log("Settings saved:", settings);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button variant="ghost" onClick={onBack} className="p-2">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
              <Settings className="w-6 h-6 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Partner Settings</h1>
              <p className="text-gray-600 dark:text-gray-400">Configure your partner portal preferences</p>
            </div>
          </div>
        </div>

        <Tabs defaultValue="general" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
            <TabsTrigger value="automation">Automation</TabsTrigger>
            <TabsTrigger value="api">API & Integrations</TabsTrigger>
            <TabsTrigger value="security">Security</TabsTrigger>
          </TabsList>

          {/* General Settings */}
          <TabsContent value="general" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Appearance</CardTitle>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Customize how your partner portal looks
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {isDark ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
                    <div>
                      <Label>Dark Mode</Label>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Toggle dark mode interface</p>
                    </div>
                  </div>
                  <Switch 
                    checked={isDark} 
                    onCheckedChange={toggleDark}
                    className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                  />
                </div>
                
                <Separator />
                
                <div className="space-y-4">
                  <Label>Language</Label>
                  <Select defaultValue="en">
                    <SelectTrigger className="w-64">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="es">Español</SelectItem>
                      <SelectItem value="fr">Français</SelectItem>
                      <SelectItem value="de">Deutsch</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-4">
                  <Label>Timezone</Label>
                  <Select defaultValue="utc-5">
                    <SelectTrigger className="w-64">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="utc-8">Pacific Time (UTC-8)</SelectItem>
                      <SelectItem value="utc-7">Mountain Time (UTC-7)</SelectItem>
                      <SelectItem value="utc-6">Central Time (UTC-6)</SelectItem>
                      <SelectItem value="utc-5">Eastern Time (UTC-5)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Data & Privacy</CardTitle>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Control your data retention and privacy settings
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <Label>Data Retention Period</Label>
                    <Badge variant="outline">{settings.dataRetention} days</Badge>
                  </div>
                  <Slider 
                    value={[settings.dataRetention]}
                    onValueChange={(value) => setSettings({...settings, dataRetention: value[0]})}
                    max={730}
                    min={90}
                    step={30}
                    className="w-full"
                  />
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    How long to keep booking and customer data
                  </p>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Analytics Tracking</Label>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Allow usage analytics collection</p>
                  </div>
                  <Switch 
                    checked={settings.enableAnalytics}
                    onCheckedChange={(checked) => setSettings({...settings, enableAnalytics: checked})}
                    className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notifications */}
          <TabsContent value="notifications" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="w-5 h-5" />
                  Notification Preferences
                </CardTitle>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Choose how you want to receive notifications
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                    <div>
                      <Label>Email Notifications</Label>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Receive notifications via email</p>
                    </div>
                    <Switch 
                      checked={settings.emailNotifications}
                      onCheckedChange={(checked) => setSettings({...settings, emailNotifications: checked})}
                      className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                    <div>
                      <Label>SMS Notifications</Label>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Receive urgent notifications via SMS</p>
                    </div>
                    <Switch 
                      checked={settings.smsNotifications}
                      onCheckedChange={(checked) => setSettings({...settings, smsNotifications: checked})}
                      className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                    <div>
                      <Label>Desktop Notifications</Label>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Show browser notifications</p>
                    </div>
                    <Switch 
                      checked={settings.desktopNotifications}
                      onCheckedChange={(checked) => setSettings({...settings, desktopNotifications: checked})}
                      className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                    <div>
                      <Label>Marketing Communications</Label>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Promotional emails and updates</p>
                    </div>
                    <Switch 
                      checked={settings.marketingEmails}
                      onCheckedChange={(checked) => setSettings({...settings, marketingEmails: checked})}
                      className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Automation */}
          <TabsContent value="automation" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="w-5 h-5" />
                  Automation Rules
                </CardTitle>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Set up automatic responses and workflows
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <Label>Auto-Accept Threshold</Label>
                      <Badge variant="outline">${settings.autoAcceptThreshold.toLocaleString()}</Badge>
                    </div>
                    <Slider 
                      value={[settings.autoAcceptThreshold]}
                      onValueChange={(value) => setSettings({...settings, autoAcceptThreshold: value[0]})}
                      max={10000}
                      min={1000}
                      step={500}
                      className="w-full"
                    />
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                      Automatically accept bookings above this amount
                    </p>
                  </div>

                  <Separator />

                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <Label>Response Time Limit</Label>
                      <Badge variant="outline">{settings.responseTimeLimit} hours</Badge>
                    </div>
                    <Slider 
                      value={[settings.responseTimeLimit]}
                      onValueChange={(value) => setSettings({...settings, responseTimeLimit: value[0]})}
                      max={72}
                      min={2}
                      step={2}
                      className="w-full"
                    />
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                      Maximum time to respond to booking requests
                    </p>
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Enable Webhooks</Label>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Send real-time updates to your systems</p>
                    </div>
                    <Switch 
                      checked={settings.enableWebhooks}
                      onCheckedChange={(checked) => setSettings({...settings, enableWebhooks: checked})}
                      className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* API & Integrations */}
          <TabsContent value="api" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Key className="w-5 h-5" />
                  API Configuration
                </CardTitle>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Manage your API keys and integration settings
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <Label>API Key</Label>
                    <div className="flex items-center gap-2 mt-2">
                      <Input 
                        type={showApiKey ? "text" : "password"}
                        value={apiKey}
                        readOnly
                        className="flex-1 font-mono"
                      />
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setShowApiKey(!showApiKey)}
                      >
                        {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={handleCopyApiKey}
                      >
                        {apiKeyCopied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                      </Button>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                      Use this key to authenticate API requests
                    </p>
                  </div>

                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <Label>API Rate Limit</Label>
                      <Badge variant="outline">{settings.apiRateLimit} requests/hour</Badge>
                    </div>
                    <Slider 
                      value={[settings.apiRateLimit]}
                      onValueChange={(value) => setSettings({...settings, apiRateLimit: value[0]})}
                      max={5000}
                      min={100}
                      step={100}
                      className="w-full"
                    />
                  </div>

                  <Separator />

                  <div className="flex items-center justify-between">
                    <Button variant="outline">
                      <RefreshCw className="w-4 h-4 mr-2" />
                      Regenerate API Key
                    </Button>
                    <Button variant="outline">
                      <Database className="w-4 h-4 mr-2" />
                      View API Docs
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Webhook Endpoints</CardTitle>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Configure webhook URLs for real-time updates
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Booking Updates Webhook</Label>
                  <Input placeholder="https://your-domain.com/webhooks/bookings" />
                </div>
                <div className="space-y-2">
                  <Label>Payment Notifications Webhook</Label>
                  <Input placeholder="https://your-domain.com/webhooks/payments" />
                </div>
                <Button className="w-full">
                  Save Webhook Settings
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Security */}
          <TabsContent value="security" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="w-5 h-5" />
                  Security Settings
                </CardTitle>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Configure security and access controls
                </p>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <Label>Two-Factor Authentication</Label>
                      <Badge className="bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200">
                        Not Enabled
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                      Add an extra layer of security to your account
                    </p>
                    <Button size="sm">Enable 2FA</Button>
                  </div>

                  <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <Label>IP Whitelist</Label>
                      <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">
                        Disabled
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                      Restrict access to specific IP addresses
                    </p>
                    <Button size="sm" variant="outline">Configure IPs</Button>
                  </div>

                  <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <Label>Session Timeout</Label>
                      <Badge variant="outline">24 hours</Badge>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                      Automatically log out inactive sessions
                    </p>
                    <Select defaultValue="24h">
                      <SelectTrigger className="w-48">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1h">1 hour</SelectItem>
                        <SelectItem value="8h">8 hours</SelectItem>
                        <SelectItem value="24h">24 hours</SelectItem>
                        <SelectItem value="7d">7 days</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Save Button */}
        <div className="flex justify-end">
          <Button onClick={handleSaveSettings} className="min-w-32 bg-green-600 hover:bg-green-700 text-white">
            <Save className="w-4 h-4 mr-2" />
            Save All Settings
          </Button>
        </div>
      </div>
    </div>
  );
}