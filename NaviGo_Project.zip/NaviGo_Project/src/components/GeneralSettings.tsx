import { useState } from "react";
import { Settings, Moon, Sun, Bell, Mail, Smartphone, Globe, Languages } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Switch } from "./ui/switch";
import { Button } from "./ui/button";
import { Separator } from "./ui/separator";
import { useDarkMode } from "./DarkModeContext";

export function GeneralSettings() {
  const { isDark, toggleDark } = useDarkMode();
  
  const [notifications, setNotifications] = useState({
    emailNotifications: true,
    pushNotifications: false,
    marketingEmails: true,
    apiAlerts: true
  });

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
            <Settings className="w-6 h-6 text-blue-600 dark:text-blue-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Settings</h1>
            <p className="text-gray-600 dark:text-gray-400">Manage your preferences</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Appearance Section */}
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2">
                <Moon className="w-5 h-5" />
                Appearance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="font-medium text-gray-900 dark:text-white">Dark mode</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Toggle between light and dark themes
                  </p>
                </div>
                <Switch 
                  checked={isDark} 
                  onCheckedChange={toggleDark}
                  className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                />
              </div>
            </CardContent>
          </Card>

          {/* Notifications Section */}
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Notifications
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="font-medium text-gray-900 dark:text-white">Email notifications</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Receive updates and alerts via email
                  </p>
                </div>
                <Switch 
                  checked={notifications.emailNotifications}
                  onCheckedChange={(checked) => setNotifications({...notifications, emailNotifications: checked})}
                  className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="font-medium text-gray-900 dark:text-white">Push notifications</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Get instant notifications on your device
                  </p>
                </div>
                <Switch 
                  checked={notifications.pushNotifications}
                  onCheckedChange={(checked) => setNotifications({...notifications, pushNotifications: checked})}
                  className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="font-medium text-gray-900 dark:text-white">Marketing emails</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Promotional content and special offers
                  </p>
                </div>
                <Switch 
                  checked={notifications.marketingEmails}
                  onCheckedChange={(checked) => setNotifications({...notifications, marketingEmails: checked})}
                  className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <p className="font-medium text-gray-900 dark:text-white">API alerts</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Technical notifications and system updates
                  </p>
                </div>
                <Switch 
                  checked={notifications.apiAlerts}
                  onCheckedChange={(checked) => setNotifications({...notifications, apiAlerts: checked})}
                  className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                />
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions Section */}
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5" />
                Quick Actions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Button 
                variant="outline" 
                className="w-full justify-start h-12"
              >
                <Languages className="w-5 h-5 mr-3" />
                <div className="text-left">
                  <p className="font-medium">Language Settings</p>
                  <p className="text-sm text-gray-500">English (US)</p>
                </div>
              </Button>
            </CardContent>
          </Card>

          {/* Save Button */}
          <div className="flex justify-end pt-4">
            <Button className="bg-green-600 hover:bg-green-700 text-white min-w-32">
              Save Changes
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}