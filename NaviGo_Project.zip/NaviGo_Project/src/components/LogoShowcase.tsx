import { NaviGoLogo } from './NaviGoLogo';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';

export function LogoShowcase() {
  return (
    <div className="max-w-4xl mx-auto p-8 space-y-8">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold">NaviGo Oval Logo Showcase</h1>
        <p className="text-muted-foreground">
          Professional oval-framed logo design for all application contexts
        </p>
      </div>
      
      <div className="grid md:grid-cols-2 gap-8">
        {/* Large Logo */}
        <Card>
          <CardHeader>
            <CardTitle>Large Oval Logo</CardTitle>
            <CardDescription>
              For homepage, welcome screens, and hero sections
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-col items-center space-y-4 p-8 bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg">
              <NaviGoLogo variant="circular" size={120} />
              <p className="text-sm text-center text-muted-foreground">
                Elegant oval frame with gradient background and inner glow
              </p>
            </div>
            
            {/* Different sizes */}
            <div className="space-y-2">
              <p className="text-sm font-medium">Available large sizes:</p>
              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg flex-wrap justify-center">
                <NaviGoLogo size={80} />
                <NaviGoLogo size={100} />
                <NaviGoLogo size={120} />
                <NaviGoLogo size={140} />
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Compact Logo */}
        <Card>
          <CardHeader>
            <CardTitle>Compact Oval Logo</CardTitle>
            <CardDescription>
              For headers, navigation, and sidebar areas
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-col items-center space-y-4 p-8 bg-gradient-to-br from-slate-50 to-slate-100 rounded-lg">
              <NaviGoLogo variant="square" size={40} />
              <p className="text-sm text-center text-muted-foreground">
                Compact oval design with consistent branding
              </p>
            </div>
            
            {/* Different sizes */}
            <div className="space-y-2">
              <p className="text-sm font-medium">Available compact sizes:</p>
              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-lg">
                <NaviGoLogo variant="square" size={32} />
                <NaviGoLogo variant="square" size={40} />
                <NaviGoLogo variant="square" size={48} />
                <NaviGoLogo variant="square" size={56} />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Usage Examples */}
      <Card>
        <CardHeader>
          <CardTitle>Usage Examples</CardTitle>
          <CardDescription>
            How the oval logo appears in different application contexts
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Header Example */}
          <div className="space-y-2">
            <p className="text-sm font-medium">In Navigation Header:</p>
            <div className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-lg shadow-sm">
              <div className="flex items-center gap-3">
                <NaviGoLogo variant="square" size={40} />
                <span className="font-semibold">NaviGo</span>
              </div>
              <div className="flex gap-2">
                <button className="px-4 py-2 text-sm border border-gray-300 rounded-lg hover:bg-gray-50">
                  Sign In
                </button>
                <button className="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                  Get Started
                </button>
              </div>
            </div>
          </div>
          
          {/* Hero Section Example */}
          <div className="space-y-2">
            <p className="text-sm font-medium">In Hero Section:</p>
            <div className="text-center p-8 bg-gradient-to-br from-blue-50 to-teal-50 rounded-lg">
              <NaviGoLogo size={120} className="mb-4" />
              <h2 className="text-2xl font-bold mb-2">Welcome to NaviGo</h2>
              <p className="text-gray-600">Your intelligent travel companion</p>
            </div>
          </div>
          
          {/* Sidebar Example */}
          <div className="space-y-2">
            <p className="text-sm font-medium">In Sidebar:</p>
            <div className="flex bg-gray-50 rounded-lg overflow-hidden">
              <div className="w-64 bg-white border-r border-gray-200 p-4">
                <div className="flex items-center gap-3 mb-6">
                  <NaviGoLogo variant="square" size={32} />
                  <span className="font-semibold text-sm">NaviGo</span>
                </div>
                <nav className="space-y-2">
                  <div className="px-3 py-2 bg-blue-50 text-blue-700 rounded-lg text-sm">Dashboard</div>
                  <div className="px-3 py-2 text-gray-600 rounded-lg text-sm">My Trips</div>
                  <div className="px-3 py-2 text-gray-600 rounded-lg text-sm">Explore</div>
                </nav>
              </div>
              <div className="flex-1 p-4">
                <p className="text-gray-500 text-sm">Main content area...</p>
              </div>
            </div>
          </div>
          
          {/* Dark Mode Example */}
          <div className="space-y-2">
            <p className="text-sm font-medium">In Dark Mode:</p>
            <div className="p-6 bg-slate-900 rounded-lg">
              <div className="flex items-center justify-center space-x-8">
                <div className="text-center">
                  <NaviGoLogo variant="square" size={40} />
                  <p className="text-white text-xs mt-2">Header Size</p>
                </div>
                <div className="text-center">
                  <NaviGoLogo size={80} />
                  <p className="text-white text-xs mt-2">Welcome Size</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Various Backgrounds */}
          <div className="space-y-2">
            <p className="text-sm font-medium">On Different Backgrounds:</p>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white p-4 rounded-lg border text-center">
                <NaviGoLogo variant="square" size={32} />
                <p className="text-xs text-gray-600 mt-2">White</p>
              </div>
              <div className="bg-sky-100 p-4 rounded-lg text-center">
                <NaviGoLogo variant="square" size={32} />
                <p className="text-xs text-gray-600 mt-2">Light Blue</p>
              </div>
              <div className="bg-gradient-to-br from-sky-500 to-teal-500 p-4 rounded-lg text-center">
                <NaviGoLogo variant="square" size={32} />
                <p className="text-xs text-white mt-2">Gradient</p>
              </div>
              <div className="bg-slate-800 p-4 rounded-lg text-center">
                <NaviGoLogo variant="square" size={32} />
                <p className="text-xs text-white mt-2">Dark</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}