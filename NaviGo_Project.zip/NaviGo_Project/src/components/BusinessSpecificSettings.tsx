import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Input } from './ui/input';
import { Separator } from './ui/separator';
import { 
  Plane, Hotel, Car, Utensils, Bus, Activity, Shield, Anchor, Briefcase, Package,
  Globe, Wifi, ParkingCircle, Bed, Camera, MapIcon, Settings, CreditCard, Clock,
  Users, TrendingUp, Star, Bell
} from 'lucide-react';

interface BusinessSpecificSettingsProps {
  businessType: string;
}

export function BusinessSpecificSettings({ businessType }: BusinessSpecificSettingsProps) {
  // Get business-specific settings based on type
  const getBusinessSettings = (type: string) => {
    switch (type) {
      case 'airline':
        return {
          icon: Plane,
          color: 'blue',
          title: 'Airline Management Settings',
          categories: [
            {
              name: 'Fleet Management',
              icon: Plane,
              settings: [
                { name: 'Aircraft availability sync', description: 'Real-time seat availability updates', enabled: true },
                { name: 'Route optimization', description: 'AI-powered route suggestions', enabled: false },
                { name: 'Maintenance scheduling', description: 'Automated maintenance alerts', enabled: true },
                { name: 'Crew management', description: 'Pilot and crew scheduling', enabled: true }
              ]
            },
            {
              name: 'Passenger Services',
              icon: Users,
              settings: [
                { name: 'Loyalty program integration', description: 'Miles and rewards tracking', enabled: true },
                { name: 'Special assistance', description: 'Disabled passenger services', enabled: true },
                { name: 'Meal preferences', description: 'Dietary requirement tracking', enabled: false },
                { name: 'Seat selection', description: 'Premium seat management', enabled: true }
              ]
            },
            {
              name: 'Pricing & Revenue',
              icon: TrendingUp,
              settings: [
                { name: 'Dynamic pricing', description: 'Real-time price adjustments', enabled: true },
                { name: 'Bulk booking discounts', description: 'Corporate travel rates', enabled: true },
                { name: 'Seasonal adjustments', description: 'Holiday and peak pricing', enabled: false },
                { name: 'Competition monitoring', description: 'Track competitor prices', enabled: true }
              ]
            }
          ]
        };
        
      case 'hotel':
        return {
          icon: Hotel,
          color: 'purple',
          title: 'Hotel Management Settings',
          categories: [
            {
              name: 'Room Management',
              icon: Bed,
              settings: [
                { name: 'Real-time availability', description: 'Live room inventory updates', enabled: true },
                { name: 'Room type preferences', description: 'Guest room selection preferences', enabled: true },
                { name: 'Housekeeping schedule', description: 'Automated cleaning schedules', enabled: false },
                { name: 'Maintenance tracking', description: 'Room maintenance alerts', enabled: true }
              ]
            },
            {
              name: 'Guest Services',
              icon: Star,
              settings: [
                { name: 'Concierge services', description: 'Local recommendations and bookings', enabled: true },
                { name: 'Spa and wellness', description: 'Wellness service bookings', enabled: false },
                { name: 'Restaurant reservations', description: 'On-site dining management', enabled: true },
                { name: 'Special occasions', description: 'Anniversary and celebration packages', enabled: true }
              ]
            },
            {
              name: 'Amenities & Features',
              icon: Wifi,
              settings: [
                { name: 'WiFi management', description: 'Guest internet access', enabled: true },
                { name: 'Parking services', description: 'Valet and self-parking', enabled: true },
                { name: 'Fitness center', description: 'Gym and pool access', enabled: false },
                { name: 'Business center', description: 'Meeting room bookings', enabled: true }
              ]
            }
          ]
        };
        
      case 'car-rental':
        return {
          icon: Car,
          color: 'green',
          title: 'Car Rental Management Settings',
          categories: [
            {
              name: 'Fleet Operations',
              icon: Car,
              settings: [
                { name: 'Vehicle tracking', description: 'GPS location monitoring', enabled: true },
                { name: 'Fuel management', description: 'Fuel level monitoring', enabled: true },
                { name: 'Maintenance alerts', description: 'Service and repair scheduling', enabled: false },
                { name: 'Insurance tracking', description: 'Coverage and claims management', enabled: true }
              ]
            },
            {
              name: 'Customer Experience',
              icon: Users,
              settings: [
                { name: 'Keyless entry', description: 'Mobile app vehicle access', enabled: false },
                { name: 'Roadside assistance', description: '24/7 emergency support', enabled: true },
                { name: 'Loyalty rewards', description: 'Frequent renter benefits', enabled: true },
                { name: 'Upgrade options', description: 'Premium vehicle upgrades', enabled: true }
              ]
            },
            {
              name: 'Pricing & Availability',
              icon: TrendingUp,
              settings: [
                { name: 'Dynamic pricing', description: 'Demand-based pricing', enabled: true },
                { name: 'Long-term discounts', description: 'Extended rental rates', enabled: true },
                { name: 'Corporate rates', description: 'Business customer pricing', enabled: false },
                { name: 'Seasonal adjustments', description: 'Holiday and peak pricing', enabled: true }
              ]
            }
          ]
        };
        
      case 'restaurant':
        return {
          icon: Utensils,
          color: 'orange',
          title: 'Restaurant Management Settings',
          categories: [
            {
              name: 'Reservation System',
              icon: Clock,
              settings: [
                { name: 'Table management', description: 'Real-time table availability', enabled: true },
                { name: 'Waitlist system', description: 'Automated waitlist notifications', enabled: true },
                { name: 'Special events', description: 'Private dining and events', enabled: false },
                { name: 'Group bookings', description: 'Large party reservations', enabled: true }
              ]
            },
            {
              name: 'Menu & Dietary',
              icon: Utensils,
              settings: [
                { name: 'Dietary restrictions', description: 'Allergy and preference tracking', enabled: true },
                { name: 'Seasonal menus', description: 'Dynamic menu updates', enabled: false },
                { name: 'Wine pairing', description: 'Sommelier recommendations', enabled: true },
                { name: 'Chef specials', description: 'Daily special promotions', enabled: true }
              ]
            },
            {
              name: 'Customer Service',
              icon: Star,
              settings: [
                { name: 'Review management', description: 'Customer feedback tracking', enabled: true },
                { name: 'Loyalty program', description: 'Repeat customer rewards', enabled: true },
                { name: 'Delivery integration', description: 'Third-party delivery services', enabled: false },
                { name: 'Gift cards', description: 'Digital gift card system', enabled: true }
              ]
            }
          ]
        };
        
      case 'activities':
        return {
          icon: Activity,
          color: 'red',
          title: 'Activity & Experience Settings',
          categories: [
            {
              name: 'Tour Management',
              icon: MapIcon,
              settings: [
                { name: 'Guide scheduling', description: 'Tour guide availability', enabled: true },
                { name: 'Group size limits', description: 'Maximum participants per tour', enabled: true },
                { name: 'Weather policies', description: 'Cancellation due to weather', enabled: false },
                { name: 'Equipment tracking', description: 'Gear and equipment management', enabled: true }
              ]
            },
            {
              name: 'Safety & Insurance',
              icon: Shield,
              settings: [
                { name: 'Liability waivers', description: 'Digital waiver management', enabled: true },
                { name: 'Emergency contacts', description: 'Emergency contact collection', enabled: true },
                { name: 'Age restrictions', description: 'Minimum age requirements', enabled: false },
                { name: 'Medical clearance', description: 'Health requirement checks', enabled: true }
              ]
            },
            {
              name: 'Customer Experience',
              icon: Camera,
              settings: [
                { name: 'Photo packages', description: 'Professional photography services', enabled: false },
                { name: 'Souvenir sales', description: 'Merchandise and gifts', enabled: true },
                { name: 'Multi-language guides', description: 'Language preference options', enabled: true },
                { name: 'Accessibility options', description: 'Disabled-friendly experiences', enabled: true }
              ]
            }
          ]
        };
        
      default:
        return {
          icon: Package,
          color: 'gray',
          title: 'General Travel Service Settings',
          categories: [
            {
              name: 'Service Management',
              icon: Settings,
              settings: [
                { name: 'Availability tracking', description: 'Real-time service availability', enabled: true },
                { name: 'Quality monitoring', description: 'Service quality assurance', enabled: true },
                { name: 'Customer feedback', description: 'Review and rating system', enabled: false },
                { name: 'Staff scheduling', description: 'Employee scheduling system', enabled: true }
              ]
            },
            {
              name: 'Customer Relations',
              icon: Users,
              settings: [
                { name: 'Communication tools', description: 'Customer messaging system', enabled: true },
                { name: 'Loyalty programs', description: 'Repeat customer rewards', enabled: false },
                { name: 'Complaint handling', description: 'Issue resolution tracking', enabled: true },
                { name: 'Refund processing', description: 'Automated refund system', enabled: true }
              ]
            }
          ]
        };
    }
  };

  const businessSettings = getBusinessSettings(businessType);

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className={`bg-gradient-to-r from-${businessSettings.color}-50 to-${businessSettings.color}-100 dark:from-${businessSettings.color}-900/20 dark:to-${businessSettings.color}-800/20 border-none`}>
        <CardContent className="p-6">
          <div className="flex items-center gap-4">
            <div className={`p-3 bg-${businessSettings.color}-100 dark:bg-${businessSettings.color}-900/40 rounded-xl`}>
              <businessSettings.icon className={`w-8 h-8 text-${businessSettings.color}-600 dark:text-${businessSettings.color}-400`} />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                {businessSettings.title}
              </h2>
              <p className="text-gray-600 dark:text-gray-400">
                Customize your business settings and preferences
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Settings Categories */}
      {businessSettings.categories.map((category, categoryIndex) => (
        <Card key={categoryIndex}>
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-3">
              <category.icon className={`w-6 h-6 text-${businessSettings.color}-600 dark:text-${businessSettings.color}-400`} />
              {category.name}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {category.settings.map((setting, settingIndex) => (
              <div key={settingIndex}>
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-gray-900 dark:text-white">
                        {setting.name}
                      </span>
                      {setting.enabled && (
                        <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300 border-green-200 dark:border-green-800">
                          ✓ Active
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {setting.description}
                    </p>
                  </div>
                  <Switch 
                    defaultChecked={setting.enabled} 
                    className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
                  />
                </div>
                {settingIndex < category.settings.length - 1 && (
                  <Separator className="mt-4" />
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      ))}

      {/* API Integration Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <Globe className={`w-6 h-6 text-${businessSettings.color}-600 dark:text-${businessSettings.color}-400`} />
            API Integration & Connectivity
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-900 dark:text-white">
                API Endpoint URL
              </label>
              <Input placeholder="https://your-api.example.com" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-900 dark:text-white">
                API Rate Limit (requests/minute)
              </label>
              <Input placeholder="1000" type="number" />
            </div>
          </div>
          
          <Separator />
          
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-gray-900 dark:text-white">Webhook Notifications</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Receive real-time notifications for booking updates
              </p>
            </div>
            <Switch 
              defaultChecked={true} 
              className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-medium text-gray-900 dark:text-white">Auto-sync Inventory</h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Automatically update availability across platforms
              </p>
            </div>
            <Switch 
              defaultChecked={false} 
              className="data-[state=checked]:bg-green-600 dark:data-[state=checked]:bg-green-500"
            />
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex gap-3">
        <Button className="bg-green-600 hover:bg-green-700 text-white">
          Save All Settings
        </Button>
        <Button variant="outline">
          Reset to Defaults
        </Button>
        <Button variant="outline">
          Export Configuration
        </Button>
      </div>
    </div>
  );
}