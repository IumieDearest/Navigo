<?php
session_start();

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = sanitize_input($_POST['email']);
    $password = $_POST['password'];
    
    if (empty($email) || empty($password)) {
        $error_message = 'Please fill in all fields.';
    } else {
        $business = authenticate_business($email, $password);
        if ($business) {
            $_SESSION['business_id'] = $business['id'];
            $_SESSION['user_type'] = 'business';
            $_SESSION['business_email'] = $business['email'];
            header('Location: business-dashboard.php');
            exit();
        } else {
            $error_message = 'Invalid email or password.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <title>NaviGo</title>
    
    <!-- PWA Meta Tags -->
    <meta name="description" content="Access your NaviGo business partner portal and connect with millions of travelers worldwide.">
    <meta name="theme-color" content="#8b5cf6" media="(prefers-color-scheme: light)">
    <meta name="theme-color" content="#1e1b4b" media="(prefers-color-scheme: dark)">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="apple-mobile-web-app-title" content="NaviGo Business">
    <meta name="mobile-web-app-capable" content="yes">
    
    <!-- PWA Manifest -->
    <link rel="manifest" href="js/manifest.json">
    
    <!-- Apple Touch Icons -->
    <link rel="apple-touch-icon" href="Assets/Images/icons/icon-180x180.png">
    <link rel="apple-touch-icon" sizes="152x152" href="Assets/Images/icons/icon-144x144.png">
    <link rel="apple-touch-icon" sizes="180x180" href="Assets/Images/icons/icon-180x180.png">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" sizes="32x32" href="Assets/Images/icons/icon-48x48.png">
    <link rel="shortcut icon" href="Assets/Images/icons/icon-48x48.png">
    
    <!-- External Resources -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    
    <!-- Stylesheets -->
    <link rel="stylesheet" href="css/business_login.css">
    
    <!-- Scripts -->
    <script src="js/dark-mode.js"></script>
    <script src="js/mobile-features.js"></script>
</head>
<body class="login-page">
    <!-- Dark Mode Toggle Button -->
    <button class="dark-mode-toggle" onclick="toggleDarkMode()">
        <span class="moon-icon">🌙</span>
    </button>
    
    <div class="container">
        <!-- Back Button -->
        <button class="back-button" onclick="window.location.href='Index.php'">
            <i class="fas fa-arrow-left"></i>
        </button>

        <!-- Dark Mode Toggle -->
        <button class="dark-mode-toggle" onclick="toggleDarkMode()">
            <span id="dark-mode-icon">🌙</span>
        </button>

        <div class="login-container">
            <!-- Left Content -->
            <div class="login-content">
                <div class="logo">
                    <div class="logo-container">
                        <img src="Assets/Images/NaviGo_Logo.png" alt="NaviGo Logo" class="logo-image">
                    </div>
                </div>
                <h1 class="login-title">
                    <span class="partnership">Your Partnership</span> <span class="starts">Starts Here</span>
                </h1>
                <h2 class="login-subtitle">Welcome to NaviGo</h2>
                <p class="login-description">
                    Join NaviGo's trusted partner network and unlock new opportunities to grow your business and reach millions of travelers worldwide.
                </p>

                <!-- Feature Icons -->
                <div class="features-grid">
                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div class="feature-content">
                            <h4>Grow Your Business</h4>
                            <p>Access new customer segments</p>
                        </div>
                    </div>

                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <div class="feature-content">
                            <h4>Bank-Grade Security</h4>
                            <p>Enterprise-level protection</p>
                        </div>
                    </div>

                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fas fa-chart-bar"></i>
                        </div>
                        <div class="feature-content">
                            <h4>Analytics Dashboard</h4>
                            <p>Detailed business insights</p>
                        </div>
                    </div>

                    <div class="feature-item">
                        <div class="feature-icon">
                            <i class="fas fa-code"></i>
                        </div>
                        <div class="feature-content">
                            <h4>Seamless API Access</h4>
                            <p>Easy integration and setup</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Login Panel -->
            <div class="login-panel">
                <div class="panel-header">
                    <h3>PARTNER ACCESS</h3>
                    <h4>Business Portal</h4>
                    <p>Join our trusted partner network</p>
                </div>

                <div class="login-form-container">
                    <h5 id="form-title">Partner Access</h5>
                    <p id="form-description">Sign in to your business portal</p>
                    
                    <!-- Toggle Buttons -->
                    <div class="form-toggle">
                        <button type="button" class="toggle-btn active" onclick="showSignIn()">Sign In</button>
                        <button type="button" class="toggle-btn" onclick="showRegister()">Register</button>
                    </div>
                    
                    <?php if ($error_message): ?>
                        <div class="alert alert-error">
                            <i class="fas fa-exclamation-circle"></i>
                            <?php echo htmlspecialchars($error_message); ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($success_message): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle"></i>
                            <?php echo htmlspecialchars($success_message); ?>
                        </div>
                    <?php endif; ?>

                    <!-- Sign In Form -->
                    <form method="POST" action="business_login.php" class="login-form" id="signin-form">
                        <div class="form-group">
                            <label for="email">
                                <i class="fas fa-briefcase"></i> Business Email
                            </label>
                            <input type="email" id="email" name="email" required 
                                   placeholder="your-business@company.com"
                                   value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                        </div>

                        <div class="form-group">
                            <label for="password">
                                <i class="fas fa-lock"></i> Password
                            </label>
                            <input type="password" id="password" name="password" required
                                   placeholder="Enter your password">
                        </div>

                        <button type="submit" class="btn-primary">
                            <i class="fas fa-handshake"></i> Begin Partnership
                        </button>
                    </form>

                    <!-- Register Form -->
                    <form method="POST" action="business_register.php" class="login-form" id="register-form" style="display: none;">
                        <div class="form-group">
                            <label for="business_name">Business Name</label>
                            <input type="text" id="business_name" name="business_name" required 
                                   placeholder="Your Business Name">
                        </div>

                        <div class="form-group">
                            <label for="business_type">Business Type</label>
                            <select id="business_type" name="business_type" required>
                                <option value="">Select business type</option>
                                <option value="hotel">Hotel</option>
                                <option value="restaurant">Restaurant</option>
                                <option value="tour">Tour Operator</option>
                                <option value="transport">Transportation</option>
                                <option value="other">Other</option>
                            </select>
                        </div>

                        <div class="form-row">
                            <div class="form-group">
                                <label for="first_name">Contact First Name</label>
                                <input type="text" id="first_name" name="first_name" required 
                                       placeholder="John">
                            </div>

                            <div class="form-group">
                                <label for="last_name">Contact Last Name</label>
                                <input type="text" id="last_name" name="last_name" required 
                                       placeholder="Doe">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="reg_email">
                                <i class="fas fa-envelope"></i> Business Email
                            </label>
                            <input type="email" id="reg_email" name="email" required 
                                   placeholder="contact@yourbusiness.com">
                        </div>

                        <div class="form-group">
                            <label for="phone">
                                <i class="fas fa-phone"></i> Phone Number
                            </label>
                            <input type="tel" id="phone" name="phone" required
                                   placeholder="+1 (555) 123-4567">
                        </div>

                        <div class="form-group">
                            <label for="reg_password">
                                <i class="fas fa-lock"></i> Password
                            </label>
                            <input type="password" id="reg_password" name="password" required
                                   placeholder="Create a strong password">
                        </div>

                        <button type="submit" class="btn-primary">
                            <i class="fas fa-rocket"></i> Launch Partnership
                        </button>
                    </form>

                    <div class="login-links">
                        <a href="forgot-password.php">Forgot your password?</a>
                    </div>

                    <div class="social-login">
                        <div class="divider">
                            <span>QUICK ACCESS</span>
                        </div>
                        
                        <div class="social-buttons">
                            <button class="btn-social">
                                <i class="fab fa-google"></i>
                                Google
                            </button>
                            <button class="btn-social">
                                <i class="fab fa-microsoft"></i>
                                Microsoft
                            </button>
                        </div>
                    </div>

                    <div class="legal-links">
                        By registering, you agree to our <a href="terms.php">Partner Terms</a> and <a href="privacy.php">Privacy Policy</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Dark mode is now handled by js/dark-mode.js

        // Form switching functions
        function showSignIn() {
            document.getElementById('signin-form').style.display = 'block';
            document.getElementById('register-form').style.display = 'none';
            document.getElementById('form-title').textContent = 'Partner Access';
            document.getElementById('form-description').textContent = 'Sign in to your business portal';
            
            // Update button states
            document.querySelectorAll('.toggle-btn').forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
        }
        
        function showRegister() {
            document.getElementById('signin-form').style.display = 'none';
            document.getElementById('register-form').style.display = 'block';
            document.getElementById('form-title').textContent = 'Partner Registration';
            document.getElementById('form-description').textContent = 'Connect with millions of travelers';
            
            // Update button states
            document.querySelectorAll('.toggle-btn').forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
        }

        // Dark mode initialization is now handled by js/dark-mode.js
        
        // Service Worker Registration
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('js/service-worker.js')
                    .then((registration) => {
                        console.log('Service Worker registered successfully:', registration.scope);
                    })
                    .catch((error) => {
                        console.log('Service Worker registration failed:', error);
                    });
            });
        }
        
        // Mobile-specific enhancements
        document.addEventListener('DOMContentLoaded', function() {
            // Add mobile class to body if on mobile
            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) || window.innerWidth <= 768) {
                document.body.classList.add('mobile-device');
            }
            
            // Optimize form inputs for mobile
            const inputs = document.querySelectorAll('input, select, textarea');
            inputs.forEach(input => {
                // Prevent zoom on focus for iOS
                input.addEventListener('focus', function() {
                    if (this.type === 'email' || this.type === 'password' || this.type === 'text' || this.type === 'tel') {
                        this.style.fontSize = '16px';
                    }
                });
                
                // Add touch feedback
                input.addEventListener('touchstart', function() {
                    this.classList.add('touch-active');
                }, { passive: true });
                
                input.addEventListener('touchend', function() {
                    setTimeout(() => {
                        this.classList.remove('touch-active');
                    }, 150);
                }, { passive: true });
            });
            
            // Add swipe gesture for form switching on mobile
            let startX = 0;
            let startY = 0;
            
            document.addEventListener('touchstart', function(e) {
                startX = e.touches[0].clientX;
                startY = e.touches[0].clientY;
            }, { passive: true });
            
            document.addEventListener('touchend', function(e) {
                const endX = e.changedTouches[0].clientX;
                const endY = e.changedTouches[0].clientY;
                const diffX = startX - endX;
                const diffY = startY - endY;
                
                // Check if it's a horizontal swipe
                if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 50) {
                    if (diffX > 0) {
                        // Swipe left - show sign in
                        showSignIn();
                    } else {
                        // Swipe right - show register
                        showRegister();
                    }
                }
            }, { passive: true });
        });
    </script>
</body>
</html>